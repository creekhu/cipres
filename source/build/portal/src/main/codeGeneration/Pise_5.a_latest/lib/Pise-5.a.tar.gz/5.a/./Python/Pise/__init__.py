from httplib import HTTP
import xml.sax.handler
import re
import time
import os
import sys
from Bio.Seq import Seq
from Bio.SeqRecord import SeqRecord
from Bio.Clustalw import ClustalAlignment
import StringIO
import types

class PiseFactory:

    """
    A class to create Pise application objects.

       from Pise import PiseFactory
       factory = PiseFactory(email='user@domain')
       program = factory.program(\"toppred\",
                                 graph_output=1,
                                 profile_format=\"ps\")
       job = program.run(query=myseq)
       if job.error():
           print job.error_message()
       else:
           print \"url of the job: \" + job.jobid()
           print job.stdout()
           print \"Results: \", job.get_results()
           job.save('.ps')
    
    """

    _debug = 0

    _location = 'http://bioweb.pasteur.fr/cgi-bin/seqanal'
    #_location = 'http://localhost/cgi-bin/Pise'
    _DEFAULT_PISE_EMAIL = 'pise-bioapi@pasteur.fr'
    
    def __init__(self, email=_DEFAULT_PISE_EMAIL, location=None, verbose=0):
        self._email = email
        if location:
            self._location = location
        else:
            self._location = PiseFactory._location
        self._verbose = verbose

    def program(self, program, **args):
        """
        Creates an instance of <program> (a subclass of PiseApplication)
        to run this program on a Pise server.
        """
        
        for param,value in args.items():
            if param == "email":
                self._email = value
            elif param == "location":
                self._location = value
            elif param == "verbose":
                self._verbose = value
        exec("from Pise import " + program)
        location = self._location + "/" + program + ".pl"
        stmt = "pise_program = " + program + "." + program + "(location=\"" + location + "\",email=\"" + self._email + "\", verbose=" + str(self._verbose) +")"
        if PiseFactory._debug:
            print >>sys.stderr, "PiseFactory stmt: ", stmt
        exec(stmt)
        for param in pise_program.parameters():
            if args.has_key(param):
                pise_program.param(param,args[param])
        return pise_program


class PiseApplication:

    """
    A class to run Pise jobs. Instances should be created by a
    factory:
    factory=PiseFactory(email=...)
    program=factory.program(<program>, [params])
    job = program.run([params])
    """

    _debug = 0
    
    def __init__(self, verbose=0, location=None, **args):
        if location:
            self._location = location
        else:
            self._location = PiseFactory._location
            
        if args.has_key("email"):
            self._email = args["email"]
        self._verbose = verbose
            
        self._value = {}
        for param in self._parameters:
            if args.has_key(param):
                self.param(param,args[param])
        self._results_type = "url"
        self._param_method = {}
        

    def __getattr__(self, name):
        
        # 1. calling self.<parameter name>()
        #  -> define it on the fly if needed
        try:
            p = self._parameters.index(name)
            if PiseApplication._debug:
                print >>sys.stderr, "PiseApplication __getattr__: ", name, " : this is a parameter"
            if not self._param_method.has_key(name):
                self._param_method[name] = ParamMethod(PiseApplication.__dict__['param'], self, name)
            return self._param_method[name]

        # 2. other statically defined attributes
        except ValueError:
            try:
                value = self.__dict__[name]
            except KeyError:
                raise AttributeError, name
            if type(value) is not types.FunctionType:
                return value
            return ParamMethod(value, self)
    
    def param(self, name, value=None):
        if ParamMethod._debug:
            print >>sys.stderr, "PiseApplication param: name: ", name, " value: ", value
            
        try:
            result = self._parameters.index(name)
        except:
            raise PiseError, "parameter " + name + " does not exist for " + self._command
        if value is not None:
            if ParamMethod._debug:
                print >>sys.stderr, "PiseApplication param: setting ", name, " to: ", value
                
            self._value[name] = value
        else:
            if self._value.has_key(name):
                return self._value[name]
            else:
                return None

    def vdef(self, param):
        if self._vdef.has_key(param):
            return  self._vdef[param]
        else:
            return None

    def run(self, location=None, interval=10, **args):
        if location:
            _location = location
        else:
            _location = self._location
            
        try:               
            pisejob = self.submit(_location, **args)
            if PiseApplication._debug:
                print >>sys.stderr, "PiseApplication run: pisejob submitted: ", pisejob.jobid()
                
        except JobError, e:
            print >>sys.stderr, e
            return

        while not pisejob.error() and not pisejob.terminated():
            time.sleep(interval)

        return pisejob

    def submit(self, location=None, **args):
        if location:
            _location = location
        else:
            _location = self._location

        for _param in self._parameters:
            if args.has_key(_param):
                self.param(_param,args[_param])

        try:
            self._pisejob = PiseJob(self, _location, self._verbose)
            if PiseApplication._debug:
                print >>sys.stderr, "PiseApplication submit: pisejob created :", self._pisejob.jobid()
        except JobError, e:
            print >>sys.stderr, e
            return

        if not self._pisejob.error():
            self._last_job_id = self._pisejob.jobid()
            if not self._pisejob.terminated():
                self._pisejob.results_type(self._results_type)
        
        return self._pisejob

    def parameters(self):
        return self._parameters
    
    def param_type(self, param):
        if param == "email":
            return "String"
        return self._param_type[param]
    
    def results_type(self, results_type, value=None):
        if value:
            self._results_type = value
        else:
            return self._results_type

    def pipein(self, pipetype):
	""" 
	Returns the name of parameter(s) having the requested pipetype 
	"""
        if self._verbose:
	    print >>sys.stderr, "PiseApplication/pipein: looking for parameters of pipe_type: ", pipetype
	result = []
	for param in self._pipetype.keys():
	    if self._verbose:
		print >>sys.stderr, "PiseApplication/pipein: param: ", param, " (", self._pipetype[param], ")"
	    if pipetype in self._pipetype[param]:
		result.append(param)
	return result

    def verbose(self, value=None):
        if value is not None:
            self._verbose = value
        else:
            return self._verbose
        

class PiseJob:

    """
    Pise jobs: a submitted program. You can test for termination,
    get results, ...
    """
    
    _debug = 0
    
    def __init__(self, application=None, location=None, verbose=0, submit=1, jobid=None):

        self._application = application
        self._verbose = verbose
        
        if application:
            self._email = application._email
        if location:
            self._location = location
        else:
            if application:
                self._location = application._location
        if application:
            self._command = application._command

        if jobid and jobid[-1:] != '/':
            if PiseJob._debug:
                print >>sys.stderr, "PiseJob __init__: jobid: ", jobid
            jobid += '/'
            
        self._jobid = jobid
        self._error = None
        self._error_message = ""
        self._terminated = 0
        self._args = []
        self._results = None
        self._results_type = None
        self._scratch_dir = ""
        self._pipes = []
        self._piped_file_type = {}
        self._ua = None
        
        if submit:
            self._submit()
            if PiseJob._debug:
                print >>sys.stderr, "PiseJob __init__: _submit done"
        else:
            # creates an instance from an already run job
            if jobid:
                self._command = self._get_command(jobid)
                self._job(jobid)
                
    def jobid(self):
        return self._jobid
    
    def terminated(self):
        """
        Re-check whether the job is terminated by getting the page and
        re-parsing.
        """

        if self._terminated:
            return 1
        
        jobid = self._jobid
        if not jobid:
            raise JobError, " Job not submitted yet."
        
        host = self._get_host(jobid)
        uri = self._get_uri(jobid)

        if self._verbose:
            print >>sys.stderr, "Getting document from host: ", host, " uri: ", uri
            
        ua = self._get_ua(host)
        ua.putrequest('GET', uri)
        ua.putheader("Accept", "text/html")
        ua.putheader("User-Agent", "Python/Pise")
        ua.endheaders()
        
        ec, em, h = ua.getreply()
        if ec == 200:
            if self._verbose:
                print >>sys.stderr, "HTTP GET ", jobid, " request successful"
                
            self._results = ua.getfile()
            self._parse()
            handler = self._handler
            self._terminated = handler.terminated()
            if self._terminated:
                self._results_files = handler.hrefs()
                self._piped_file_type = handler.piped_file_type()
                self._piped_param_type = handler.piped_param_type()
                if self._verbose: 
		    print >>sys.stderr, "terminated: piped_param_type: " , self._piped_param_type.keys()
		self._pipes = handler.pipes()
                
            return self._terminated

        else:
            self._error_message = "Problem in HTTP GET request: " + em
            if self._verbose: 
                print >>sys.stderr, "Problem in HTTP request: " + em
            raise JobError, "Problem in HTTP GET request: " + em
            

    def save(self, result_file, filename=None):
        content = self.content(result_file)
        if not filename:
            for url in self._results_files:
                if url.find(result_file) >= 0:
                    filename = self._get_filename(url)
                    break

        if filename:
            f = open(filename, "w")
            f.write(content)
            f.close()
            if self._verbose:
                print >>sys.stderr, "Content of ", result_file, " saved in ", filename
            return filename
        else:
            raise JobError, " not able to infer a filename from: " + result_file

    def stdout(self):
        return self.content(self._command + ".out")

    def stderr(self):
        return self.content(self._command + ".err")

    def content(self, result_file):
        if not self._jobid:
            raise JobError, "Job not submitted yet."
        
        if not self.terminated():
            raise JobError, "Job is not terminated"

        file = None
        for url in self._results_files:
            if url.find(result_file) >= 0:
                file = url
                break

        if not file:
            raise JobError, result_file + ": no such file in job results"
        
        host = self._get_host(file)
        uri = self._get_uri(file)

        if self._verbose:
            print >>sys.stderr, "Getting document from host: ", host, " uri: ", uri
            
        ua = self._get_ua(host)
        ua.putrequest('GET', uri)
        ua.putheader("Accept", "text/html")
        ua.putheader("User-Agent", "Python/Pise")
        ua.endheaders()
        
        ec, em, h = ua.getreply()
        if ec == 200:
            if self._verbose:
                print >>sys.stderr, "HTTP GET ", uri, " request successful"
            content = ua.getfile()
            return content.read()
        
        else:
            self._error_message = "Problem in HTTP GET request: " + em
            if self._verbose: 
                print >>sys.stderr, "Problem in HTTP request: " + em
            raise JobError, "Problem in HTTP GET request: " + em
            
      
    def fh(self, result_file):
        content = self.content(result_file)
        if content:
            handle = StringIO.StringIO(content)
            return handle
        
    def get_results(self):
        if not self._jobid:
            raise JobError, "Job not submitted yet."
        
        if not self.terminated():
            raise JobError, "Job is not terminated"

        return self._results_files
        
    def get_pipes(self, result_file):
        if not self._jobid:
            raise JobError, "Job not submitted yet."
        
        if not self.terminated():
            raise JobError, "Job is not terminated"

        return self._pipes[result_file]

    def piped_file_type(self, result_file):
        if not self._jobid:
            raise JobError, "Job not submitted yet."
        
        if not self.terminated():
            raise JobError, "Job is not terminated"

        return self._piped_file_type[result_file]
        
        
    def piped_param_type(self, result_file):
        if not self._jobid:
            raise JobError, "Job not submitted yet."
        
        if not self.terminated():
            raise JobError, "Job is not terminated"

        return self._piped_param_type[result_file]
        
        
    def lookup_piped_file(self, pipe_type):
        if not self._jobid:
            raise JobError, "Job not submitted yet."
        
        if not self.terminated():
            raise JobError, "Job is not terminated"

        for result_file in self._results_files:
	    try:
		if self._piped_file_type[result_file] == pipe_type:
		    return result_file
	    except KeyError:
		pass

    def pipein(self, pipe_type):
        """
	Returns the name of the parameter of type: pipe_type
	"""
        if self._verbose:
	    print >>sys.stderr, "PiseJob/pipein: looking for parameters of pipe_type: ", pipe_type
	for result_file in self._piped_param_type.keys():
	    if self._verbose:
		print >>sys.stderr, "PiseJob/pipein: ", result_file, " name: ",self._piped_param_type[result_file]
	    try:
		if self._piped_file_type[result_file] == pipe_type:
		    return self._piped_param_type[result_file]
	    except KeyError:
		pass
        
    def results_type(self, results_type=None):
        
        """
        Either get current results type, or change results type on the
        Pise Web server.
        """
        
        if results_type is None:
            return self._results_type

        if self._terminated:
            print >>sys.stderr, "Job has already terminated"
                
        boundary ="3350843711048987223263301088"
        postdata = "--" + boundary

        postdata += "\r\nContent-Disposition: form-data; name=\"command\""
        postdata += "\r\n\r\n" + self._command + "\r\n"
        postdata += "--" + boundary

        postdata += "\r\nContent-Disposition: form-data; name=\"email\""
        postdata += "\r\n\r\n" + self._email + "\r\n"
        postdata += "--" + boundary

        postdata += "\r\nContent-Disposition: form-data; name=\"results_type\""
        postdata += "\r\n\r\n" + results_type + "\r\n"
        postdata += "--" + boundary

        postdata += "\r\nContent-Disposition: form-data; name=\"scratch_dir\""
        postdata += "\r\n\r\n" + self._scratch_dir + "\r\n"
        postdata += "--" + boundary

        postdata += "--\r\n"
        content_length = str(len(postdata))

        host = self._get_host(self._location)
        cgi_re = re.compile('(.*)/' + self._command + '\.pl')
        m = cgi_re.match(self._location)
        if m:
            cgi = m.group(1) + '/lib/results.pl'

        if self._verbose:
            print >>sys.stderr, "Submitting to host: ", host, " cgi: ", cgi, " ..."
            
        ua = self._get_ua(host)
        ua.putrequest('POST', cgi)
        ua.putheader("Accept", "text/html")
        ua.putheader("User-Agent", "Python/Pise")
        ua.putheader("Content-Length", content_length)
        ua.putheader("Content-type", "multipart/form-data; boundary=" + boundary)
        ua.endheaders()

        if self._verbose:
            print >>sys.stderr, "\npostdata:\n", postdata
            print >>sys.stderr, "\ncontent_length: ", content_length

        ua.send(postdata)

        ec, em, h = ua.getreply()
        if self._verbose or PiseJob._debug:
            print >>sys.stderr, "PiseJob results_type: Request status: ", ec, " ", em
            
        if ec == 200:
            if self._verbose:
                print >>sys.stderr, "HTTP POST ", cgi, " request successful"
                
        else:
            self._error = 1
            self._error_message = "Problem in HTTP request: " + em
            if self._verbose: 
                print >>sys.stderr, "Problem in HTTP request: " + em
            raise JobError, "Problem in HTTP request: " + em

        

    def error(self):
        return self._error

    def error_message(self):
        return self._error_message

    def verbose(self, value=None):
        if value is not None:
            self._verbose = value
        else:
            return self._verbose
        
    # --------------------------------------------------------
    # Internal core methods
    
    def _submit(self):
        if self._jobid:
            self._error = 1
            self._error_message = "Job already lauchend"
            raise JobError, "Job already lauchend"

        application = self._application
        
        content = {}
        #content["email"] = self._email
        
        for param in application.parameters():
            value = application.param(param)
            vdef = application.vdef(param)
            if value is None:
                if vdef is not None:
                    value = vdef
                continue
            type = application.param_type(param)
            if PiseJob._debug:
                print >>sys.stderr, "PiseJob _submit: Filling content with ", param, " type: ", type, " value: ", value
            if type == "Sequence" or type == "InFile":
                
                if isinstance(value,Seq):
                    if self._verbose:
                        print >>sys.stderr, "input sequence is an instance of Bio.Seq Seq class"
                    content[param] = value.data + "\n"
                    
                elif isinstance(value,SeqRecord):
                    if self._verbose:
                        print >>sys.stderr, "input sequence is an instance of Bio.SeqRecord SeqRecord class"
                    if value.name == '<unknown name>':
                        content[param] = ">" + value.description + "\n"
                    else:
                        content[param] = ">" + value.name + "\n"
                    content[param] += value.seq.data + "\n"
                    
                elif isinstance(value,ClustalAlignment):
                    if self._verbose:
                        print >>sys.stderr, "input sequence is an instance of Bio.Clustalw ClustalAlignment class"
                    content[param] = ""
                    for seq in value.get_all_seqs():
                        content[param] += ">" + seq.description + "\n"
                        content[param] += seq.seq.data + "\n"
                    
                else:
		    try:
			if os.path.exists(value):
			    if self._verbose:
				print >>sys.stderr, "input sequence is a file"
			    content[param] = value
		    except TypeError, e:
			try:
			    res = value.isatty()
			    if self._verbose:
				print >>sys.stderr, "input sequence is a filehandle"
			    content[param] = "".join(value.readlines())

			except Exception, e:
			    if self._verbose:
				print >>sys.stderr, "input sequence is a string"
			    content[param] = value
                    
            elif type == "Switch":
                if value:
                    content[param] = "on"
            else:
                 content[param] = value

        if PiseJob._debug:
            print >>sys.stderr, "PiseJob _submit: content: ", content
            
        boundary = "3350843711048987223263301088"
        postdata = "--" + boundary

        postdata += "\r\nContent-Disposition: form-data; name=\"email\""
        postdata += "\r\n\r\n" + self._email + "\r\n"
        postdata += "--" + boundary

        for param in content.keys():
            type = application.param_type(param)
            value = content[param]
            if self._verbose:
                print >>sys.stderr, "Filling postdata with ", param, " type: ", type, " value: ", value

            if type == "Sequence" or type == "InFile":
                if os.path.exists(value):
                    filename = os.path.basename(value)
                    postdata += "\r\nContent-Disposition: form-data; name=\"" + param + "\""
                    postdata += "; filename=\"" + filename + "\"\r\n"
                    postdata += "Content-Type: text/plain\r\n" + "\r\n"
                    f=open(value)
                    l=f.readline()
                    while l:
                        l=l[0:-1]
                        postdata += l + "\r\n"
                        l=f.readline()
                        
                    f.close()
                    postdata += l + "\r\n"
                    postdata += "--" + boundary
    
                else: 
                    postdata += "\r\nContent-Disposition: form-data; name=\"" + param + "_data\""
                    postdata += "\r\n\r\n" + value + "\r\n"
                    postdata += "--" + boundary
            elif type == "Integer" or type == "Float" :
                postdata += "\r\nContent-Disposition: form-data; name=\"" + param + "\""
                postdata += "\r\n\r\n" + str(value) + "\r\n"
                postdata += "--" + boundary
                
            else:
                postdata += "\r\nContent-Disposition: form-data; name=\"" + param + "\""
                postdata += "\r\n\r\n" + value + "\r\n"
                postdata += "--" + boundary


        postdata += "--\r\n"
        content_length = str(len(postdata))

        host = self._get_host(self._location)
        cgi = self._get_cgi(self._location)

        if self._verbose:
            print >>sys.stderr, "Submitting to host: ", host, " cgi: ", cgi, " ..."
            
        ua = self._get_ua(host)
        ua.putrequest('POST', cgi)
        ua.putheader("Accept", "text/html")
        ua.putheader("User-Agent", "Python/Pise")
        ua.putheader("Content-Length", content_length)
        ua.putheader("Content-type", "multipart/form-data; boundary=" + boundary)
        ua.endheaders()

        if self._verbose:
            print >>sys.stderr, "\npostdata:\n", postdata
            print >>sys.stderr, "\ncontent_length: ", content_length

        ua.send(postdata)

        ec, em, h = ua.getreply()
        if self._verbose or PiseJob._debug:
            print >>sys.stderr, "PiseJob _submit: Request status: ", ec, " ", em
            
        if ec == 200:
            if self._verbose:
                print >>sys.stderr, "HTTP POST ", cgi, " request successful"
                
            self._results = ua.getfile()
            #t = self._results.read()
            #print t
            #return

            self._parse()
            
            handler = self._handler
            self._jobid = handler.pise_result_url()
            self._results_files = handler.hrefs()
            self._piped_file_type = handler.piped_file_type()
            self._piped_param_type = handler.piped_param_type()
            self._scratch_dir = handler.scratch_dir()
            self._error = handler.error()
            self._error_message = handler.error_message()
            self._pipes = handler.pipes()
            self._value = handler.value()
            self._terminated = handler.terminated()
                
        else:
            self._error = 1
            self._error_message = "Problem in HTTP request:" + em
            if self._verbose: 
                print >>sys.stderr, "Problem in HTTP request:" + em
            raise JobError, "Problem in HTTP request: " + em


    def _parse(self):
        results = self._results
        
        parser = xml.sax.make_parser()
        self._handler = PiseJobParser(verbose=self._verbose)
        handler = self._handler
        parser.setContentHandler(handler)
        
        try:
            parser.parse(results)

        except StandardError,e:
            print >>sys.stderr, "Problem in parsing: ", e
            raise
           
        if self._verbose:
            print >>sys.stderr, "Result parsed, error? ", self._error, " terminated? ", self._terminated

    def _job(self, jobid):
        """
        Creates a PiseJob instance from an already run job.
        """
        host = self._get_host(jobid)
        uri = self._get_uri(jobid)
            
        if self._verbose:
            print >>sys.stderr, "Getting document from host: ", host, " uri: ", uri
            
        ua = self._get_ua(host)
        ua.putrequest('GET', uri)
        ua.putheader("Accept", "text/html")
        ua.putheader("User-Agent", "Python/Pise")
        ua.endheaders()
        
        ec, em, h = ua.getreply()
        if ec == 200:
            if self._verbose:
                print >>sys.stderr, "HTTP GET ", jobid, " request successful"
                
            self._results = ua.getfile()
            self._parse()
            
            handler = self._handler
            
            self._jobid = handler.pise_result_url()
            self._results_files = handler.hrefs()
            self._piped_file_type = handler.piped_file_type()
            self._piped_param_type = handler.piped_param_type()
            self._scratch_dir = handler.scratch_dir()
            self._error = handler.error()
            self._error_message = handler.error_message()
            self._pipes = handler.pipes()
            self._value = handler.value()
            self._terminated = handler.terminated()

        else:
            self._error_message = "Problem in HTTP GET request: " + em
            if self._verbose: 
                print >>sys.stderr, "Problem in HTTP request: " + em
            raise JobError, "Problem in HTTP GET request: " + em
            
    # ------------------------------------------
    # Utilities for internal use.
    
    def _get_ua(self, host):
        if not self._ua:
            self._ua = HTTP(host)
        return self._ua

    def _get_host(self,url):
        location_re = re.compile('http://([^/]+)/(.*)')
        m = location_re.match(url)
	if m:
	    host = m.group(1)
	    return host
	else:
	    raise JobError, "url: " + url + " not valid"

    def _get_uri(self,url):
        location_re = re.compile('http://([^/]+)(/.*)')
        m = location_re.match(url)
        uri = m.group(2)
        return uri
    
    def _get_filename(self,url):
        location_re = re.compile('http://[^/]+/.*/([^/]+)')
        m = location_re.match(url)
        if m:
            filename = m.group(1)
        else:
            filename = url
        return filename
    
    def _get_command(self,jobid):
        command_re = re.compile('http://.+/(\w+)/\w+/\s*$')
        m = command_re.match(jobid)
        if m:
            if self._debug:
                print >>sys.stderr, "PiseJob _get_command (1): ", m.group(1)
            return m.group(1)
        
        command_re = re.compile('http://.+/(\w+)/\w+/index.html')
        m = command_re.match(jobid)
        if m:
            if self._debug:
                print >>sys.stderr, "PiseJob _get_command (2): ", m.group(1)
            return m.group(1)
        
        command_re = re.compile('http://.+/(\w+)/\w+\s*$')
        m = command_re.match(jobid)
        if m:
            if self._debug:
                print >>sys.stderr, "PiseJob _get_command (3): ", m.group(1)
            return m.group(1)
    
    def _get_cgi(self,url):
        location_re = re.compile('http://([^/]+)/(.*)')
        m = location_re.match(url)
        cgi = m.group(2)
        cgi_re = re.compile('(.*)/' + self._command + '\.pl')
        m = cgi_re.match(cgi)
        if m:
            cgi = m.group(1)
        cgi = "/" + cgi + "/" + self._command + ".pl"
        return cgi


class PiseJobParser(xml.sax.handler.ContentHandler):

    _debug = 0
    
    def __init__(self, verbose=0):
        self._verbose = verbose
    
    def startElement(self, element_name, attributes):
        if PiseJobParser._debug >= 2:
            print >>sys.stderr, "PiseJobParser in startElement: ", element_name
            
        if element_name == "HTML":
            self._command = None
            self._terminated = 0
            self._error = 0
            self._error_message = ""
            self._check_message = 0
            self._href = None
            self._hrefs = []
            self._output_files = 0
            self._result_url = 0
            self._pise_result_url = None
            self._scratch_dir = None
            self._pipes = {}
            self._connected = {}
            self._piped_file_type = {}
            self._piped_param_type = {}
            self._value = {}
            
        elif element_name == "A":
            if not attributes.has_key("HREF"):
                return
            
            href = attributes["HREF"]
            self._connected[href] = 0
            self._pipes[href] = []
            
            if self._output_files:
                self._hrefs.append(href)
            elif self._result_url:
                if not self._pise_result_url:
                    self._pise_result_url = href
                    if href.find("index.html") >= 0:
			print >>sys.stderr, "PiseJobParser href: ", href
			self._pise_result_url = href[:href.find("index.html")]
			print >>sys.stderr, "PiseJobParser : _pise_result_url", self._pise_result_url
		    else:
			if href[-1:] != '/':
			    if PiseJobParser._debug >= 2:
				print >>sys.stderr, "PiseJobParser _pise_result_url: ", self._pise_result_url
			    self._pise_result_url += '/' 
            self._href = href
            
        elif element_name == "H3":
            #if self._error:
            #    self._check_message = 1
            # this parser does not deal with comments apparently
            self._error = 1
            self._check_message = 1
                
        elif element_name == "FORM":
            connect_re = re.compile('.*/connect.pl')
            results_re = re.compile('.*/results.pl')
            action = attributes["action"]
            connect=connect_re.match(action)
            if connect:
                self._connected[self._href] = 1
            else:
                results=results_re.match(action)
                if results:
                    self._terminated = 0

        elif element_name == "INPUT":
            
            name = None
            if attributes.has_key("NAME"):
                name = attributes["NAME"]
                if PiseJobParser._debug >= 2:
                    print >>sys.stderr, "PiseJobParser INPUT name: ", name
                
            value = attributes["VALUE"]

            if PiseJobParser._debug >= 2:
                print >>sys.stderr, "PiseJobParser INPUT value: ", value, " attr: ", attributes.keys()
                
            if name == "scratch_dir":
                self._scratch_dir = value
            else:
                self._value[name] = value
            if self._connected.has_key(self._href) and self._connected[self._href]:
                if name == "piped_file_type":
                    self._piped_file_type[self._href] = value

                if name == "piped_variable":
                    self._piped_param_type[self._href] = value
		    if self._verbose: 
			print >>sys.stderr, "PiseJobParser/startElement: piped_param_type: " , self._piped_param_type.keys()

        elif element_name == "OPTION":
            option = 1
            value = attributes["VALUE"]

            if PiseJobParser._debug >= 2:
                print >>sys.stderr, "PiseJobParser OPTION value: ", value
                
            if value.find(",") == -1:
                command = value
                with_piped_files = []
            else:
                l = value.split(",")
                command = l[0]
                with_piped_files = l[1:]

                if PiseJobParser._debug >= 2:
                    print >>sys.stderr, "PiseJobParser command: ", command
                    print >>sys.stderr, "PiseJobParser with_piped_files: ", with_piped_files
                    
            if self._connected.has_key(self._href) and self._connected[self._href]:
                self._pipes[self._href].append(command)

            if self._href:
                root_re = re.compile('(.+)\/.+')
                m = root_re.match(self._href)
                root_url = m.group(1)
            
                for with_file in with_piped_files:
                    if PiseJobParser._debug >= 2:
                        print >>sys.stderr, "PiseJobParser with_file: ", with_file
                    
                    if with_file.find("=") == -1:
                        continue
                
                    (with_param,with_value) = with_file.split("=")
                    with_href = root_url + "/" + with_value
                    if not self._pipes.has_key(with_href):
                        self._pipes[with_href] = []
                        if not command in self._pipes[with_href]:
                            self._pipes[with_href].append(command)
                        self._piped_file_type[with_href] = with_param
                
    def endElement(self, element_name):
        if element_name == "H3":
            if self._error:
                self._check_message = 0


    def characters(self, char_data):

        blank_re = re.compile('^\s*$')
        
        if PiseJobParser._debug >= 2 and not blank_re.match(char_data):
            print >>sys.stderr, "PiseJobParser char_data: " + char_data
            
        remain_re = re.compile('.*this files will remain accessible for.*')
        save_indiv_re = re.compile('You can save them individually.*')
        upon_compl_re = re.compile('.*upon completion of the job.*')
        please_wait_re = re.compile('Please wait for the results of this query before submitting')
        similar_jobs_re = re.compile('Two similar jobs have been submitted.*')
        
        if char_data == "Results:":
            self._output_files = 1
            self._terminated = 1
            if PiseJobParser._debug:
                print >>sys.stderr, "PiseJobParser Job terminated"
                
        elif char_data == "Results not available yet":
            self._terminated = 0
        elif remain_re.match(char_data):
            if PiseJobParser._debug:
                print >>sys.stderr, "PiseJobParser Result url: on "
            self._output_files = 0
            self._result_url = 1
        elif save_indiv_re.match(char_data):
            self._result_url = 0
        elif upon_compl_re.match(char_data):
            self._result_url = 1
        elif please_wait_re.match(char_data):
            self._result_url = 0
        elif similar_jobs_re.match(char_data):
            self._error = 1
            self._error_message = char_data

        if self._check_message:
            self._error_message += char_data

    def pipes(self):
        return self._pipes

    def piped_file_type(self):
        return self._piped_file_type

    def piped_param_type(self):
        return self._piped_param_type

    def pise_result_url(self):
        return self._pise_result_url

    def scratch_dir(self):
        return self._scratch_dir
    
    def hrefs(self):
        return self._hrefs

    def value(self):
        return self._value

    def terminated(self):
        return self._terminated

    def error(self):
        return self._error

    def error_message(self):
        return self._error_message
    
    
class JobError(StandardError):
    pass

class PiseError(StandardError):
    pass

class ParamMethod: 
    """
    A way to trap AttributeError by redefining __getattr__ in
    PiseApplication, which returns a ParamMethod for callable
    attributes (http://www.python.org/doc/essays/metaclasses/).
    """
    
    _debug = 0
    
    def __init__(self, function, instance, param=None): 
        if ParamMethod._debug: 
            print >>sys.stderr, "ParamMethod __init__: function: ", function, " parameter: ", param  
        self.function = function 
        self.instance = instance 
        self.param = param 
        
    def __call__(self, *args): 
        if ParamMethod._debug: 
            print >>sys.stderr, "ParamMethod __call__: calling", self.function, "for", self.instance, "with parameter: ", self.param, " and: args: ", args 
        if self.param: 
            return apply(self.function, (self.instance, self.param,) + args) 
        else: 
            return apply(self.function, (self.instance,) + args) 

