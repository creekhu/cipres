# local copies
$title = ${"${command}::title"};
@top_parameters=@{"${command}::top_parameters"};
@by_group_parameters=@{"${command}::by_group_parameters"};
%type = %{"${command}::type"};
%format = %{"${command}::format"};
%group = %{"${command}::group"};
%hidden = %{"${command}::hidden"};
%command = %{"${command}::command"};
%mandatory = %{"${command}::mandatory"};
%prompt = %{"${command}::prompt"};
%standout = %{"${command}::standout"};
%vlist = %{"${command}::vlist"};
%vdef = %{"${command}::vdef"};
%precond = %{"${command}::precond"};
%ctrl = %{"${command}::ctrl"};
%clean = %{"${command}::clean"};
%simple = %{"${command}::simple"};
%paramfile = %{"${command}::paramfile"};
%comment = %{"${command}::comment"};

