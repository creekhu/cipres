#
# HTML : non expert version of the form (attribute : simple)
#
#TODO:

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";
use File::Listing;

package Maker;
use Getopt::Std;

$PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : "/local/gensoft/lib/Pise/5.a/PerlDef";
$VERSION = ($ENV{'VERSION'})? $ENV{'VERSION'} : "5.a" ;
$PISEDIR=($ENV{'PISEDIR'})? $ENV{'PISEDIR'} : "/local/gensoft/lib/Pise/$VERSION";
require "$PISEDIR/lib/web.pl";
$ROOT_HTML_FORM = "http://bioweb.pasteur.fr/seqanal/interfaces";
$DONT{clustalw} = 1;

getopts('p:c:t:f:C:');
if (! $opt_f) {
    print STDERR "you must provide a SeWer file\n";
    exit;
}
$SEWER_FILE = $opt_f;

sub getmaincat {
    my $cat = $_[0];
    @subcats = split(":", $cat);
    return $subcats[0];
}

if ($opt_p) {

    foreach my $command (split(",",$opt_p)) {
	eval ("use $command;");
	next if ($@);
	$defs = $command->new;
	next if ($@);
	$defs{$command} = $defs;
	push @l, $command;
    }
    print_sewer(@l)

} elsif ($opt_c) {
    $category = $opt_c;
    if ($opt_C) {
	$not_category = $opt_C;
    }
    if ($category eq "emboss") {
	foreach my $command (split(/\s/,$ENV{'EMBOSS_PGS'})) {
	    next if ($DONT{$command});
	    eval("use $command");
	    next if ($@);
	    $defs = $command->new;
	    $defs{$command} = $defs;
	    push (@l, $command);
	}
    } else {
	for (File::Listing::parse_dir(`ls -l $PERLDEFDIR/*.pm`)) {
	    ($name, $type, $size, $mtime, $mode) = @$_;
	    $command = $name;
	    $command =~ s/$PERLDEFDIR//;
	    $command =~ s/\.pm//;
	    $command =~ s/\///;
	    next if ($DONT{$command});
	    eval("use $command");
	    next if ($@);
	    $defs = $command->new;
	    $defs{$command} = $defs;
	    my @categories;
	    eval {
		@categories = map { getmaincat($_) } @{ $defs->categories };
		print STDERR "command: $command\t", join(", ",@categories), "\n";
	    };
	    next if ($@);
	    if (grep /$category/, @categories) {
		if ($not_category && (grep /$not_category/, @categories)) {
		    print STDERR "program $command belongs to $category (","@categories",") but $not_category also\n";
		    next;
		}
		print STDERR "program $command belongs to $category (","@categories",") \n";
		push @l, $command;
	    }
	}
    }
    #print STDERR "l: ", "@l", "\n";
    print_sewer(@l)

}

sub get_last_program_nb {
    my $program_nb;
    open (SEWER, $SEWER_FILE) || die "cannot open $SEWER_FILE:$!";
    while (<SEWER>) {
	if (/program\[(\d+)\]=new ProgramConstructor/) {
	    $nb = $1;
	    if ($nb > $program_nb) {
		$program_nb = $nb;
	    }
	} 
    }
    close (SEWER);
    if (! $program_nb) {
	$program_nb = -1;
    }
    return $program_nb;
}

sub print_sewer {
    my (@commands) = @_;
    my $section;
    my $section2;
    my $section3;
    my $section4;
    my $section5;
    my $last_program_nb = get_last_program_nb();
    open (SEWER, $SEWER_FILE) || die "cannot open $SEWER_FILE:$!";
    while (<SEWER>) {
	if (/END of Section/) {
	    if ($section == 2) {
		my $program_nb = $last_program_nb;
		foreach $command (@commands) {
		    print STDERR "doing sections for $command\n";
		    $defs = $defs{$command};
		    $program_nb++;
		    $section2 = gen_section2($program_nb);
		    print $section2;
		}
	    }
	    if ($section == 3) {
		my $program_nb = $last_program_nb;
		foreach $command (@commands) {
		    $defs = $command->new;
		    $program_nb++;
		    $section3 = gen_section3($program_nb);
		    print $section3;
		}
	    }
	    if ($section == 4) {
		my $program_nb = $last_program_nb;
		foreach $command (@commands) {
		    $defs = $command->new;
		    $program_nb++;
		    $section4 = gen_section4($program_nb);
		    $section5 = gen_section5($program_nb);
		    print $section5;
		    print $section4;
		}
	    }
	}
	if (/included_programs="(.*)"/ && $section == 1) {
	    my @programs = split(",",$1);
	    push (@programs, @commands);
	    print STDERR "section1\n", join("\n",@programs),"\n";
	    $section1 = gen_section1(@programs);
	    print $section1;
	} else {
	    print;
	}
	chomp;
	if (/Section \#1 /) {
	    $section = 1;
	} 
	if (/Section \#2 /) {
	    $section = 2;
	    
	} 
	if (/Section \#3 /) {
	    $section = 3;
	} 
	if (/Section \#4 /) {
	    $section = 4;
	} 
    }
    close (SEWER);
}

sub gen_section1 {
    my (@programs) = @_;
    my $result;
    $result = "<!--included_programs=\"" . join(",",@programs) . "\"-->\n";
    return $result;
}

sub get_query {
    foreach my $param ($defs->by_group_parameters) {
	if ($defs->type($param) eq "Sequence" && $defs->ismandatory($param) && $defs->issimple($param)) {
	    return $param;
	}
    }
}    

sub get_mandatory {
    my @l;
    foreach my $param ($defs->by_group_parameters) {
	if ($defs->ismandatory($param)) {
	    push (@l, $param);
	}
    }
    return @l;
}    

sub get_doc_link {
    if ($defs->doclink) {
	$doclink = $defs->doclink;
    } else {
	my $doc_aname = $defs->title;
	$doc_aname =~ s/-//g ; 
	$doc_aname =~ s/\://g ;
	$doc_aname =~ tr/a-z/A-Z/ ;
	$doclink = "http://bioweb.pasteur.fr/docs/softgen.html#$doc_aname";
    }
    return $doclink;
}

sub gen_section2 {
    my $program_nb = $_[0];
    my $result = "";
    my $query = get_query();
    my $doclink = get_doc_link();

    $MAINWEBPAGE = "http://bioweb.pasteur.fr";

    $result = "program[$program_nb]=new ProgramConstructor(\"$command\",\"$MAINWEBPAGE\",\"$CGI_URL/$command.pl\",\"$doclink\",\"${query}_data\",\"post\",\"application/x-www-form-urlencoded\")\n";
    $result .= "option[$program_nb]=new makeOption(\"$command\")\n";
    $result .= "description[$program_nb]=new makeDescription(\"$command\")\n\n";
    return $result;
}

sub gen_section3 {
    my $program_nb = $_[0];
    my $result = "";
    $result .= "	<option value=\"$command\">";
    if ($TITLE) {
	$result .= $TITLE . "\n";
    } else {
	$result .= $defs->title . "\n";
    }

    return $result;
}

sub gen_section4 {
    my $program_nb = $_[0];
    my $result = "";
    my $title = $defs->title;
    my $doclink = get_doc_link();

    my $description = $defs->description;
    my $query = get_query();
    $input_type = $defs->prompt($query);
    my $mandatory = join (" ",get_mandatory());

    my $program_link = $ROOT_HTML_FORM . "/$command.html";

    $result .= "
<div id=\"${command}description\" class=\"description\">
<table border=\"0\" cellpadding=\"0\" cellspacing=\"0\" width=\"204\">
<tr>
<td class=\"size2\"><img height=\"8\" width=\"8\" src=\"images/redear.png\"><b>$title</b></td>
<td align=\"right\"><a href=\"$program_link\" target=\"_blank\"><img border=\"0\" height=\"12\" width=\"32\" src=\"images/more_grey.png\"></a></td>
</tr>
<tr><td height=\"1\" colspan=\"2\" bgcolor=\"#cccccc\"><spacer type=\"block\" width=\"32\" height=\"1\"></td></tr><tr><td colspan=\"2\" class=\"size1\">$description. Input type: $input_type. ";
    if ($mandatory) {
	$result .= "<br>Required options: email $mandatory.";
    }
    $result .= "</td></tr></table></div>\n";
    return $result;
}

sub gen_section5 {
    my $program_nb = $_[0];
    my $result = "";
    my $title = $defs->title;

    $result .= "
<div id=\"${command}option\" class=\"optionlist\">
<form name=\"${command}form\">
<table width=\"600\" border=\"0\" bgcolor=\"#e6e6e6\" cellpadding=\"5\" cellspacing=\"5\">
<tr><td class=\"size1\"><p class=\"size2\"><font color=\"#cc0000\"><b>$command</b></font></p>

<input type=\"hidden\" name=\"Title\" value=\"$title\">
<input type=\"hidden\" name=\"Cmd\" value=\"$command\">
";

    $result .= do_email();  
    print STDERR "result before params:\n$result\n\n";
    $result .= do_parameters($defs->by_group_parameters); 
    $result .= "</td></tr></table>
</form></div>
";
    return $result;
}

sub do_email {
    return "Your email: <input type=\"text\" size=\"40\" name=\"email\" value=\"\"><p></p>\n";
}

sub do_parameters {
    my (@parameters_list) = @_ ;

    my $result;
    my $query = get_query();

    foreach my $param (@parameters_list) {
	next if ($defs->type($param) eq "Results");
	next if ($defs->type($param) eq "Paragraph");
	next if ($param eq $query);
	$result .= do_one_param($param);
    }

    return $result;

}

sub do_one_param {
    my $param = $_[0];
    my $type = $defs->type($param);
    my $vdef;

    if ($param eq "init" && $defs->ishidden($param)) {
	# EMBOSS init section
	return "";
    }

    if ($defs->ishidden($param)) {
	return do_hidden_param($param);
    } 

    my $result = "<p>";
    if ($type eq "OutFile") {
	$result .= "<b>" . $defs->prompt($param) . "</b>" ;
	if ( defined $defs->vdef($param)) {
	    $vdef = $defs->vdef($param);
	    $result .= "<input name=\"$param\" value=\"$vdef\">\n";
	} else {
	    $result .= "<input name=\"$param\">\n";
	}
    }  elsif ($type eq "InFile" || $type eq "Sequence")  {
	my $paramdata = $param . "_data";
	$result .=  "<br><textarea name=\"$paramdata\" rows = 10 cols = 50></textarea>\n <b>" . $defs->prompt($param) . "</b>\n";
    }  elsif ($type eq "Switch")  {
	if (defined $defs->vdef($param) && $defs->vdef($param)) {
	    $vdef = "CHECKED";
	} else {
	    $vdef ="";
	}
	$result .= "<input type=\"checkbox\" name=\"$param\" $vdef><b>" . $defs->prompt($param) . "</b>\n";
    } elsif ($type eq "Excl") {
	$result .= "<b>" . $defs->prompt($param) . "</b>";
	$result .= "<br><select name=\"$param\">\n";	
	$i=0;
	@values = $defs->vlist($param) ;
	$vdef = $defs->vdef($param);
	while ($i <= $#values) {
	    my $value= $values[$i];
	    my $prompt=$values[$i+1];
	    if ($value eq $vdef && $value) {
		$result .= "<option selected value=\"$value\"> $prompt\n";
	    } else {
	        # hack for bug? in SeWer when default is displayed
	        # as prompt, and also passed as value (it should not?)
                if ($prompt eq "default") {
			$result .= "<option value=\"$value\"> \n";
		} else {
			$result .= "<option value=\"$value\"> <b>$prompt</b>\n";
		}
	    }
	    $i+=2;
	}
	$result .= "</select>\n";		

    } elsif ($type eq "Integer" || $type eq "Float") {
	$result .=  "<input name=\"$param\" value=\"" . $defs->vdef($param) . "\"> <b>" . $defs->prompt($param) . "</b>\n"; 

    } elsif ($type eq "String") {
	my $size;
	if (defined $defs->size($param) ) {
	    $size="size=" . $defs->size($param);
        } else {
	    if ( defined $defs->vdef($param) && $defs->vdef($param) ne "" && length($defs->vdef($param)) > 20) {
	        $size="size=" . length($defs->vdef($param));
	    } else {
	        $size="";
	    }
        }
	if ($size) {
	    $result .= "<input name=\"$param\" size=\"$size\" value=\"" . $defs->vdef($param) . "\"> <b>" . $defs->prompt($param) . "</b>\n";
	} else {
	    $result .= "<input name=\"$param\" value=\"" . $defs->vdef($param) . "\"> <b>" . $defs->prompt($param) . "</b>\n";
	}

    }

    $result .= "</p>\n";
    print STDERR "result ($param)\n\t$result\n\n";
    return $result;
}
sub do_hidden_param {
    my $param = $_[0];
    my $result = "";
    my $vdef = $defs->vdef($param);
    $result .= "\n<input name=\"$param\" type=\"hidden\" value=\"$vdef\">\n";

    return $result;
}

1;


