# object for *one* pise job

#
# TODO
#

#use lib "/local/gensoft/inst/Pise/5.a/PerlDef";
use lib "/local/gensoft/lib/Pise/5.a/PerlDef";

use XML::Parser::PerlSAX;
use LWP::UserAgent;
use PiseJobParser;

package pisejob;

sub new {
    my $proto = shift;
    my $command;
    if (@_) {
	$command = shift;
    }
    if (@_) {
	$self->{VERBOSE} = shift;
    } else {
	$self->{VERBOSE} = 0;
    }
    my $class = ref($proto) || $proto;
    my $self  = {};

#    $self->{VERSION}   = "5.a";
    $self->{VERSION}   = "5.a";
#    my $PISEDIR="/local/gensoft/inst/Pise/5.a";
    my $PISEDIR="/local/gensoft/lib/Pise/5.a";
    require "$PISEDIR/lib/web.pl";
    $self->{PISEDIR} = $PISEDIR;

    # web.pl
    $self->{SEQANAL_CGI} = $CGI_URL;
    $self->{BIOWEB_RESULTS} = $tmp_url;

    $self->{COMMAND} = undef;
    $self->{COMMAND_OBJECT} = undef;

    $self->{JOBID} = undef;
    $self->{ERROR} = undef;
    $self->{ERROR_MESSAGE} = undef;
    $self->{TERMINATED} = 0;
    $self->{ARGS} = undef;
    $self->{RESULT_FILES} = undef;
    $self->{RESULTS} = undef;
    $self->{SCRATCH_DIR} = undef;
    $self->{DEBUG} = 0;
    $self->{PIPES} = {};
    $self->{PIPED_FILE_TYPE} = {};

    bless ($self, $class);

    if ($command) {
	$self->init($command);
    }
    return $self;

}

sub usage {
    my $self = shift;
    my $PISEDIR = $self->{PISEDIR};

    print "

    Commands:

      pisejob                get this message
      pisejob command        legal parameters for command

    Programming:

      # Create a new job
      \$job = pisejob->new(\"command\");

      # set parameter param to value
      \$job->args(\"param\",\"value\");

      # return -1 when illegal parameter name (and display list of 
      # legal parameters)
      # legal parameter names may be display by calling args without arguments
      \$job->args;

      # set parameter infile (\"my_sequence.seq\ is the name of a file)
      \$job->args(\"infile\",\"my_sequence.seq\");
      # set the same parameter infile, \$seq is a string
      # the parameter name *must be* suffixed by _data
      \$job->args(\"infile_data\",\$seq);

      # pipe parameters :infile parameter is initialized by the content 
      # of file \"outfile\" from a previous job
      \$job->args(\"infile_data\",\$previous_job->output(\"outfile\"));

      # submit
      \$jobid = \$job->submit;
      
      # monitor execution and get results

      # Web interface errors
      if (\$job->error) {
           print STDERR \$job->error_message;
      }

      # getting results
      if (\$job->terminated(\$jobid)) {
         foreach my \$result (\$job->get_results(\$jobid)) {

            # print output file
            print \$job->output(\$result);
            # or save it
            #   - save return the name of the file actually saved
            #   - save and output take an url or a filename as argument
            my \$file = \$job->save(\$result);    
            \$job->save(\$result,\"result.txt\");

            # which programs are connected to this result?
            \$job->get_pipes(\$result);
            # what is the connection type of this file?
            # eg phylip_tree, blast_output, pdbfile, ...
            # see $PISEDIR/PerlDef/pipeins
            \$job->piped_file_type(\$result);
         }
      }

      # using an already finished job
      \$job->get_job(\$jobid);
      print \$job->output(\$result);

      # utilities
      \$job->jobid;  # current jobid 
                    # eg: $tmp_url/command/xxxxx/
      \$job->param_type(\"param\");  # Integer, String, Sequence, InFile, ...
      \$job->parse(\$html_content);  # parse a bioweb result document

";
}

sub init {
    my $self = shift;
    my $command = shift;
    if (@_) {
	$self->{VERBOSE} = shift;
    }
    eval ("use $command;");
    if ($@) {
	print STDERR "init: problem using $command\n";
	return -1;
    }
    my $defs = $command->new;
    $self->{COMMAND} = $command;
    $self->{COMMAND_OBJECT} = $defs;
}

sub jobid {
    my $self = shift;
    if (@_) {   $self->{JOBID} = shift ;    }
    return $self->{JOBID} ;  
}

sub args {
    my $self = shift;

    if (! defined $self->{COMMAND}) {
	print STDERR "args: init not done\n";
	return -1;
    }
    my $defs = $self->{COMMAND_OBJECT};
    my $prompt;
    if (! @_) {
	foreach my $param ($defs->parameters_order) {
	    $prompt = $defs->prompt($param);
	    if ($prompt) {
		print "$param\t\t$prompt\n";
	    }
	}
	return;
    }
    if (defined $self->{JOBID}) {
	print STDERR "args: this job has been already setup and launched\n";
	return -1;
    }
    if (@_) {
	my $param = shift;
	my $p = $param;
	if ($p =~ /_data$/) {
	    $p =~ s/_data$//;
	} 
	if ($param ne "email") {
	    if ( ! (grep { $_ eq $p } $defs->parameters_order) ) {
		if ($param =~ /_data$/) {
		    if ( ! (grep { $_ eq $param } $defs->parameters_order) ) {
			print STDERR "$param: this parameter does not exist for ", $self->{COMMAND}, "\n";
			print STDERR "Parameters allowed:\n";
			my $prompt;
			foreach my $p ($defs->parameters_order) {
			    $prompt = $defs->prompt($p);
			    if ($prompt) {
				print "$p\t\t$prompt\n";
			    }
			}
			return -1;
		    }
		} else {
		    print STDERR "$param ($p): this parameter does not exist for ", $self->{COMMAND}, "\n";
		    print STDERR "Parameters allowed:\n",join("\n",$defs->parameters_order),"\n";
		    return -1;
		}
	    }
	}
	$self->{ARGS}{$param} = shift;
	print STDERR "args: $param set to ", $self->{ARGS}{$param}, "...\n"  if $self->{VERBOSE};
    } else {
	$self->{ARGS} = shift;
    }
}

sub param_type {
    my $self = shift;
    my $param = shift;
    my $command_object = $self->{COMMAND_OBJECT};
    my $type;
    if ($param =~ /_data$/) {
	my $p;
	($p = $param) =~ s/_data//;
	$type = $command_object->type($p) ;
#	print STDERR "param: $param => $p type=$type\n" if ($self->{DEBUG});
    } else {
	$type = $command_object->type($param) ;
	$value = $self->{ARGS}{$param};
    }
    return $type;
}

sub submit {
    my $self = shift;
    if (! defined $self->{COMMAND}) {
	print STDERR "submit: init not done\n";
	return -1;
    }
    if (defined $self->{JOBID}) {
	print STDERR "submit: this job has been already setup and launched\n";
	return -1;
    }

    my $cgi = $self->{SEQANAL_CGI} . "/" . $self->{COMMAND} . ".pl";

    my $command_object = $self->{COMMAND_OBJECT};
    my $type;
    my %content;

    foreach $param (keys %{ $self->{ARGS} }) {
	$type = $self->param_type($param);
        $value = $self->{ARGS}{$param};
	if ($type eq "InFile" || $type eq "Sequence") {
	    if ($param !~ /_data$/) {
		stat($value);
		if (-e _) {
		    $content{$param} = [$value];
#		    print STDERR "$param: file\n" if ($self->{DEBUG});
		} else {
		    $content{$param} = $value;
#		    print STDERR "$param: not file (1)\n" if ($self->{DEBUG});
		}
	    } else {
		$content{$param} = $value;
#		print STDERR "$param: not file (2)\n$value" if ($self->{DEBUG});
	    }
	} elsif ($type eq "Switch") {
	    if ($value) {
		$content{$param} = "on";
	    }
	} else {
	    $content{$param} = $value;
	}
	
#	print STDERR "$param ($type): $content{$param}\n" if ($self->{DEBUG});;
    }
    
    foreach $param ($command_object->parameters_order) {
	$type = $self->param_type($param) ;
	if ($type eq "Switch") {
	    if (! defined $self->{ARGS}{$param}) {
		$vdef = $command_object->vdef($param) ;
		if ($vdef) {
		    $content{$param} = "on";
		}
#		print STDERR "$param ($type): $content{$param}\n" if ($self->{DEBUG});;
	    }
	}
    }

    if ($self->{DEBUG}) {
	foreach my $p (keys %content) {
	    $type = $self->param_type($p) ;
	    print STDERR "$p ($type): $content{$p}\n";
	}
    }

    print STDERR "submitting request...\n"  if $self->{VERBOSE};

    use HTTP::Request::Common;
    use LWP::UserAgent;
    my $ua = new LWP::UserAgent;
    my $version = $self->{VERSION};
    $ua->agent("Pise/$version " . $ua->agent);

    my $res = $ua->request(POST $cgi,
			   Content_Type => 'form-data', 
			   Content      => \%content);

    if ($res->is_success) {
#	if ($self->{DEBUG}) {
#	    print STDERR "submit:\n", $res->content;
#	}
	$self->{RESULTS} = $res->content;
	if ($self->parse($res->content) >= 0) {
	    return $self->get_jobid;
	} else {
	    print STDERR "submit, parse error:\n", $res->content;
	    return -1;
	}
    } else {
        print STDERR "Bad luck this time\n";
	$self->{TERMINATED} = 1;
	return undef;
    }
}

sub parse {
    my $self = shift;
    my $content;
    if (@_) {
	$content = shift;
    } elsif (defined $self->{RESULTS}) {
	$content = $self->{RESULTS};
    } else {
	print STDERR "parse: you must provide the CGI results page\n";
	return -1;
    }
    my $handler;
    if ($self->{VERBOSE}) {
 	$handler = PiseJobParser->new(1);
   } else {
	$handler = PiseJobParser->new;
    }
    $parser = XML::Parser::PerlSAX->new  (Handler => $handler);
    $self->{PARSER} = $parser;
    $content = $self->clean_content($content);
    eval {$parser->parse ($content)};

    if ($@) {
	print STDERR "parse: cannot parse this job:\n$@\n";
	print STDERR $content;
	return -1;
    } else {
	$self->{JOBID} = $self->{BIOWEB_RESULTS} . "/" . $PiseJobParser::scratch_dir;
	$self->{SCRATCH_DIR} = $PiseJobParser::scratch_dir;
	my @results_files = @PiseJobParser::hrefs;
	$self->{RESULT_FILES} = [@results_files];
	foreach my $result (@results_files) {
	    $self->{PIPED_FILE_TYPE}{$result} = $handler->piped_file_type($result);
	}
	my %pipes = $handler->pipes;
	foreach my $f (keys %pipes) {
	    my @p = @{ $pipes{$f} };
	    foreach my $p (@p) {
		push (@{$self->{PIPES}{$f}}, $p);
	    }
	}
	$self->{TERMINATED} = $PiseJobParser::terminated;
	if ($PiseJobParser::error) {
	    $self->{ERROR} = $PiseJobParser::error;
	    $self->{ERROR_MESSAGE} = $PiseJobParser::error_message;
	    print STDERR "An error as occured (", $self->{COMMAND}, ") : $PiseJobParser::error_message\n";
	}
	print STDERR "parsing done...\n"  if $self->{VERBOSE};
    }

}

sub error {
    my $self = shift;
    return $self->{ERROR};
}

sub error_message {
    my $self = shift;
    return $self->{ERROR_MESSAGE};
}

sub get_jobid {
    my $self = shift;
    if (! defined $self->{COMMAND}) {
	print STDERR "get_jobid: init not done\n";
	return -1;
    }
    if (defined $self->{JOBID}) {
	return $self->{JOBID};
    } else {
	print STDERR "get_jobid: parse not done\n";
	return -1;
    }

}

sub get_results {
    my $self = shift;
    my $jobid;
    if (@_) {
	$jobid = shift;
    } else {
	if (! defined $self->{JOBID}) {
	    print STDERR "get_results: parse not done\n";
	    return -1;
	}
    }
    return @{ $self->{RESULT_FILES} };
}

sub get_job {
    my $self = shift;
    my $jobid = shift;
    if (@_) {
	$self->{VERBOSE} = shift;
    }

    use HTTP::Request::Common;
    my $ua = LWP::UserAgent->new;
    my $version = $self->{VERSION};
    $ua->agent("Pise/$version " . $ua->agent);
    my $res = $ua->request(GET $jobid);

    if ($res->is_success) {
	$self->{RESULTS} = $res->content;
	$self->parse($res->content);
    } else {
	return undef;
    }

}

sub get_pipes {
    my $self = shift;
    my $result_file = shift;
    my $jobid;
    if (@_) {
	$jobid = shift;
    } else {
	if (! defined $self->{JOBID}) {
	    print STDERR "get_pipes: parse not done\n";
	    return -1;
	}
    }
    my %pipes = %{ $self->{PIPES}};
    if (defined $pipes{$result_file}) {
	my @pipes = @{ $pipes{$result_file} };
	return @pipes;
    } else {
	return $pipes{$result_file};
    }
}

sub piped_file_type {
    my $self = shift;
    my $result_file = shift;
    my $jobid;
    if (@_) {
	$jobid = shift;
    } else {
	if (! defined $self->{JOBID}) {
	    print STDERR "piped_file_type: parse not done\n";
	    return -1;
	}
    }
    return $self->{PIPED_FILE_TYPE}{$result_file};
}

sub terminated {
    my $self = shift;
    my $jobid;
    if ($self->{TERMINATED}) {
	return 1;
    }
    if (@_) {
	$jobid = shift;
    } else {
	if ($self->{JOBID}) {
	    $jobid = $self->{JOBID};
	} else {
	    print STDERR "terminated: you must provide the jobid\n";
	    return 0;
	}
    }
    $self->get_job($jobid);
    if ($self->{TERMINATED}) {
	return 1;
    } else {
	return 0;
    }
}

sub save {
    my $self = shift;
    my $jobid;
    my $url;
    my $file;
    my $result;

    if (! $self->{TERMINATED}) {
	if (@_) {
	    $jobid = shift;
	} else {
	    if ($self->{JOBID}) {
		$jobid = $self->{JOBID};
	    } elsif (! defined $self->{COMMAND}) {
		print STDERR "output: init not done\n";
		return -1;
	    } elsif (defined $self->{COMMAND} && ! defined $self->{JOBID}) {
		print STDERR "output: you must run the job first\n";
		return -1;
	    } else {
		print STDERR "output: you must provide the jobid\n";
		return -1;
	    }
	}
	$self->get_job($jobid);
	if (! $self->{TERMINATED}) {
	    print STDERR "output: your job is not finished\n";
	    return -1;
	}
    }
    if (@_) {
	$result = shift;
    } else {
	print STDERR "save: you must provide the result name\n";
	return -1;
    }
    if (@_) {
	$file = shift;
    } else {
	$file = $result;
	if ($file =~ /http/) {
	    $file =~ s/$tmp_url//;
	    if (defined $self->{COMMAND}) {
		my $cmd = $self->{COMMAND};
		$file =~ s/$cmd//;
		$file =~ s/\d+\///;
		$file =~ s/\///g;
	    } else {
		$file =~ s/\w+\/\d+\///;
		$file =~ s/\///g;
	    }
	}
    }

    $ua = new LWP::UserAgent;
    my $version = $self->{VERSION};
    $ua->agent("Pise/$version " . $ua->agent);

    foreach $url (@{ $self->{RESULT_FILES}}) {
	if ($self->{DEBUG}) {
	    print STDERR "DEBUG> pisejob output: $url (",$self->{COMMAND},")\n";
	}
	if ($url =~ /$result/) {
	    $res = $ua->request(GET $url);
	    
	    if ($res->is_success) {
		open(FILE,"> $file") || die "cannot open $file: $!";
		print FILE $res->content;
		close FILE;
		return $file;
	    } else {
		print STDERR "Cannot get $url\n";
		return -1;
	    }
	}
    }
}

sub output {
    my $self = shift;
    my $jobid;
    my $url;
    my $file;

    if (! $self->{TERMINATED}) {
	if (@_) {
	    $jobid = shift;
	} else {
	    if ($self->{JOBID}) {
		$jobid = $self->{JOBID};
	    } elsif (! defined $self->{COMMAND}) {
		print STDERR "output: init not done\n";
		return -1;
	    } elsif (defined $self->{COMMAND} && ! defined $self->{JOBID}) {
		print STDERR "output: you must run the job first\n";
		return -1;
	    } else {
		print STDERR "output: you must provide the jobid\n";
		return -1;
	    }
	}
	$self->get_job($jobid);
	if (! $self->{TERMINATED}) {
	    print STDERR "output: your job is not finished\n";
	    return -1;
	}
    }
    if (@_) {
	$file = shift;
    } else {
	$file = '.out';
    }

    $ua = new LWP::UserAgent;
    my $version = $self->{VERSION};
    $ua->agent("Pise/$version " . $ua->agent);

    foreach $url (@{ $self->{RESULT_FILES}}) {
	if ($self->{DEBUG}) {
	    print STDERR "DEBUG> pisejob output: $url (",$self->{COMMAND},")\n";
	}
	if ($url =~ /$file/) {
	    if ($self->{DEBUG}) {
		print STDERR "DEBUG> pisejob output: this one!\n";
	    }
	    $res = $ua->request(GET $url);
	    
	    if ($res->is_success) {
		return $res->content;
	    } else {
		print STDERR "Cannot get $url\n";
		return -1;
	    }
	}
    }
}

sub results_type {
    my $self = shift;
    my $results_type;
    my $jobid;
    if ($self->{TERMINATED}) {
	print STDERR "results_type: job already terminated\n";
	return 0;
    }
    if (@_) {
	$results_type = shift;
    } else {
	$results_type = "url";
    }
    if (@_) {
	$jobid = shift;
    } elsif ($self->{JOBID}) {
	$jobid = $self->{JOBID};
    } else {
	print STDERR "results_type: you must provide a jobid\n";
	return -1;
    }
    
    my $scratch_dir = (defined $self->{SCRATCH_DIR}) ? $self->{SCRATCH_DIR} : "" ;
    my $command = (defined $self->{COMMAND}) ? $self->{COMMAND} : "";
    if ($command eq "") {
	($command = $jobid) =~ s/http.+\/(\w+)\/\d+/$1/;
    }
    if ($scratch_dir eq "") {
	($scratch_dir = $jobid) =~ s/http.+\/(\d+)/$1/;
	$scratch_dir = "$command/$scratch_dir";
    }

    use HTTP::Request::Common;
    my $ua = LWP::UserAgent->new;
    my $version = $self->{VERSION};
    $ua->agent("Pise/$version " . $ua->agent);
    my $cgi = $self->{SEQANAL_CGI} . "/lib/results.pl";
    my $res = $ua->request(POST $cgi, [command => $command, email => $ENV{'USER'}, results_type => $results_type, scratch_dir => $scratch_dir, PISEDIR => $self->{PISEDIR}]);

    if ($res->is_success) {
	return 1;
    } else {
	return -1;
    }
}

sub clean_content {
    my $self = shift;
    my $content = shift;

    $content =~ s/\&/\&amp;/g;
#    $content =~ s/</&lt;/g;
#    $content =~ s/>/&gt;/g;
    my $title;
    my $head;
    my $foot;
#    if ($content !~ /<\?xml/) {
#	$head = "<?xml version=\"1.0\" encoding=\"iso-8859-1\"?>\n";
#    }
    if ($content !~ /DOCTYPE/) {
	$head .= "<!DOCTYPE html PUBLIC \"-//W3C//DTD XHTML 1.0 Strict//EN\"
    \"http://www.w3.org/TR/xhtml1/DTD/strict.dtd\">\n";
    }
    if ($content !~ /<html>/i) { 
	if (defined $self->{COMMAND_OBJECT}) {
	    my $command_object = $self->{COMMAND_OBJECT};
	    $title = $command_object->title;
	} else {
	    $title = "unknown title";
	}
	$head .= "<HTML>
<HEAD><TITLE>$title</TITLE><h1>$title</h1>
</HEAD>
<BODY>
";
    }
    $content = $head . $content;

    if ($content !~ /<\/html>/i) {
	$foot = "
</BODY></HTML>
";
	$content = $content . $foot;
    }
#    print STDERR "clean_content:\n",$content;

    return $content;

}


1;
