#! /local/bin/perl
#
# send biok code for program
# 

use CGI;

$request=new CGI;

$command=$request->param('command');
$level=$request->param('level');
print $request->header(-type=>'text/plain');

$VERSION="5.a";
$PISEDIR="/local/gensoft/lib/Pise/$VERSION";
$ENV{'VERSION'}=$VERSION;
$ENV{'PISEDIR'}=$PISEDIR;
print STDERR "request for $command make-biok\n";
$make_biok= "perl $PISEDIR/Maker/make-biok.pl";
$make_biok .= " $command"; 
if (defined $level) {
    #print STDERR "level: $level\n";
    $make_biok .= " $level"; 
}
open (BIOK,"$make_biok |") || die "cannot run $make_biok:$!";
$i=0;
while (<BIOK>) {
    print;
    $i++;
}
close(BIOK);
print STDERR "$i line(s) read\n";
