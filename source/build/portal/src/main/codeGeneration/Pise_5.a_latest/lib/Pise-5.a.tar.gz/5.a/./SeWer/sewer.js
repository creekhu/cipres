var program, option; 
var isOptionOpen=false;
var isNS4, isIE4;
isNS4=(document.layers)?true:false;
isIE4=(document.all)?true:false;

imageA=new Image();
imageA.src="images/optionoff.png"

imageB=new Image();
imageB.src="images/optionon.png"

function ProgramConstructor(name,url,cgi,helpPage,id,method,encoding){
	this.name=name;
	this.url=url;
	this.help=helpPage;
	//this.cgi=cgi;
	this.id=id;
	this.method=method;
	this.encoding=encoding;
	this.action=cgi;
	//this.action=makeurl;
	//this.openResultWindow=openresult;
	return this;
	}
//function makeurl(){
//		 u=this.url+this.cgi;
//		 return u;
//		 }
function makeOption(name){
	
	this.name=name;
	this.css=(isNS4)?eval('document["'+name+'"]'):eval('document.all.'+name+'.style');
	
	this.f=(isNS4)?eval('document["'+name+'"].document.'+name+'form'):eval('document.'+name+'form');
	//lert("before des");
	//var m=name+'description';
	//alert(m);
	//this.d=(isNS4)?eval('document.'+m):eval('document.all.'+name+'description.style');
	this.hideit=hideit;
	this.showit=showit;
	this.vis=vis;
	return this;
	}
function showit(){
	this.css.visibility="visible"
	//this.d.visibility="visible";
	}
function hideit(){
	this.css.visibility="hidden"
	//this.d.visibility="hidden"
	}
function vis(){
	if(this.css.visibility=="hidden"||this.css.visibility=="hide") return true;
}	

function makeDescription(name){
	//alert("within description");
	this.name=name+'description';
	this.css=(isNS4)?eval('document.'+name+'description'):eval('document.all.'+name+'description.style');
	//alert(this.css);
	this.hideit=hideit;
	this.showit=showit;
	this.vis=vis;
	return this;
	}
function whichProgram(){
name=(document.programchoice.program[document.programchoice.program.selectedIndex].value);
for(var i=0;i<program.length;i++){
	if(program[i].name==name){
		//alert("Got It");
		return i;
		break;
		}
	}
}

function programSelect(){
	writeprogrambanner();
	showDescription();
	if(isOptionOpen){showhide();
	 isOptionOpen=true;}
	}

function writeprogrambanner(){
	index=whichProgram();
	//v="<H2><font color='#cc0000' face='Verdana, Helvetica, Arial, Sans-Serif'>"
v='<p class="heading">'	
v +=program[index].name
	//v+="</font></H2>"
v +="</p>"
//alert(v)	
writeDiv(v,"programbanner");
	}
	
function writeDiv(content,divid){
	if(isNS4){
		document.layers[divid].document.open()
		document.layers[divid].document.write(content);
		document.layers[divid].document.close();}
		else{document.all[divid].innerHTML=content}
		}
function whichOption(){
	index=whichProgram();
	for(i=0;i<option.length;i++){
		if(option[i].name==program[index].name){
			break;
			}
		}
	//alert ("Ha Ha" +i);
	return i;
	
	}
		
function optionCheck(obj){
	var i=0;
	i=parent.frames[1].document.forms[0].elements.length;
	//alert("Element"+i);
	return i;
	}

function check(ch){
        var v=new Array();
		var elname=new Array();
		var elvalue=new Array();
		index=whichOption();
		//alert(option[index].f)
		pgindex=whichProgram();
		num=option[index].f.elements.length
		//alert(num)
	
		elname[0]=program[pgindex].id;
		elvalue[0]=document.query.elements[0].value;
	
		for(i=0; i<num;i++){
				n=option[index].f.elements[i].name;
				v=getElementValue(option[index].f.elements[i])
				if(v[0]){
					if(v.length>1){
				 	//alert("V greater than 1"+v.length);
				 	for(j=0;j<v.length;j++){
						elname[elname.length]=n;
						elvalue[elvalue.length]=v[j];}
						}
					else{
				 		elname[elname.length]=n;
				 		elvalue[elvalue.length]=v[0];
						}
				 }
				 }
			
		//elname[elname.length]=program[index].id;
		//elvalue[elvalue.length]=document.form1.sequence.value;
				 //alert(elname.length);
				 //alert(elvalue.length);
		if(ch=="submit"){
		openResult(program[pgindex],elname,elvalue);}
		else{
		customize(program[pgindex],elname,elvalue);
			}
		}
function getElementValue(formObject){
		var value=new Array();
		 if (formObject.type=="radio"){
			if(formObject.checked){
				value[0]=formObject.value;
				
				}
			return value;
			}
		if(formObject.type=="checkbox"){
			if(formObject.checked){
				value[0]=formObject.value;}
				
				return value;
				}
		if(formObject.type=="select-one"){
				//alert("I am select")
				value[0]=formObject[formObject.selectedIndex].value;
				if((value[0]=="")||(value[0]==null)){
					value[0]=formObject.options[formObject.options.selectedIndex].text
					}
				return value
				}
		if(formObject.type=="select-multiple"){
			//alert("select-multi found")
			for(i=0;i<formObject.options.length;i++){
				if(formObject.options[i].selected){
				value[value.length]=formObject.options[i].text
					//alert(value[i]);
					}
					}
			return value;
			}
		else {value[0]=formObject.value;
		return value;}
		}

function clearForm(){
	document.forms["query"].elements[0].value="";
	}

function customize(theprogram,n,value){
	
	vardate=new Date();
	resultWindow=window.open("","resultwindow","menubar=1,resizable=1,scrollbars=1,width=650,height=400");
	resultWindow.focus();
	v ="<html><head><title>SeWeR: customized "+theprogram.name+"</title>\n"
	v+='<style>\n.size0 { font-size: x-small; font-family: Verdana, Arial, Sans-Serif }\n.size1 {font-size: small; font-family: Verdana, Arial, Sans-Serif }\n.size2 { font-size: medium; font-family: Verdana, Arial, Sans-Serif }\na { color: #cc0000 }\n</style>\n</head>\n<body bgcolor="white" topmargin="0" leftmargin="0" marginheight="0" marginwidth="0" alink="#cc0000" vlink="#cc0000" link="#cc0000">';
	
	v+='\n<table border="0" cellpadding="0" cellspacing="0" width="600">';
	v+='<tr><td width="10" rowspan="4" bgcolor="#cc0000">\n<spacer type="block" width="10" height="1"></td>\n<td width="20" rowspan="4">&nbsp;</td>\n<td width="570">';
	v+='<h2><font color="#cc0000" face="Verdana,Arial,Sans-Serif">'+theprogram.name+'</font></h2>\n';
	v+='<span class="size1"><b><a href="'+theprogram.url+'">'+theprogram.url+'</a></b></span><p>'
	
	v+='<span class="size2"><b>Generated by<font color="#cc0000"> SeWeR: Sequence Analysis using Web Resources</font></b></span><br>'
v+='<span class="size0">'+vardate.toLocaleString()+'</span>'
v+='<p><span class="size0"><b>Save this page on your computer. Please update this page regularly. Any change in the target service will cause a wrong-request to the server, that might cause server-overloading. Generate this page by SeWeR as frequently as possible.</b></span>' 
v+='<hr noshade size="1"></td>\n</tr>\n<tr>\n'
 v+='<form method="'+theprogram.method+'" action="'+theprogram.action+'" enctype="'+theprogram.encoding+'">\n';
 v+='<td width="570"><span class="size1"><b>Query</b></span><br>'
 v+='<textarea name="'+n[0]+'" cols="50" rows="4">'+value[0]+'</textarea><br><input type="submit" value="Submit"><input type="reset" value="Clear">'
for(i=1;i<n.length;i++){
	v+='<input type="hidden" name="'+n[i]+'" value="'+value[i]+'">\n'
	}
v+='<hr noshade size="1"></td></form>\n</tr>\n<tr>\n<td width="570" class="size1"><b>Customized for</b><p>'
v+='<span class="size0">'

for(i=1;i<n.length;i++){
v+='<b>'+n[i]+'</b>='+value[i]+'&#059 '
}
v+='</span></td>\n</tr>'
	v+='\n<tr><td width="570" class="size0">\n<hr noshade size="1"><font color="#666666">Copyright &copy; 2000 Malay K Basu</font><br><a href="mailto:curiouser@ccmb.ap.nic.in">curiouser@ccmb.ap.nic.in</a></td>\n</tr>\n</table>'
	v+='</body></html>'
	
	with(resultWindow){
	document.open()
	document.write(v);
	document.close();
	}
}
function openResult(theprogram,n,value){
		/*resultWindow=window.open("","resultwindow","menubar=1,resizable=1,scrollbars=1,width=650,height=400");
	resultWindow.focus();
	with(resultWindow){
	document.write(program[pgindex].action())}
	
		for(i=0;i<n.length;i++){
			resultWindow.document.write(n[i]);
			resultWindow.document.write("<br>")
			resultWindow.document.write(value[i])
			resultWindow.document.write("<br>")
			}*/
		//alert("before writediv")
		v="<form name='resultform' method='' action='' enctype='' target='_blank'>";
		for(i=0;i<n.length;i++){
			v+="<input type='hidden' name='' value=''>"}
		v+="</form>";
	writeDiv(v,"result");
	//alert("after writediv")
	if(isIE4){
	for(i=0;i<n.length;i++){
			document.resultform.elements[i].name=n[i];
			/*resultWindow.document.write(n[i]);
			resultWindow.document.write("<br>")
			resultWindow.document.write(value[i])
			resultWindow.document.write("<br>")*/
			}	
	for(i=0;i<value.length;i++){
		document.resultform.elements[i].value=value[i];
								//resultWindow.document.write(value[i]);
								}
	document.resultform.method=theprogram.method;
	document.resultform.action=theprogram.action;
	document.resultform.enctype=theprogram.encoding;
	document.resultform.submit();
	}
	if(isNS4){
			//alert("before submission")
		for(i=0;i<n.length;i++){
		document.layers['result'].document.forms['resultform'].elements[i].name=n[i];}
	for(i=0;i<value.length;i++){
		document.layers['result'].document.forms['resultform'].elements[i].value=value[i];}
	document.layers['result'].document.forms['resultform'].method=theprogram.method;
	document.layers['result'].document.forms['resultform'].action=theprogram.action;
	document.layers['result'].document.forms['resultform'].enctype=theprogram.encoding;
	document.layers['result'].document.forms['resultform'].submit();
	}	
		
}
function optiontoggle(){
	if(document.images["optiontoggle"].src==imageA.src){
		document.images["optiontoggle"].src=imageB.src}
		else{
			document.images["optiontoggle"].src=imageA.src}
	showhide();
	}
function showhide(){
	isOptionOpen=(isOptionOpen)?false:true;
	index=whichProgram();
	for(i=0;i<option.length;i++){
		if(option[i].name==program[index].name){
			if(option[i].vis()){option[i].showit();
				//option[i].css.z-index=300;
			}
			else option[i].hideit()
			}
		else option[i].hideit();
		}
		}
function showDescription(){
	//alert("Within ShowDescription");
	var index=whichProgram();
	var d=program[index].name+'description';
	//alert(d);
	for(i=0;i<description.length;i++){
		if(description[i].name==d){
			//alert("Description found");
			description[i].showit();
			}
			else{
				description[i].hideit();
			}
	}
}
function findhelp(){
	index=whichProgram();
	url=program[index].help;
	helpwindow=window.open(url,"help","menubar,scrollbars,top=0,left=0,width=600,height=500");
}
