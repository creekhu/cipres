from Pise import PiseFactory
from Bio.Emboss.Primer import PrimerSearchParser
import sys

parser = PrimerSearchParser()

factory = PiseFactory(email='letondal@pasteur.fr')

primersearch = factory.program('primersearch',
                               sequences = sys.argv[1],
                               primers = sys.argv[2],
                               verbose=1)

j=primersearch.run()
if j.error():
    print "Error: " + j.error_message()
else:
    j.verbose(0)
    print "Output:\n", j.content(".out")
    
    handle = j.fh('.out')
    record = parser.parse(handle)

    for key in record.amplifiers.keys():
        for e in record.amplifiers[key]:
            print "Length: ", e.length
            print "Info: ", e.hit_info

    handle.close()

