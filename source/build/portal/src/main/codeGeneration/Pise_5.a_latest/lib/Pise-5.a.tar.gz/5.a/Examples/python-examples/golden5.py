from Pise import PiseFactory

email = 'letondal@pasteur.fr'
query ='MALK_ECOLI'
db = "swissprot"

factory = PiseFactory(email=email)
golden = factory.program("golden",
                         location='http://bioweb.pasteur.fr/cgi-bin/seqanal/golden.pl',
                         verbose=1)
golden.param("query",query)
golden.param("db",db)
job = golden.run()

if job.error():
    print job.error_message()
else:
    print job.jobid()


