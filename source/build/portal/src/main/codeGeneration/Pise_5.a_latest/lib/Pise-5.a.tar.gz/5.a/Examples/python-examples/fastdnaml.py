#
# An example to run a non-default Web server.
#
from Pise import PiseFactory
import sys

factory = PiseFactory(location='http://kun.homelinux.com/cgi-bin/Pise/5.a/')
fastdnaml = factory.program("fastdnaml",
                            alignment=sys.argv[1],
                            frequencies=1, non_interleaved=1)
job=fastdnaml.run()
if job.error():
    print "error: ", job.error_message()
else:
    print job.jobid()
    print job.content('fastdnaml.out')



