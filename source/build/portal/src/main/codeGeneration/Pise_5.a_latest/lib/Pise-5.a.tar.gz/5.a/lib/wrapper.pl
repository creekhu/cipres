#! /local/bin/perl

use Fcntl ':flock';

open LOCK, '> .lock';
flock LOCK, LOCK_EX;
system "hostname > .host";
open CMDS, '< .command';
my $cmds = <CMDS>; chomp $cmds;
close CMDS;
my $res = system "$cmds";
flock LOCK, LOCK_UN;
close LOCK;

