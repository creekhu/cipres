## Databases Query System

## Get database entry using `seqret' application
sub get_dbentry {
  my ($db, $name) = @_;
  my $entry = '';
  
  my $date = localtime;
  $db = lc($db);
  
  print STDERR "Pise:db.pl> [$date] Fetching entry $name from $db ...\n";
  ## Proceed query (entry name or accession number)
  #open(IN, "seqret $db:$name -firstonly=true -stdout -auto 2>/dev/null |") or return '';
  open(IN, "golden $db:$name |") or return '';
  while(<IN>) { $entry .= $_; }
  close(IN);
  
  ## Checks for program or command line error
  if ($?) { 
    $entry = ''; 
    print STDERR "Pise:db.pl> [$date] entry $name from $db not found\n";
  } else {
    print STDERR "Pise:db.pl> [$date] entry $name from $db found\n";
  }
  
  return $entry; }

1;
