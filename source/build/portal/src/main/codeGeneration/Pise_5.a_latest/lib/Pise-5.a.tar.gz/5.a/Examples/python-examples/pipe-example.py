from Pise import PiseFactory
import sys
import Bio.Clustalw

alig = Bio.Clustalw.parse_file(sys.argv[1])          

factory = PiseFactory()
dnapars = factory.program('dnapars', infile=alig, print_treefile=True)
job = dnapars.run()
if job.error():
    print "Error: " + job.error_message()
    sys.exit(1)

print "Output:\n", job.content("outfile")
print "Job ID:\n", job.jobid()


drawtree = factory.program('drawtree')
j2 = drawtree.run(treefile = job.fh(job.lookup_piped_file('phylip_tree')))

if j2.error():
    print "Error: " + j2.error_message()
    sys.exit(1)

print "Job ID:\n", j2.jobid()





