#
# TODO : 
#

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";
 
package Maker;

# Settings

$command=$ARGV[0];

eval ("use $command;");
require "/local/gensoft/lib/Pise/5.a//Maker/make-html-utils.pl";
require "/local/gensoft/lib/Pise/5.a//lib/web.pl";


$defs = $command->new;

if (defined $ARGV[1]) {
    $required=$ARGV[1];
    require "$required";
}


&print_headers($defs, "advanced");
&print_one_param($defs, "advanced", "email","Mail",'top');
print "(<img src=\"$IMAGES_DIR/red-bullet.gif\"/> = required, <img src=\"$IMAGES_DIR/blue-bullet.gif\"/> = conditionally required)\n";
print "<p></p>\n";

&do_parameters ($defs, 'top', $defs->top_parameters );

print "<hr></hr>\n<INPUT TYPE=\"reset\" VALUE=\"Reset\"/>\n";
print "<INPUT TYPE=\"submit\" VALUE=\"$command_label\"/>\n";
&print_one_param($defs, "advanced", "email2","Mail",'top');

print "\n</FORM>\n";

&do_comments($defs);

&print_footer($defs, "advanced");

sub do_parameters {
    my ($defs, $paragraph, @parameters_list) = @_ ;
    my $param;

    foreach $param (@parameters_list) {

	next if ($defs->ishidden($param) || $defs->type($param) eq "Results" );

	if ($paragraph eq 'top' && 
	    $defs->type($param) ne "Paragraph" &&
	    defined $defs->comment($param) ) {

	    push ( @{ $comments{'top'} } , $param);
	}
	&print_one_param($defs, 
			 "advanced", 
			 $param,
			 $defs->type($param),
			 $paragraph);
    }

    if ($paragraph ne 'top') {
	print "<br></br>\n<i>[Return to the main part with your favorite browser's Back function]</i>\n<br></br>\n";
    }

    foreach $param (@parameters_list) {
	next if ($defs->ishidden($param));
	if ($defs->type($param) eq "Paragraph") {

	    $string = $defs->prompt($param);
	    print "<hr></hr>\n";

	    join("\n",$defs->comment($param)), "\n";

	    if ( defined $defs->comment($param) ) {
		push (@{ $comments{$param} } , $param);
	    }
	    $comment_in_paragraph = 0;
	    foreach $p ( $defs->vlist($param) ) {
		unless ($defs->type($p) eq "Paragraph") {
		    if ( defined $defs->comment($p) ) {
			$comment_in_paragraph = 1;
			push (@{ $comments{$param} } , $p);
		    }
		}
		push @{ $parameters_todo{$param} }, $p;
	    }
	    if ( defined $defs->comment($param) || $comment_in_paragraph) {
		$comment_aname = $param . "_comment";
		print "<a name=$param><h2><A HREF=\"\#$comment_aname\">$string</a>";
	    } else {
		print "<a name=$param><h2>$string";
	    }
	    print "</h2>\n";
	    &do_parameters($defs, $param, @{$parameters_todo{$param}} );

	}
    }

}

sub do_comments {
    my $defs = $_[0];

    if (defined %comments) {
	print "<hr></hr>\n<H2>Some explanations about the options</H2>\n";
	print "\n<dl>\n";
	
	if ( defined $comments{'top'} ) {
	    $n=0;
	    print "<dt><br></br><i><b>Main parameters</b></i></dt>\n";
	    foreach $param (@{ $comments{'top'}} ) {
		$string = $defs->prompt($param);
	        $aname=$param;
	        print "<dt><a name=$aname><i>$string</i></a></dt>\n";
		if (defined $defs->comment($param)) {
		    foreach $comment ($defs->comment($param)) {
			print "<dd>$comment</dd>\n";
		    }
		}
	        $n++;
            }
            for $i (0 .. $n ) {
	         undef @{ $comments{'top'}[$i] };
            }
            undef $comments{'top'};
        }

        foreach $paragraph (keys %comments) {
    
            $aname = $paragraph . "_comment";
            $string = $defs->prompt($paragraph);
            print "<dt><a name=$aname>\n<br></br>\n<i><b>$string</b></i></a></dt>\n";
	    if (defined $defs->comment($paragraph)) { 
		foreach $comment ($defs->comment($paragraph)) {
		    print "<dd>$comment</dd>\n";
		}
	    }
            shift @{ $comments{$paragraph}} 
                if (defined $defs->comment($paragraph) );
	
            foreach $param (@{ $comments{$paragraph}} ) {
	        $string = $defs->prompt($param);
	        $aname=$param;
	        print "<dt><a name=$aname><i>$string</i></a></dt>\n";
	        foreach $comment ($defs->comment($param)) {
	            print "<dd>$comment</dd>\n";
	        }
            }
         }
    
         if ($seqfmt) {
	     print "<dt><a name=fmtseq><i>Sequence format</i></dt>\n";
	     print "<dd>The sequence will be automatically converted in the format needed for the program</dd>\n";
	     print "<dd>providing you enter a sequence either:</dd>\n";
	     print "<dd> in plain (raw) sequence format or in one of the following known formats:</dd>\n";
	     print "<dd>IG,GenBank,NBRF,EMBL,GCG,DNAStrider,Fitch,fasta,Phylip,PIR,MSF,ASN,PAUP,CLUSTALW</dd>\n";
	     if ($DBSEARCH) {
		     print "<dd>You may enter in the text area a database entry code, or an accession number, in this form:<BR></BR><CODE>database:entry_name</CODE><BR></BR>or:<BR></BR><CODE>database:accession</CODE>.</dd>\n";
             }
         }
         print "</dl><hr></hr>\n";
     }
}

1;


