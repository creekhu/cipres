#! /local/bin/perl

use CGI;
use File::Basename;
use Mail::Internet;

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";

# how do we prefer to cancel jobs? direct/email to adm
# assume you have PBS
my $cancel_method = 'direct';  
#my $cancel_method = 'email_adm';

# Get the input
my $input = new CGI;

my $command=$input->param('command');
my $scratch_dir=$input->param('scratch_dir');
my $email=$input->param('email');
$email =~ s|\\||g;

my $date=localtime;
my $me = basename $0;
require "/local/gensoft/lib/Pise/5.a/lib/web.pl";

print STDERR "[$date] $me: $command ($scratch_dir) ($email) \n";
my $user_message;

if ($cancel_method eq 'direct' and $PBS) {
    my $job_to_kill = $scratch_dir;
    $job_to_kill =~ s/.+\///;
    #print STDERR "[$date] $me: direct cancel $job_to_kill\n";
    $user_message = "Your $command job is terminated";
    
    my $JOB=open(IN, "/local/bin/qstat |") || die "cannot open qstat: $!\n";
    while (<IN>) {

        my ($id, $name, $user, $time, $state, $queue) = split(' ' , $_);

	#print STDERR "[$date] $me: $name $user $time $state $queue\n";

        # check job status
        if ( $name eq $job_to_kill ) {
            # job is runnig, kill it 
            if ( $state eq "R" ) {
                my @args = ( "qsig", $id );
                system(@args);
                print STDERR "[$date] $me: $job_to_kill: killed\n";
		$user_message = "Your $command job has been cancelled";
                last;
            }
            # job is waiting, un-queue it
            else {
                my @args = ( "qdel", $id );
                system(@args);
                print STDERR "[$date] $me: $job_to_kill: dequeued\n";
		$user_message = "Your $command job has been cancelled";
                last;
            } 
        }
    }

} else {
    #print STDERR "[$date] $me: email cancel\n";
    my $agent_line = "User agent: $ENV{'HTTP_USER_AGENT'}\n";
    my $message =  $agent_line;
    $message .= "Request for cancelling this job:\nEmail: $email\nDate: $date\nCommand: $command\nTmp directory: $scratch_dir\n";

    $help =~ s/\\//g;
    $mail = new Mail::Internet ( [ "From: $email" ,
				   "To: $help" ,
				   "Cc: $email",
				   "Subject: Cancel a $command job" ] ,
				 'Body' => [ $message ] ) ;

    $ENV{MAILADDRESS} =  $email;


# RFC2219
    $mail->smtpsend ( 'Host' => "$MAILHOST" ) ;
    $user_message = "Your request to cancel a $command job has been sent to the staff";
}

print $input->header;
print $input->start_html("Cancel a job.");
print $input->h1("Cancel a job.");

print "
<h3>$user_message</h3>
";

print $input->end_html;

