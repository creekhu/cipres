#! /local/bin/perl

# TODO:

use CGI;

require "/local/gensoft/lib/Pise/5.a/lib/web.pl";

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";

# Get the input
my $input = new CGI;
my $piped_file=$input->param('piped_file');
my $command = $input->param('command');
($command,@with_piped_files)=split(",",$command);
#print STDERR "DEBUG> command=$command with_piped_files=@with_piped_files\n";
my $scratch_dir=$input->param('scratch_dir');
my $piped_file_type=$input->param('piped_file_type');
my $piped_variable=$input->param('piped_variable');
my $user_level=$input->param('user_level');
my $email=$input->param('email');
$email =~ s|\@|\\$&|g;

#$ENV{'CGI_DIR'}=$CGI_DIR;

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";
eval ("use $command;");
my $defs = $command->new;

$def="$tmp_dir/$scratch_dir/pipe.pl";
open (PERLDEF, "> $def") || die "cannot open $def:$!";
print PERLDEF "\%$command\:\:piped = (\n";
my %pipein = $defs->pipein;
foreach $param (keys %pipein) {
    print STDERR "DEBUG> connect.pl $command $param ($piped_file_type)\n";
    if (defined $defs->pipein($param)) {
	my %param_pipein = $defs->pipein($param);
	foreach $type (keys %param_pipein ) {
#	    print STDERR "DEBUG> connect.pl $command $param type: $type\n";
	    if ($type eq $piped_file_type) {
		print PERLDEF "\t\t\"$param\" => \"$scratch_dir/$piped_file\",\n";
		if (@with_piped_files) {
		    foreach $with_file (@with_piped_files) {
			($with_param,$with_value) = split("=",$with_file);
#			print STDERR "with_param=$with_param, with_value=$with_value, type=$type, command=$command, param=$param\n";
			@with_params = $defs->withpipein($param,$type);
			print STDERR "check: ", join (",",@with_params),"\n";
			if (grep ( /^$with_param$/ , @with_params)) {
			    print STDERR "$param => $with_param,$with_value\n";
			    print PERLDEF "\t\t\"$with_param\" => \"$scratch_dir/$with_value\",\n";
			}
		    }
		}
	    }
	}
    }
}
if ($email !~ /^\s*$/) {
    #print STDERR "DEBUG> connect.pl email not empty: |$email|\n";
    print PERLDEF "\t\t\"email\" => \"$email\",\n";
}
print PERLDEF "\t\t\"scratch_dir\" => \"$scratch_dir\",\n";
print PERLDEF "\t\t\"piped_file\" => \"$piped_file\",\n";
print PERLDEF "\t\t\"piped_file_type\" => \"$piped_file_type\",\n";
print PERLDEF "\t\t\"piped_variable\" => \"$piped_variable\"\n";
print PERLDEF ");\n";
close(PERLDEF);
print STDERR "DEBUG> connect.pl $email: $command ($scratch_dir)\n";

printf "Content-type: text/html\n\n";

$make_html= "perl /local/gensoft/lib/Pise/5.a/Maker/";
$make_html .= ($user_level eq "simple")? "make-simple-html.pl" : "make-html.pl"; 
$make_html .= " $command $def"; 
open (HTML,"$make_html |") || die "cannot run $make_html:$!";
while (<HTML>) {
    print;
}
close(HTML);


