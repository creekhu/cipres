#
#
# TODO
#  - bouton d'ouverture/fermeture de paragraphe ==> align� en haut
#  - r�cup�rer les param�tres d'un job (dans la page de r�sultats)
#  (dans la frame outputs)
#  - file exists comme test unique = ficher d'input ... :-(
#  - s�parer le code pour tous les jobs et le code sp�cifique � une commande
#    listbox
#  - type Label

require "$ENV{'PISEDIR'}/lib/web.pl";

sub panic {
  my($msg) = @_;
  print STDERR $msg, "\n";
  die;
}
sub clean_esc {
    my $s = $_[0];
    $s =~ s/\\//g ;
    return $s;
}
sub esc_tcl {
    my $s = $_[0];
    $s =~ s/\[/\\[/g ;
    $s =~ s/\]/\\]/g ;
    return $s;
}

sub print_headers {
    print "
package require http
package require xml

proc eval_pise_include {} {
    global env
    if [info exists env(PISE_CODE_SERVER)] {
	set pise_code_server \$env(PISE_CODE_SERVER)
    } else {
	set pise_code_server \"http://bioweb.pasteur.fr/cgi-bin/seqanal/lib/\"
    }
    #set token [ http::geturl http://bioweb.pasteur.fr/cgi-bin/seqanal/lib/get_tcl.pl -query source=http]

    puts stderr \"(eval_pise_include) pise_code_server: \$pise_code_server\"

    set token [http::geturl \$pise_code_server/get_tcl.pl -query source=http]

    set status [http::status \$token]
    if {\$status == \"ok\"} {
        set code [http::code \$token]
        if [regexp {200} \$code match] {
            set results [http::data \$token]
            eval \$results
        }  elseif [regexp {404} \$code match] {
	    puts stderr \"eval_pise_include: \$code\"
        } else {
           puts stderr \"eval_pise_include: \$code\"
        }
    } else {
        puts stderr \"eval_pise_include: \$status\"
    }

    #set token [ http::geturl http://bioweb.pasteur.fr/cgi-bin/seqanal/lib/get_tcl.pl -query source=pise ]
    set token [ http::geturl \$pise_code_server/get_tcl.pl -query source=pise ]

    set status [http::status \$token]
    if {\$status == \"ok\"} {
        set code [http::code \$token]
        if [regexp {200} \$code match] {
            set results [http::data \$token]
            eval \$results
        }  elseif [regexp {404} \$code match] {
	    puts stderr \"eval_pise_include: \$code\"
        } else {
           puts stderr \"eval_pise_include: \$code\"
        }
    } else {
        puts stderr \"eval_pise_include: \$status\"
    }
}

eval_pise_include

";
}

sub print_footers {
    my $top_frame = $_[0];
    print "
global last_pise_frame
set last_pise_frame $top_frame
puts \"I am done\"
";
}

sub print_top_frame {
    my $command = $_[0];
    my $user_level = $_[1];
    ($frame = $command) =~ tr/A-Z/a-z/ ;
    print "
global root_frame
if { ! [info exists root_frame] } {
    set root_frame \"\"
} else {
    puts stderr \"root_frame=\$root_frame\"
}
";
    print "
if [winfo exists \$root_frame.$frame] {
    foreach {child} [winfo children \$root_frame.$frame] {
        destroy \$child
    }
} else {
    frame \$root_frame.$frame
    pack \$root_frame.$frame -fill both -expand true
}
";
    return "\$root_frame.$frame";
}

sub print_procedures {
    my ($defs,$command) = @_ ;
    my @parameters_list = $defs->parameters_order;

    print "

proc submit_command_$command {button} {

    set command $command

    global env
    set user \$env(USER)
    set multipart \"email=\$user\"
";
    $sep='';
    foreach $param (@parameters_list) {
        if ($defs->type($param) ne "Paragraph") {
	   if ($defs->type($param) eq "Switch") {
	       print "
    global $param
";

# -textvariable does not always create the variable

	       if ($defs->vdef($param)) {
		   print "
    if { ! [info exists $param]} {
       set $param 1
    }
";
	       }

	       print "
    if { [info exists $param] && \$$param} {
       append multipart \"&\" 
       append multipart \"$param=on\"
    } 
";
	   } else { 
	       print "
    global $param
    if [info exists $param] {
       append multipart \"&\"
       append multipart \"$param=\$$param\"
    }
";
	  }
       }
    }

    print "
    \$button configure -state disabled

    post_request $command \$multipart

    \$button configure -state normal
}
";
}

sub wrap_string {
    my $string = $_[0];
    my $l = length($string);
    my $i = 0;
    my $label = "";
    my @words=split(/\s/,$string);
    my $word;
    my @substrs;

    my $substr = "";
    foreach $word (@words) {
	if (length($substr) < 40) {
	    $substr .= "$word ";
	} else {
	    push (@substrs, $substr);
	    $substr = "$word ";
	}
    }
    push (@substrs, $substr);
    $label = join ("\n", @substrs);
    return $label;
}

sub print_quit_submit {
    my $command = $_[0];
    print "print_quit_submit $command\n";
}

sub print_jobs_frame {
    my $command = $_[0];
    print "print_jobs_frame $command\n";
}

sub print_one_param {
    my ($defs, $command, $user_level, $param , $type, $paragraph, $frame ) = @_ ;

    print "set row [current_row $command]\n";

    undef $vdef;
    $string = wrap_string (esc_tcl ( clean_esc($defs->prompt($param)) ));
#    chomp($string);

    $param_frame="$frame.$param";
    $param_frame =~ tr/A-Z/a-z/;
    $param_frame_label = $param_frame . "_label";
    $param_frame_input = $param_frame . "_input";

    if ($type eq "Paragraph") {
        $paragraph_frame = $param_frame . "_frame";
	$command_name = "paragraph_" . $command . "_" . $param;
	print "button $param_frame_input -text \"$string\" -command [list $command_name \$row]\n";
	print "grid $param_frame_input -row \$row -column 0\n";

	$proc_name = "close_" . $command . "_" . $param;
	#print "puts \"defining $proc_name\"\n";
	print "\n\nproc $proc_name {row} {\n";
	print "\tglobal root_frame\n";
	print "\tcatch { destroy $paragraph_frame }\n";
	print "\t$param_frame_input configure -command [list $command_name \$row]\n";
	print "}\n\n";
	$proc_name = "paragraph_" . $command . "_" . $param;
	#print "puts \"defining $proc_name\"\n";
	print "\n\nproc $proc_name {row} {\n";
	print "\tglobal root_frame\n";
	print "\tif [winfo exists $param_frame.frame] {\n";
	print "\t     \treturn;\n";
	print "}\n\n";
	$command_name = "close_" . $command . "_" . $param;
	print "$param_frame_input configure -command [list $command_name \$row]\n";
	print "frame $paragraph_frame -borderwidth 2 -relief sunken\n";
	print "grid $paragraph_frame -row \$row -column 1\n";
	return;
    }

    if (! ($type eq "InFile" || $type eq "Sequence" )) {
	print "label $param_frame_label -text \"$string\"\n";
    }

# penser au cas ou vdef est une liste ?
    $vdef = $defs->vdef($param);

    if ($type eq "InFile" || $type eq "Sequence" ) {
        print "global $param\n";
        print "button $param_frame_label -text \"$string\" -command [list getFile \"$string\" $param]\n";
        print "entry $param_frame_input -width 50 -exportselection 1 -textvariable $param\n";
    }
    elsif ($type eq "OutFile" || $type eq "String") {
        print "global $param\n";
	print "entry $param_frame_input -width 20 -exportselection 1 -textvariable $param\n";
    }
    elsif ($type eq "Switch") {
        print "global $param\n";
        print "checkbutton $param_frame_input -variable $param\n";
	if ($vdef) {
	    print "$param_frame_input select\n";
	}
    }
    elsif ($type eq "Excl") {
#	@values = @{ $defs->vlist($param) };
	@values = $defs->vlist($param) ;
	$prompt_size = 0;
	$i=0;
	while ($i <= $#values) {
	    $prompt_size += length($values[$i+1]);
	    $i++;
	}
	if ( $#values > 6 || $prompt_size > 70) {
            $menu_string = "";
            $n = 0;
            while ($n <= $#values) {
                $value=$values[$n];
                $prompt=$values[$n+1];
		$menu_string .= " \"$value\"";
		$n+=2;
	    }
            print "global $param\n";
            print "tk_optionMenu $param_frame_input $param $menu_string\n";
            
        } else {
            print "frame $param_frame_input\n";
            $n = 0;
            $c=0;
            while ($n <= $#values) {
                $value=$values[$n];
                $prompt=$values[$n+1];
		print "global $param\n";
                if ($value) {
		    print "radiobutton $param_frame_input.choice_$c -text \"$prompt\" -value $value -variable $param\n";
		} else {
		    print "radiobutton $param_frame_input.choice_$c -text \"$prompt\"  -variable $param\n";
		}
                print "pack $param_frame_input.choice_$c -side top\n";
                if ($value eq $vdef) {
    #                print "$param_frame_input.choice_$value select\n";
		} 
		$n+=2;
		$c++;
	    }
        }
    }
    elsif ($type eq "List") {
	# pas variable associee: a gerer a la main
#	@values = @{ $defs->vlist($param) } ;
	@values = $defs->vlist($param) ;
	@vdefs = @{ $defs->vdef($param) };
        print "listbox $param_frame_input -selectmode multiple\n";
        $n = 0;
        $line = 0;
        while ($n <= $#values) {
	    $value=$values[$n];
	    $prompt=$values[$n+1];
            print "$param_frame_input insert end $prompt\n";
	    if ( (grep { $_ eq $value } @vdefs )) {
		print "$param_frame_input selection set $line\n";
	    }
	    $n+=2;
            $line++;
        }
    }
    elsif ($type eq "Integer" || $type eq "Float") {
        print "global $param\n";
	print "entry $param_frame_input -width 20 -exportselection 1 -textvariable $param\n";
    }	
    elsif ($type eq "Label") {
	# TODO
    }
    elsif ($type eq "Results") {
	return;
    }
    else {
	&panic ("AAAAAAAAAAA! Unknown type $type for parameter $param");
    }
    print "grid $param_frame_label -row \$row -column 0\n";
    print "grid $param_frame_input -row \$row -column 1\n\n";

}

1;
