# not finished

use CGI;
use POSIX;

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";

my $input = new CGI;
$user_level=$input->param('user_level');
$VERSION= ($ENV{'VERSION'})? $ENV{'VERSION'} : "5.a";
$VERSION= ($input->param('VERSION')) ? $input->param('VERSION') : $VERSION;
$ENV{'VERSION'}=$VERSION;

my $date=localtime;

$PISEDIR="/local/gensoft/lib/Pise/$VERSION";
$ENV{'PISEDIR'}=$PISEDIR;
require "$PISEDIR/lib/web.pl";

if (defined $input->param('PERLDEFDIR')) {
    $PERLDEFDIR=$input->param('PERLDEFDIR');
} else {
    $PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : $ENV{'PISEDIR'} . '/PerlDef';
}
$ENV{'CGI_DIR'}="$CGI_DIR";

$command=$FORM{'command'};
use lib "$PERLDEFDIR";
eval ("use $command;");
