
## PBS batch system specific stuff


## Generate PBS command line
sub pbs_command {
  my ($command, $queue, $jobname) = @_;

  ## Command init
  my $cmd = "qsub -m n -N $jobname";
  ## Set stdout & stderr output files
  $cmd .= " -o $command.out -e $command.err";
  ## Set queue
  $cmd .= " -q $queue";

  return $cmd; }


1;
