#
# access control
# 

# the black.list file may contains 2 kind of lists:
# @users = ( 'someone@somewhere.domain', 'someoneelse@another.domain' );
# @hostnames = ( 'a.complete.internet.adress',  'an.ip.number', '.a.subdomain.name' );
#require "/local/gensoft/lib/Pise/5.a/lib/black.list";

my @local_only = qw(blastpar psiblastpar megablastpar hmmpar hmmsearchpar hmmpfam stamp amps transform sorttrans alignfit avestruc pdbc pdbseq dstamp aconvert reputer RepeatMasker glimmer long_orfs full_run build_imm morgan genemark);
 
sub not_wanted {
    my $who = $_[0];
    my $remote = $ENV{'REMOTE_HOST'};
    if (! $remote) {
        $remote = $ENV{'REMOTE_ADDR'};
    }

    my $date = localtime;

    ## Check for local users
    if ($PASTEUR && $who =~ /\@pasteur\.fr$/) {
	if ($who eq 'pise-bioapi\@pasteur.fr') {
	    #print STDERR "[$date] check_user.pl: a bioperl tester...\n";
	    return 0;
	}
	require "/local/gensoft/lib/Pise/5.a/lib/check_pasteur.pl";
	my $res = check_local($who);
	return 1 if ($res == 1) ;
    }

    ## Check black.list
    if ($PASTEUR) {
	require '/local/gensoft/lib/Pise/5.a/lib/black.list';
	$msg = "not allowed on this server (for now)";
	## Check email
	if (grep(/^$who$/, @users)) {
	    print STDERR "[$date] User $who from $remote: $msg\n";
	    return 1; 
	}
	## Check hostname
	foreach my $host (@hostnames) {
	    $host =~ s/\./\\\./g;
	    ## IP number
	    if ($host =~ /\d+$/ && $remote =~ /^$host/) {
		print STDERR "[$date] User $who from $remote: $msg\n";
		return 1; 
	    }
	    ## Real hostname
	    if ($remote =~ /$host$/) {
		print STDERR "[$date] User $who from $remote: $msg\n";
		return 1; 
	    }
	}
    }
    
    ## You may insert here your local policy.

    return 0; 
}

sub check_local_only {
    my $email_status = $_[0];  # see Pasteur::Email
    my $command = $_[1];

    if (not (grep {$_ eq $command} (@local_only))) {
	return 1;
    }

    my $remote = $ENV{'REMOTE_HOST'};
    if (! $remote) {
        $remote = $ENV{'REMOTE_ADDR'};
    }
    if ($email_status ne 'local') {
	return 0;
    }
    if ($remote !~ /pasteur\.fr/) {
	return 0;
    }
    return 1;
}




1;
