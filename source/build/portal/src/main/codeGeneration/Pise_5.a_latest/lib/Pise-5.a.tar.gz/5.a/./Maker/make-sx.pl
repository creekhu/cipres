BEGIN {
  unshift(@INC,"/local/private/sis/fmc/work/Sx-2.3/blib/arch",
	  "/local/private/sis/fmc/work/Sx-2.3/blib/lib",
	  "/local/private/sis/fmc/lib/perl/widg",
	  "$ENV{PISEDIR}/PerlDef","$ENV{PISEDIR}/lib");
}

require 'do_command.pl';
use Sx;
use Filer;

sub MakeParagraph {
  my $para = shift;

  my $but = MakeButton($prompt->{$para},\&MakePara,$para);
  AddHelp($but,$para);
  (wantarray) ? ($but) : $but;
}

sub MakePara {
  my ($w,$para) = @_;

  return if ($ActiveWindow{$para}++);
  my $tmpwind = MakeWindow($para,SAME_DISPLAY,NONEXCLUSIVE_WINDOW);
  my %OldUp = %Up;
  my @wlist;
  %Up = (Prev => undef);
  my $ThisHelp = MakeTextWidget('',0,0,$sixty_chars,$ten_lines,'Start'); 
  foreach $field (@{$vlist->{$para}}) {
    next if ($hidden->{$field});
    my $f = 'Make' . $type->{$field};
    my ($w,$w2) = &{$f}($field);
    $HelpOf{$field} = $ThisHelp;
    SetWidgetPos($w,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
    $Up{Prev} = $w;
    push(@wlist,[$field,$w2]);
  }
  my $close = MakeButton('Close',\&CloseMe,[$para,$tmpwind]);
  my $reset = MakeButton('Reset',\&Reset,[@wlist]);
  SetWidgetPos($ThisHelp,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  SetWidgetPos($close,PLACE_UNDER,$ThisHelp,NO_CARE,undef);
  SetWidgetPos($reset,PLACE_UNDER,$ThisHelp,PLACE_RIGHT,$close);
  ShowDisplay;
  %Up = %OldUp;
}

sub Reset {
  my @datas = @{$_[1]};

  foreach $dbl (@datas) {
#    $($dbl->[1],$vdef->{$dbl->[0]});
    ;
  }
}

sub MakeString {
  my $string = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$string}));
  my $inwidg = MakeStringEntry($ActualValue{$string},$thirty_chars,\&SetValue,$string);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddExit($inwidg,$string);
  AddHelp($tmpform,$string);
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub MakeSequence {
  my $sequence = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$sequence}));
  my $inwidg = MakeStringEntry($ActualValue{$sequence},$forty_chars,\&SetInfile,$sequence);
  my $browse = MakeButton('Browse',\&ChooseFile,['old',$sequence,$inwidg]);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetWidgetPos($browse,PLACE_RIGHT,$inwidg,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddTranslation($inwidg,
		 '<Leave>' => "::SetInfileValue($sequence)");
  AddHelp($tmpform,$sequence);
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub MakeInFile {
  my $infile = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$infile}));
  my $inwidg = MakeStringEntry($ActualValue{$infile},$forty_chars,\&SetInfile,$infile);
  my $browse = MakeButton('Browse',\&ChooseFile,['old',$infile,$inwidg]);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetWidgetPos($browse,PLACE_RIGHT,$inwidg,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddTranslation($inwidg,
		 '<Leave>' => "::SetInfileValue($infile)");
  AddHelp($tmpform,$infile);
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub ChooseFile {
  my @datas = @{$_[1]};
  my $fl = Filer::new($datas[0]);
  
  if ($fl) {
    SetStringEntry($datas[2],$fl);
    $fl =~ s/^~/$ENV{HOME}/o; 
    $ActualValue{$datas[1]} = $fl;
  }
}  

sub MakeInteger {
  my $integer = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$integer}));
  my $inwidg = MakeStringEntry($ActualValue{$integer},$thirty_chars,\&SetValue,$integer);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddExit($inwidg,$integer);
  AddHelp($tmpform,$integer);
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub MakeOutFile {
  my $outfile = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$outfile}));
  my $inwidg = MakeStringEntry($ActualValue{$outfile},$thirty_chars,\&SetValue,$outfile);
  my $browse = MakeButton('Browse',\&ChooseFile,['new',$infile,$inwidg]);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetWidgetPos($browse,PLACE_RIGHT,$inwidg,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddExit($inwidg,$outfile);
  AddHelp($tmpform,$outfile);
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub AddExit {
  my $w = shift;
  my $field = shift;

  AddTranslation($w,
		 '<Leave>' => "::SetExitValue($field)");
}

sub SetExitValue {
  my ($w,$ign,$field) = @_;
  $ActualValue{$field} = GetStringEntry($w);
}

sub SetInfileValue {
  my ($w,$ign,$field) = @_;
  my $value = GetStringEntry($w);
  $ActualValue{$field} = $value;
  return unless ($value);
  $ActualValue{$field} =~ s/^~/$ENV{HOME}/o; 
  unless (-f $ActualValue{$field}) {
    unless (GetYesNo("file $value doesn't exists. Keep it ?")) {
      SetStringEntry($w,'');
    }
  }
}

sub SetValue {
  my ($w,$value,$field) = @_;

  $ActualValue{$field} = $value;
}

sub SetInfile {
  my ($w,$value,$field) = @_;

  $value =~ s/^~/$ENV{HOME}/o; 
  $ActualValue{$field} = $value;
  return unless ($value);
  unless (-f $value) {
    unless (GetYesNo("file $_[1] doesn't exists. Keep it ?")) {
      SetStringEntry($w,'');
    }
  }
}

sub MakeSwitch {
  my $switch = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$switch}));
  my $inwidg = MakeButton($ActualValue{$switch} ? "Yes" : " No",\&SetSwitch,$switch);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddHelp($tmpform,$switch);
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub SetSwitch {
  my ($w, $switch) = @_;

  if ($ActualValue{$switch}) {
    SetLabel($w," No");
    $ActualValue{$switch} = 0;
  } else {
    SetLabel($w,"Yes");
    $ActualValue{$switch} = 1;
  }
}

sub MakeList {
  my $list = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$list}));
  my @vlist = @{$vlist->{$list}};
  my $max = MaxLen(@vlist);
  $max = 25 unless ($max > 25);
  my %corr = @vlist;
  $ActualValue{$list} = join(' ',@corr{sort @{$ActualValue{$list}}}) 
    if (ref($ActualValue{$list}) eq 'ARRAY');
  my $first = $ActualValue{$list} || ('_'x25);
  my $menu = MakeMenu(sprintf(" %${max}s ",$first));
  SetWidgetInt($menu,'justify',0);
  SetFgColor($menu,RED);
  while (@vlist) { 
    my $w = MakeMenuItem($menu,$vlist[1],\&SetList,[$list,$vlist[0],$vlist[1],$menu]);
    SetFgColor($w,RED);
    SetMenuItemChecked($w,$ActualValue{$list} =~ /( $vlist[0])|($vlist[0] )/);
    splice(@vlist,0,2);
  } 
  SetWidgetPos($menu,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddHelp($tmpform,$list);
  (wantarray) ? ($tmpform,$menu) : $tmpform;
}


sub SetList {
  my ($w,$data) = @_;
  my ($list,$item,$title,$menu) = @{$data};

  my @values = split(/ /,$ActualValue{$list});
  my %saw;
  @saw{@values} = @values;

  if ($saw{$item}) {
    SetMenuItemChecked($w,0);
    delete $saw{$item};
  } else {
    $saw{$item} = $item;
    SetMenuItemChecked($w,1);
  }
  $ActualValue{$list} = join(' ',sort (keys %saw));
  SetLabel($menu,$ActualValue{$list});  
}


sub MakeExcl {
  my $excl = shift;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  my $lab = MakeLabel(justif(40,$prompt->{$excl}));
  my @vlist = @{$vlist->{$excl}};
  my $max = MaxLen(@vlist);
  my %corr = @vlist;
  $ActualValue{$excl} = $vlist[0] unless ($ActualValue{$excl});
  my $menu = MakeMenu(sprintf(" %${max}s ",$corr{$ActualValue{$excl}}));
  SetWidgetInt($menu,'justify',0);
  SetFgColor($menu,RED);
  my $which;
  while (@vlist) { 
    my $w = MakeMenuItem($menu,$vlist[1],\&SetExcl,[$excl,\$which,$vlist[0],$vlist[1],$menu]);
    SetFgColor($w,RED);
    SetMenuItemChecked($w,$ActualValue{$excl} eq $vlist[0]);
    $which = $w if ($ActualValue{$excl} eq $vlist[0]);
    splice(@vlist,0,2);
  } 

  SetWidgetPos($menu,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddHelp($tmpform,$excl);
  (wantarray) ? ($tmpform,$menu) : $tmpform;
}


sub SetExcl {
  my ($w,$data) = @_;
  my ($excl,$rwid,$item,$title,$menu) = @{$data};

  if ($ActualValue{$excl} eq $item) {
    SetMenuItemChecked($$rwid,0);
    SetLabel($menu,'');
    $ActualValue{$excl} = undef;
  } else {
    $ActualValue{$excl} = $item;
    SetMenuItemChecked($$rwid,0);
    SetMenuItemChecked($w,1);
    SetLabel($menu,$title);
    $$rwid = $w;
  }
}

sub SetHelp { 
  SetTextWidgetText($HelpOf{$_[2]},justif(60,@{$comment->{$_[2]}}),0);
}

sub AddHelp { 
  return unless ($_[0] && $_[1]);
  AddTranslation($_[0],
		 '<Enter>' => "::SetHelp($_[1])");
}

sub justif {
  my ($width,@txt) = @_;
  my $result = '';

  foreach $line (@txt) {
    until (length($line) < $width) {
      $line =~ s/(.{0,$width}) (.*)/$2/;
      $result .= "$1\n";
    }
    $result .= "$line\n\n";
  }
  chomp($result);
  $result;
}


sub Main {
  eval("package $ARGV[0]; require '$ARGV[0].pl';");
  
  $command = $ARGV[0];
  $vdef = \%{"${command}::vdef"};
  $vlist = \%{"${command}::vlist"};
  $type = \%{"${command}::type"};
  $prompt = \%{"${command}::prompt"};
  $hidden = \%{"${command}::hidden"};
  $comment = \%{"${command}::comment"};
  $mandatory = \%{"${command}::mandatory"};
  $top_parameters = \@{"${command}::top_parameters"};
  $parameters_order = \@{"${command}::parameters_order"};
  @ARGV = OpenDisplay('Main',@ARGV);
  my $ex = MakeButton('Close',\&DoExit,undef);
  my $do = MakeButton('Do It',\&DoIt,undef);
  $MainFont = GetWidgetFont($ex);
  $eighty_chars = TextWidth($MainFont,'M'x82);
  $sixty_chars = TextWidth($MainFont,'M'x67);
  $forty_chars = TextWidth($MainFont,'M'x42);
  $thirty_chars = TextWidth($MainFont,'M'x32);
  $ten_lines = 10 * (FontHeight($MainFont)+1);
  $HelpLabel = MakeTextWidget('',0,0,$sixty_chars,$ten_lines,'Start'); 
  %ActualValue = %{$vdef};
  %Up = (Prev => undef);
  GetStandardColors;
  foreach $field (@{$top_parameters}) {
    next if ($hidden->{$field});
    my $f = 'Make' . $type->{$field};
    my $w = &{$f}($field);
    $HelpOf{$field} = $HelpLabel;
    SetWidgetPos($w,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
    $Up{Prev} = $w;
  }
  SetWidgetPos($HelpLabel,PLACE_UNDER,$Up{Prev},NO_CARE,undef);
  SetWidgetPos($ex,PLACE_UNDER,$HelpLabel,NO_CARE,undef);
  SetWidgetPos($do,PLACE_UNDER,$HelpLabel,PLACE_RIGHT,$ex);
  ShowDisplay;
  MainLoop;
}

sub CloseMe { 
  @datas = @{$_[1]};
  SetCurrentWindow($datas[1]);
  $ActiveWindow{$datas[0]} = undef;
  CloseWindow; 
}

sub DoIt {
  foreach $field (@{$parameters_order}) {
    if ($mandatory->{$field} && !($ActualValue{$field})) {
      return unless (GetYesNo("Field $field is missing, proceed ?"));
    }
  }
  foreach $k (keys %ActualValue) {
    $ {"${command}::$k"} = $ActualValue{$k};
  }
  run(do_command($command));
}

sub DoExit { 
#  DoIt;
  exit;
}

sub MaxLen {
  
  my $max = 0;
  foreach (@_) {
    $l = length($_);
    $max =  $l if ($l > $max);
  }
  $max;
}

sub run {
  my $cmd = shift;
  my $w = MakeWindow('Test',SAME_DISPLAY,EXCLUSIVE_WINDOW);
  my $l = MakeLabel("Waiting for program $command to terminate");
  my $prev = $l;
  unless ($ActualValue{outfile}) {
    $ActualValue{outfile} = "Output.$$";
    $cmd .= " > $ActualValue{outfile}";
  }    
  my $b = MakeButton(sprintf('Results',$ActualValue{outfile}), \&ShowFile, $ActualValue{outfile});
  SetWidgetPos($b,PLACE_UNDER,$prev,NO_CARE,undef);
  SetWidgetState($b,0);
  my $errfile = "error.$$";
  my $e = MakeButton(' Error ',\&ShowFile,$errfile);
  SetWidgetState($e,0);
  my $c = MakeButton('Close',\&CloseMe,[undef,$w]);
  SetWidgetState($c,0);
  SetWidgetPos($e,PLACE_UNDER,$b,NO_CARE,undef);
  SetWidgetPos($c,PLACE_UNDER,$e,NO_CARE,undef);
  
  $pid = open(MYOUT,"-|");

  unless(defined($pid)) {
    print STDERR "Couldn't fork: [$!] [$?]\n";
    return;
  }
  unless ($pid) {
    exec "$cmd 2> $errfile";
  } 
  ShowDisplay;
  AddTimeOut(5000,\&AddOut,[$pid,$errfile,$e,$c,$l,$b]);
  MainLoop;
}

sub AddOut {
  my ($pid,$ferr,$err,$clo,$l,@wlist) = @{$_[0]};

  $stats = waitpid $pid, 1;
  if ($stats == 0) {
    AddTimeOut(5000,\&AddOut,$_[0]);
    return;
  } else {
    close(MYOUT);
    SetLabel($l,"Select a file name");
    foreach (@wlist) { SetWidgetState($_,1) }
  }
  unless (-z $ferr) {
    SetLabel($l,"Errors during run (click on Error)");
    SetWidgetState($err,1);
  }
  SetWidgetState($clo,1);
}

sub ShowFile {
  my $file = $_[1];

  my $w = MakeWindow($file,SAME_DISPLAY,NONEXCLUSIVE_WINDOW);
  my $t = MakeTextWidget($file,1,0,$eighty_chars,3*$ten_lines,'Results'); 
  my $e = MakeButton('Save',\&Blahh,$errfile);
  my $c = MakeButton('Close',\&CloseMe,[undef,$w]);
  SetWidgetPos($e,PLACE_UNDER,$t,NO_CARE,undef);
  SetWidgetPos($c,PLACE_UNDER,$t,PLACE_RIGHT,$e);
  ShowDisplay;
}

Main;
