sub get_lsf_queue {
    my $email_status = $_[0];
    my $command = $_[1];

    my $queue = 'webrem';
    if ($email_status eq 'local') {
	$queue = 'webloc';
    } elsif ($command eq 'genscan') {
	$queue = 'webloc';
    } elsif ($command eq 'toppred') {
	$queue = 'webloc';
    } elsif ($command eq 'efetch') {
	$queue = 'webloc';
    } elsif ($command eq 'golden') {
	$queue = 'webloc';
    } elsif ($command eq 'drawtree') {
	$queue = 'webloc';
    } elsif ($command eq 'drawgram') {
	$queue = 'webloc';
    } elsif ($command eq 'tacg') {
	$queue = 'webloc';
    } elsif ($command eq 'mfold') {
	$queue = 'webloc';
    } elsif ($command eq 'fastdnaml') {
	$queue = 'long';
	#$queue = 'webrem';
    }
    return $queue;
}

1;
