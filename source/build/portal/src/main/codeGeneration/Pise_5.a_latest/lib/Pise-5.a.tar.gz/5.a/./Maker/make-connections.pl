
use lib "/local/gensoft/lib/Pise/5.a/PerlDef";

#open (DEFS,"ls /local/gensoft/lib/Pise/5.a/PerlDef/*.pm|") || die "cannot open ls /local/gensoft/lib/Pise/5.a/PerlDef/*.pm: $!";
#while (<DEFS>) {
#    chop;
#    $def=$_;
#    $command=`basename $def`;
#    chomp($command);
#    $command =~ s/\.pm//;
#    $analyze{$command} = 1;
#}
#close DEFS;

for my $command (@ARGV) {
    $analyze{$command} = 1;
}

foreach $program (keys %analyze) {
    print STDERR "PROGRAM=$program\n";
    eval("use $program");
    $defs = $program->new;
    %pipein = $defs->pipein;
    foreach $param (keys %pipein) {
	print STDERR "PROGRAM=$program\tPARAM=$param";
	%types = $defs->pipein($param);
	foreach $type ( keys %types ) {
	    print STDERR "\ttype = $type [",
	    $defs->pipein($param,$type),"]\n";
            push (@{ $params{$type}{$program} }, $param);
        }
    }
}

open (PIPEIN,"> /local/gensoft/lib/Pise/5.a/PerlDef/pipeins") || die "cannot open /local/gensoft/lib/Pise/5.a/PerlDef/pipein.pl:$!";

print PIPEIN "
%pipein = (
";

foreach $type (keys %params) {
    print PIPEIN "\t$type => {\n";
    foreach $program ( keys %{ $params{$type} } ) {
	print PIPEIN "\t\t$program => [\n";
        foreach $param ( @{ $params{$type}{$program} } ) {
	    print PIPEIN "\t\t\t$param,\n";
        }
	print PIPEIN "\t\t],\n";
    }
    print PIPEIN "\t},\n";
}
print PIPEIN "
);

1;

";

close PIPEIN;


