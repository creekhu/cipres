#! /local/bin/perl

use CGI;
use File::Basename;
use Mail::Internet ;

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";

my $input = new CGI;
$command=$input->param('command');
$email=$input->param('email');
$freearea=$input->param('freearea');
if (defined $input->param('PISEDIR')) {
    $PISEDIR=$input->param('PISEDIR');
} else {
    $PISEDIR="/local/gensoft/lib/Pise/5.a";
}
require "$PISEDIR/lib/web.pl";

if (defined $input->param('subject')) {
    $subject=$input->param('subject');
} else {
    $subject="Notes and summary about a $command job";
}

my $date=localtime;
$me=basename $0;
chomp($me);
print STDERR "[$date] $me: $command ($email)\n";

printf "Content-type: text/html\n\n";

$email =~ s/\\//g;
$mail = new Mail::Internet ( [ "From: $email" ,
                               "To: $email" ,
                               "Subject: $subject" ] ,
                             'Body' => [ $freearea ] ) ;

$ENV{MAILADDRESS} =  $email;

# RFC2219
$mail->smtpsend ( 'Host' => "$MAILHOST" ) ;

print "Your message \"$subject\" has been sent to $email\n";



