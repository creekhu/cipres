package Filer;

use Sx;

sub Abort {
  $CurSelection = undef;
  CloseWindow;
}

sub GetDir {
  my $cdir = shift;
  chop($Cpwd = `pwd`);
  $Tpwd = $Cpwd;
  $Cpwd =~ s/$oldpwd/./o;
  $Tpwd =~ s/$ENV{HOME}/~/o;
  $Tpwd =~ s/.*(.{24})$/...$1/o if (length($Tpwd) > 27);  
  SetLabel($dlabel,$Tpwd);
  opendir(DIR,$cdir);
  @CurList = readdir(DIR);
  grep((-d $_) && ($_ .= '/'),@CurList);
  @CurList = sort @CurList;
}

sub Select {
  return Beep unless ($_[1] || $CurSelection);
  if ($_[1]) {
    $CurSelection = $_[1];
  }
  if (-d $CurSelection) {
    chdir($CurSelection);
    GetDir('.');
    ChangeScrollList($list,@CurList);
    $CurSelection = undef;
    SetStringEntry($entry,'');
  } else {
    CloseWindow;
  }
}

sub GotIt {
  $CurSelection = $_[1];
  Select(undef,$_[1]) if ($_[3] == 512);
}

sub GetIt {
  $CurSelection = GetStringEntry($entry);
}

sub new {
  shift if ($_[0] eq 'Filer');
  chomp($oldpwd = `pwd`);
  $CurSelection = undef;
  $win = MakeWindow('Filer',SAME_DISPLAY,1);
  SetWidgetDat($win,'title','Filer');
  $dlabel = MakeLabel(' ' x 27);
  GetDir('.');
  $list = Make3List(200,190,'GotIt',undef,@CurList);
  $get = MakeButton(' Open ','Select',undef);
  $abort = MakeButton('Cancel','Abort',\$win);
  SetWidgetPos($list,PLACE_UNDER,$dlabel,undef,undef);
  SetWidgetPos($get,PLACE_RIGHT,$list,PLACE_UNDER,$dlabel);
  SetWidgetPos($abort,PLACE_RIGHT,$list,PLACE_UNDER,$get);
  SetWidgetInt($get,'vertDistance',40);
  SetWidgetInt($abort,'vertDistance',40);
  if ($_[0] eq 'New') {
    $entry = MakeStringEntry('',200,'Select',0);
   SetWidgetPos($entry,PLACE_UNDER,$list,undef,undef);
   AddTranslation($entry,'<Leave>','GetIt');
  }
  ShowDisplay;
  MainLoop;
  SetCurrentWindow(ORIGINAL_WINDOW);
  chdir($oldpwd);
  if ($CurSelection) {
    $Cpwd =~ s/$oldpwd/./;
    $Cpwd =~ s/$ENV{HOME}/~/o;
    return "$Cpwd/$CurSelection";
  } else {
    return undef;
  }
}

  
package main;

sub MakeParagraph {
  my ($para,$prompt,$callback) = @_;

  my $but = MakeButton($prompt,$callback,$para);
  AddTranslation($but,
		 '<Enter>' => "::SetHelp($para)");
  (wantarray) ? ($but) : $but;
}


sub Reset {
  my @datas = @{$_[1]};

  foreach $rec (@datas) {
    ($field,$type,$widget,$value,@rest) = @{$rec};
    if ($type eq 'Excl') {
      $ActualValue{$field} = $value;
      SetLabel($widget,$rest[0]);
      foreach $r (@{$rest[1]}) {
	SetMenuItemChecked($r->[2],$value eq $r->[0]);
      }
    } elsif ($type eq 'List') {
      $ActualValue{$field} = $value;
      SetLabel($widget,$rest[0]);
      foreach $r (@{$rest[1]}) {
	SetMenuItemChecked($r->[2],($value =~ /( $r->[0])|($r->[0] )/));
      }
    } elsif ($type eq 'Switch') {
      $ActualValue{$field} = $value;
      SetLabel($widget,$value ? 'Yes' : ' No');
    } else {
      $ActualValue{$field} = $value;
      SetStringEntry($widget,$value);
    }
  }
}

sub MakeString {
  my ($string,$prompt) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
  my $inwidg = MakeStringEntry($ActualValue{$string},$thirty_chars,\&SetValue,$string);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddExit($inwidg,$string);
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($string)");
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub MakeSequence {
  my ($sequence,$prompt) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
  my $inwidg = MakeStringEntry($ActualValue{$sequence},$forty_chars,\&SetInfile,$sequence);
  my $browse = MakeButton('Browse',\&ChooseFile,['Old',$sequence,$inwidg]);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetWidgetPos($browse,PLACE_RIGHT,$inwidg,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddTranslation($inwidg,
		 '<Leave>' => "::SetInfileValue($sequence)");
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($sequence)");
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub MakeInFile {
  my ($infile,$prompt) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
  my $inwidg = MakeStringEntry($ActualValue{$infile},$forty_chars,\&SetInfile,$infile);
  my $browse = MakeButton('Browse',\&ChooseFile,['Old',$infile,$inwidg]);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetWidgetPos($browse,PLACE_RIGHT,$inwidg,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddTranslation($inwidg,
		 '<Leave>' => "::SetInfileValue($infile)");
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($infile)");
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub ChooseFile {
  my @datas = @{$_[1]};
  my $fl = Filer::new($datas[0]);
  
  if ($fl) {
    SetStringEntry($datas[2],$fl);
    $fl =~ s/^~/$ENV{HOME}/o; 
    $ActualValue{$datas[1]} = $fl;
  }
}  

sub MakeInteger {
  my ($integer,$prompt) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
  my $inwidg = MakeStringEntry($ActualValue{$integer},$thirty_chars,\&SetValue,$integer);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddExit($inwidg,$integer);
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($integer)");
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub MakeOutFile {
  my ($outfile,$prompt) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
  my $inwidg = MakeStringEntry($ActualValue{$outfile},$thirty_chars,\&SetValue,$outfile);
  my $browse = MakeButton('Browse',\&ChooseFile,['New',$infile,$inwidg]);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetWidgetPos($browse,PLACE_RIGHT,$inwidg,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddExit($inwidg,$outfile);
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($outfile)");
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub AddExit {
  my $w = shift;
  my $field = shift;

  AddTranslation($w,
		 '<Leave>' => "::SetExitValue($field)");
}

sub SetExitValue {
  my ($w,$ign,$field) = @_;
  $ActualValue{$field} = GetStringEntry($w);
  $ActualValue{$field} = undef if ($ActualValue{$field} =~ /^\s*$/);
}

sub SetInfileValue {
  my ($w,$ign,$field) = @_;
  my $value = GetStringEntry($w);
  $ActualValue{$field} = $value;
  return unless ($value);
  $ActualValue{$field} =~ s/^~/$ENV{HOME}/o; 
  unless (-f $ActualValue{$field}) {
    unless (GetYesNo("file $value doesn't exists. Keep it ?")) {
      SetStringEntry($w,'');
    }
  }
}

sub SetValue {
  my ($w,$value,$field) = @_;

  $ActualValue{$field} = $value;
  $ActualValue{$field} = undef if ($ActualValue{$field} =~ /^\s*$/);
}

sub SetInfile {
  my ($w,$value,$field) = @_;

  $value =~ s/^~/$ENV{HOME}/o; 
  $ActualValue{$field} = $value;
  return unless ($value);
  unless (-f $value) {
    unless (GetYesNo("file $_[1] doesn't exists. Keep it ?")) {
      SetStringEntry($w,'');
    }
  }
}

sub MakeSwitch {
  my ($switch,$prompt) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
    my $inwidg = MakeButton($ActualValue{$switch} ? "Yes" : " No",\&SetSwitch,$switch);
  SetFgColor($inwidg,RED);
  SetWidgetPos($inwidg,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($switch)");
  (wantarray) ? ($tmpform,$inwidg) : $tmpform;
}

sub SetSwitch {
  my ($w, $switch) = @_;

  if ($ActualValue{$switch}) {
    SetLabel($w," No");
    $ActualValue{$switch} = 0;
  } else {
    SetLabel($w,"Yes");
    $ActualValue{$switch} = 1;
  }
}

sub MakeList {
  my ($list,$prompt,@vlist) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
  my $max = MaxLen(@vlist);
  my @clist;
  $max = 25 unless ($max > 25);
  my %corr = @vlist;
  my $lvalue = $ActualValue{$list};
  my $first = $lvalue || ('_'x25);
  my $menu = MakeMenu(sprintf(" %-${max}s ",$first));
  SetWidgetInt($menu,'justify',0);
  SetFgColor($menu,RED);
  while (@vlist) { 
    my $w = MakeMenuItem($menu,$vlist[1],\&SetList,[$list,$vlist[0],$vlist[1],$menu]);
    SetFgColor($w,RED);
    SetMenuItemChecked($w,$lvalue =~ /( $vlist[0])|($vlist[0] )/);
    push(@clist,[$vlist[0],$vlist[1],$w]);
    splice(@vlist,0,2);
  } 
  SetWidgetPos($menu,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($list)");
  (wantarray) ? ($tmpform,$menu,[@clist]) : $tmpform;
}


sub SetList {
  my ($w,$data) = @_;
  my ($list,$item,$title,$menu) = @{$data};

  my @values = split(/ /,$ActualValue{$list});
  my %saw;
  @saw{@values} = @values;

  if ($saw{$item}) {
    SetMenuItemChecked($w,0);
    delete $saw{$item};
  } else {
    $saw{$item} = $item;
    SetMenuItemChecked($w,1);
  }
  $ActualValue{$list} = join(' ', sort (keys %saw));
  SetLabel($menu,$ActualValue{$list});  
}


sub MakeExcl {
  my ($excl,$prompt,@vlist) = @_;
  my $tmpform = MakeForm(TOP_LEVEL_FORM,PLACE_UNDER,$prev,NO_CARE,undef);
  my $lab = MakeLabel($prompt);
  my $max = MaxLen(@vlist);
  my @clist;
  my %corr = @vlist;
  $ActualValue{$excl} = $vlist[0] unless ($ActualValue{$excl});
  my $menu = MakeMenu(sprintf(" %-${max}s ",$corr{$ActualValue{$excl}}));
  SetWidgetInt($menu,'justify',0);
  SetFgColor($menu,RED);
  my $which;
  while (@vlist) { 
    my $w = MakeMenuItem($menu,$vlist[1],\&SetExcl,[$excl,\$which,$vlist[0],$vlist[1],$menu]);
    SetFgColor($w,RED);
    SetMenuItemChecked($w,$ActualValue{$excl} eq $vlist[0]);
    $which = $w if ($ActualValue{$excl} eq $vlist[0]);
    push(@clist,[$vlist[0],$vlist[1],$w]);
    splice(@vlist,0,2);    
  } 

  SetWidgetPos($menu,PLACE_RIGHT,$lab,NO_CARE,undef);
  SetForm(TOP_LEVEL_FORM);
  AddTranslation($tmpform,
		 '<Enter>' => "::SetHelp($excl)");
  (wantarray) ? ($tmpform,$menu,[@clist]) : $tmpform;
}


sub SetExcl {
  my ($w,$data) = @_;
  my ($excl,$rwid,$item,$title,$menu) = @{$data};

  if ($ActualValue{$excl} eq $item) {
    SetMenuItemChecked($$rwid,0);
    SetLabel($menu,'');
    $ActualValue{$excl} = undef;
  } else {
    $ActualValue{$excl} = $item;
    SetMenuItemChecked($$rwid,0);
    SetMenuItemChecked($w,1);
    SetLabel($menu,$title);
    $$rwid = $w;
  }
}

sub SetHelp { 
  SetTextWidgetText($HelpOf{$_[2]},$HelpText{$_[2]},0) if ($HelpOf{$_[2]});
}

sub CloseMe { 
  @datas = @{$_[1]};
  SetCurrentWindow($datas[1]);
  $ActiveWindow{$datas[0]} = undef;
  CloseWindow; 
}

sub DoExit { 
  exit;
}

sub MaxLen {
  
  my $max = 0;
  foreach (@_) {
    $l = length($_);
    $max =  $l if ($l > $max);
  }
  $max;
}

sub run {
  my $cmd = shift;
  my $outf = shift;
  my $others = shift;
  my $w = MakeWindow('Test',SAME_DISPLAY,EXCLUSIVE_WINDOW);
  my $com = MakeLabel("  $cmd  ");
  my $l = MakeLabel("Waiting for program $command to terminate");
  SetWidgetPos($l,PLACE_UNDER,$com,NO_CARE,undef);
  my $prev, $m;
  $outf = $ActualValue{$outf};
  unless ($outf) {
    $outf = "Output.$$";
    $cmd .= " > $outf";
  }     
  print "other: [$others], outf: $outf\n";
  my $b = MakeButton(sprintf('Standard Output',$outf), \&ShowFile, $outf);
  SetWidgetPos($b,PLACE_UNDER,$l,NO_CARE,undef);
  SetWidgetState($b,0);

  my $errfile = "error.$$";
  my $e = MakeButton('  Informations ',\&ShowFile,$errfile);

  if ($others) {
    $m = MakeMenu('  Result Files ');
    SetWidgetPos($m,PLACE_UNDER,$b,NO_CARE,undef);
    SetWidgetState($m,0);
    SetWidgetPos($e,PLACE_UNDER,$m,NO_CARE,undef);
  } else {
    SetWidgetPos($e,PLACE_UNDER,$b,NO_CARE,undef);
  }
  SetWidgetState($e,0);
  
  my $c = MakeButton(' Close ',\&CloseMe,[undef,$w]);
  SetWidgetPos($c,PLACE_UNDER,$e,NO_CARE,undef);
  SetWidgetState($c,0);
  
  $pid = open(MYOUT,"-|");

  unless(defined($pid)) {
    print STDERR "Couldn't fork: [$!] [$?]\n";
    return;
  }
  unless ($pid) {
    exec "$cmd 2> $errfile";
  } 
  ShowDisplay;
  AddTimeOut(5000,\&AddOut,[$pid,$errfile,$e,$c,$l,$b,$m,$others,$outf]);
  MainLoop;
}

sub AddOut {
  my ($pid,$ferr,$err,$clo,$l,$o,$m,$f,$output) = @{$_[0]};
  my $ok = 0;
  $stats = waitpid $pid, 1;
  if ($stats == 0) {
    AddTimeOut(5000,\&AddOut,$_[0]);
    return;
  } else {
    close(MYOUT);
    SetLabel($l,"Select a file name");
    SetWidgetState($o,1);
    if ($m) {
      @flist = eval("<$f>;");
      foreach $f (@flist) {
	next if ($f eq $output);
	if ((-e $f) && ((-M $f) < 0)) {
	  my $w = MakeMenuItem($m,$f,\&ShowFile,$f);
	  if (-z $f) {
	    SetWidgetState($w,0);
	  } else {
	    $ok++;
	  }
	}
      }
      SetWidgetState($m,1) if ($ok);
    }
  }
  unless (-z $ferr) {
    SetLabel($l,"Errors during run (click on Error)");
    SetWidgetState($err,1);
  }
  SetWidgetState($clo,1);
}

sub ShowFile {
  my $file = $_[1];

  my $w = MakeWindow($file,SAME_DISPLAY,NONEXCLUSIVE_WINDOW);
  my $t = MakeTextWidget($file,1,0,$eighty_chars,3*$ten_lines,'Results'); 
  my $e = MakeButton('Save',\&Blahh,$file);
  my $c = MakeButton('Close',\&CloseMe,[undef,$w]);
  SetWidgetPos($e,PLACE_UNDER,$t,NO_CARE,undef);
  SetWidgetPos($c,PLACE_UNDER,$t,PLACE_RIGHT,$e);
  ShowDisplay;
}

sub Blahh {
  my $f = new Filer('New');

  print "in: $_[1], out: $f\n";
  if ($f) {
    open(OUT,">$f");
    open(IN,$_[1]);
    print OUT while (<IN>) ;
  }
  close(IN); close(OUT);
}
    
END {
  unlink("Output.$$","error.$$");
}

1;

