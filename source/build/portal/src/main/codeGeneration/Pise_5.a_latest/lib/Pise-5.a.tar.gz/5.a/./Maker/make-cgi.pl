#
# see configurations in lib/web.pl
#

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";

package Maker;

$VERSION = ($ENV{'VERSION'})? $ENV{'VERSION'} : "5.a" ;
$PISEDIR= ($ENV{'PISEDIR'})? $ENV{'PISEDIR'} : "/local/gensoft/lib/Pise";

$command=$ARGV[0];

eval ("use $command;");
if ( $@ ) {
    die "Pise ($VERSION) $command: $@";
}
$defs = $command->new;

#---------------------------------------------------
# Web settings
#
require "$PISEDIR/lib/web.pl";

# batch command systems (see below # BATCH)
$lsf_command = "bsub -u nobody -e $command.err -o $command.out -N -I ";
$batch_nb = $LSF + $PBS;
if ($batch_nb > 1) {
    die "More than one BATCH system selected, cannot use more than one";
}

# nice command (see web.pl)
$nice_command = "/usr/bin/nice -n NICE_VALUE";
$nice_command =~ s/NICE_VALUE/$NICE_VALUE/;

$PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : $PISEDIR . '/PerlDef';
$verbal = 0;
$date = `date +"%d %b %Y %H:%M"` ;
chop($date);

#---------------------------------------------------
# CGI 

print "#! /local/bin/perl

# Cgi generator version: $VERSION ($date)

";

if ($PASTEUR) {
    print "
use Pasteur::Email;
use MD5;
";
}

print "
# Settings

use CGI;
use Mail::Internet;

my \$input = new CGI;
my \$output = new CGI;

use BSD::Resource;
my \$resource = RLIMIT_CORE;
# Arrange so no core files are generated
my \$success = setrlimit(\$resource, 0, 0);
\$resource = RLIMIT_FSIZE;
my \$FILELIMIT = $FILELIMIT;
\$success = setrlimit(\$resource, \$FILELIMIT, \$FILELIMIT);
\$MAXMAILSIZE = $MAXMAILSIZE;

\$ENV{\'PATH\'} = \"$path\";
my \$WEB_LIB=\"$PISEDIR/lib\";
my \$MAINTAINER=\"$maintainer\";
my \$HELP=\"$help\";
my \$LOG=\"$log\";
my \$tmp_url = \"$tmp_url\"; 
my \$tmp_dir = \"$tmp_dir\"; 
my \$tmp_email;
my \$requests_dir = \"\$tmp_dir/REQUESTS\";
my \$have_readseq = $READSEQ;
my \$have_fmtseq = $FMTSEQ;
my \$have_clustalw = $CLUSTALW;
my \$unix_command;
my \$title;
my \$prompt;
my \%ctrl;
my \@seqfmt;

sleep 1;
my \$t = time ;
# for PBS jobname, you need the tmp dir to begin with a letter
my \$scratch_nb = \"A\$\$\" . \"\$t\";
\$scratch_nb =~ s/(\.{15})\.*/\$1/;   ## Max 15 chars for PBS jobname.
my \$scratch_dir = \"\$tmp_dir/$command/\$scratch_nb\" ;
\$| = 1;

#my \$result_delay=5;
my \$result_remain=$RESULT_REMAIN;
my \$child_wait=60;
my \$child_done=0;
my \$child_err=0;

my \$version=\"$VERSION ($date)\";

require \"\$WEB_LIB/convseq.pl\";
require \"\$WEB_LIB/evaluation.pl\";
require \"\$WEB_LIB/do_command.pl\";
require \"\$WEB_LIB/check_user.pl\";
require \"\$WEB_LIB/service_down.pl\";
require \"\$WEB_LIB/web.pl\";
require \"\$WEB_LIB/db.pl\";
require \"\$WEB_LIB/info.pl\";
require \"\$WEB_LIB/mirrors.pl\"; 
";

if ($LSF) {
    print "
require \"\$WEB_LIB/lsf.pl\";
";
}

if ($PBS) {
  print "
require \"\$WEB_LIB/batch.pl\";
require \"\$WEB_LIB/pbs.pl\";
";
}

print "

# tmp variables
my \$pid;
my \$param;
my \$paramdata;
my \$paramstring;
my \$rawdata;
my \@rawdata_lines;
my \$rawdata_line_number;
my \$rawdata_sequence;
my \$rawdata_sequences;
my \$rawdata_db;
my \$rawdata_id;
my \$value;
my \$vdef;
my \$seqfile;
my \$newseqfile;
my \$tmpfile;
my \$convfile;
my \$current_fmt;
my \$fromfmt;
my \$fromfmtdesc;
my \$tofmt;
my \$tofmtdesc;
my \$precond;
my \$test;
my \$test_pos;
my \$msg;
my \$filenames;
my \$fname;
my \$user_part;
my \@outfiles;
my \@infiles;
my %fromfmtseq;
my %tofmtseq;
my %prgfmtseq;
my \%squizz_warning;
my \$v;
my \$w;
my \$request_pid;
my \$separator;
";

#----------------------------------------------------
print "

use lib \"/local/gensoft/lib/Pise/5.a/PerlDef\";
eval (\"use $command;\");
\$defs = $command->new;

package main;

# re-define default values for List parameters
";
my %types = $defs->type;
foreach $param (keys %types) {
    if ($defs->type($param) eq "List") {
	if (defined $defs->separator($param)) {
	    $separator = $defs->separator($param);
	} else {
	    $separator = '';
	}
	print "\$defs->vdef($param,join (\"$separator\", sort (( ";
	print join(",",@{ $defs->vdef($param) });
	print ") ) ) );\n";
#	print "print STDERR \$defs->vdef($param), \"\\n\";";
    }
}

print "
# add special variables for HTML/CGI interface
&set_var(\"_html\",1);
if (not \$defs->opt_email) {
  \$defs->ismandatory('email', 1);
}

";

print "
# utilities
sub child_end {
    \$SIG{CHLD} = 'IGNORE';
    my \$pid=-2;
    use POSIX \"sys_wait_h\";
    print STDERR \"CGI for $command received SIGCHLD from ...\\n\";
    while (\$pid && \$pid != -1) {
	\$pid = POSIX::waitpid( -1, \&POSIX::WNOHANG );
	print STDERR \"\\t\$pid ?\\n\";
    }
    \$child_err=1;
}
sub child_usr1 {
#    print STDERR \"CGI for $command received SIGUSR1\\n\";
    \$child_done=1;
    \$SIG{USR1} = 'IGNORE';
    \$SIG{CHLD} = 'IGNORE';
}

sub mail_maintainer {
    my \$msg = \$_[0];
    my \$from = getpwuid(\$<) . \"\\\@$MAILHOST\" ;
    \$mail = new Mail::Internet ( [ \"From: \$from\" ,
				   \"To: \$MAINTAINER\" ,
				   \"Subject: Pise problem\" ] ,
				  'Body' => [ \$msg ] ) ;

     \$ENV{MAILADDRESS} =  \$from;
    
# RFC2219
    \$mail->smtpsend ( 'Host' => '$MAILHOST' ) ;
}

sub clean_files {
    my \$f;
    stat ( \"\$scratch_dir\" );
    if ( -e _ ) {
	chdir \"\$scratch_dir\" || die \"can\'t cd to \$scratch_dir: \$!\" ;
	open (LS, \"ls |\") || &mail_maintainer(\"pb ls clean_files: \$!\") ; 
	while (<LS>) {
	    chop ;
	    \$f = \$_ ;
	    stat(\$f);
	    if ( -e _ ) {
		unlink \$f;
	    }
	}
	close (LS) ;
	rmdir \"\$scratch_dir\" ;
    }
}

sub gettitle {

    my \$defs = \$_[0];
    my \$result = \"\";
    \$result .= \"<h1>\";

    if (\$defs->description) {
        \$title_name = \$defs->title; 
	\$title_text = \": \" . \$defs->description;
        if (\$defs->authors) {
	    if (\$defs->reference) {
		\$title_text .= \" (<a href=\\\"\#REFERENCE\\\">\" . \$defs->authors . \"</a>)\";
	    } else {
		\$title_text .= \" (\" . \$defs->authors . \")\";
	    }
	}
    } else {
	\@title_parts = split(' ', \$defs->title);
        \$title_name = \$title_parts[0]; 
        \$title_text = join(' ',\@title_parts[1..\$#title_parts]);
    }
    \$doc_aname = \$title_name;
    \$doc_aname =~ s/-//g ; 
    \$doc_aname =~ s/\://g ;
    \$doc_aname =~ tr/a-z/A-Z/ ;
    if (\$defs->doclink) {
	\$result .= \"<a href=\\\"\";
	\$result .= \$defs->doclink;
	\$result .= \"\\\">\$title_name</a> \$title_text\";

    } else {
	# this is an url where to find documentation about (all) programs
	# the name of the program, say 'xx' will be appended (#xx) 
	# not used if \$PASTEUR=0
	if (\$PASTEUR) {
	    \$www_gensoft = \"http://bioweb.pasteur.fr/docs/softgen.html\";
	    \$result .= \"<a href=\\\"\$www_gensoft\#\$doc_aname\\\">\$title_name</a> \$title_text\";
	} else {

	    \$result .= \$title;
	}
    }

    \$result =~ s/\\\&/\\\&amp;/g;

    \$result .= \"</h1>\";

    return \$result;
}

sub unlock_request {
";
if ($PASTEUR) {
print "
    if (defined \$::request_file) {
	stat \$::request_file;
	if ( -e _ ) {
	    unlink \$::request_file;
	}
	stat \"\$::request_file.pid\";
	if ( -e _ ) {
	    unlink \"\$::request_file.pid\";
	}
	stat \"\$::request_file.jobname\";
	if ( -e _ ) {
	    unlink \"\$::request_file.jobname\";
	}
    }
";
} else {
    print "
    return;
";
}

print "
}

sub panic {
    my \$msg = \$_[0];
    my \$no_mail = \$_[1];
#    &clean_files;
    print \"<H1>PANIC: \$msg</H1><address>\$HELP</address>\\n\";
    print \"</BODY></HTML>\\n\";
    \$msg = \"$command: \$msg\";
    &mail_maintainer (\"\$msg\") unless (\$no_mail);
    &unlock_request;
    exit 1;
}
sub user_error {
    my \$msg = \$_[0];
    my \$keep_request = \$_[1];
    &clean_files;
    print \"<!--USER ERROR-->\\n\";
    print \"<H3>\$msg</H3>\\n\";
    print \"</BODY></HTML>\\n\";
    &unlock_request unless (\$keep_request);
    exit 1;
}

sub upload_file {
    my \$param = \$_[0];
    my \$filename = \$input->param(\$param);
    my \$fh = \$filename;
#    print STDERR \"DEBUG> upload_file: filename=\$filename (\$scratch_dir)\\n\";
    if (\$filename =~ /\\\\/ ) {
	\$filename =~ s|.*[:/\\\\](.*)|\$1|;
	&set_var (\$param,\$filename);
	print STDERR \"DEBUG> upload_file: \$param PC Windows filename (2) = \$filename (\$scratch_dir)\\n\";
    }

    if (\$filename =~ /^\\S*.*\\s+.*\\S*\$/ ) {
	my \$date=`date`;
	chop(\$date);
	\$date=\"[\$date]\";
	print STDERR \"\$date filename containing space(s): \", \$input->param(\$param), \"\\n\";
	(\$tmpfile = \$filename) =~ s/\\s+//g ;
	print STDERR \"\$date renaming \$filename \$tmpfile (\$scratch_dir)\\n\";
	&set_var (\$param, \$tmpfile);
	\$filename = \$tmpfile;
    }
    open (TMPFILE,\"> \$scratch_dir/\$filename\") || die \"cannot open \$scratch_dir/\$filename: \$!\";
    my \$content;
    my \$data;
    # book on CGI.pm, Lincoln Stein, p154
    while (read(\$fh,\$data,1024)) {
	\$content .= \$data;
    }
    my \$eol = \"\\n\";
    \$content =~ s/\\015\\012/\$eol/og;
    \$content =~ s/\\015/\$eol/og;
    print TMPFILE \$content;
    close TMPFILE;
    return;

# no Content-Type field to test wether binary or text...
#    my \%info = \%{ \$input->uploadInfo(\$fh) };
#    foreach my \$field (keys \%info) {
#	print STDERR \"DEBUG> field = \$field value = \$info{\$field}\\n\";
#    }
#    \$type = \"text\";
#    if (\$type =~ /^text/) {
#    my \$line;
#    while ( <\$fh> ) {
#	if (/\\r\\n/) {
#	    (\$line = \$_) =~ s/\\r\\n/\\n/;
#	    \$content .= \$line;
#	} elsif (/\\r/) {
#	    \$content = join (\"\\n\", split ( \"\\r\", \$_ ));
#	    last;
#	} else {
#	    \$content .= \$_;
#	}
#    }
#    print STDERR \"DEBUG> upload_file (\$scratch_dir) content:\\n\$content\\n\";

# other possibility (what about Mac and PC windows files?):
#    my \$tmpfile = \$input->tmpFileName(\$filename);
#    my \$new = `basename \$tmpfile`;
#    chomp(\$new);
#    system(\"cp \$tmpfile /tmp/\$new\");
#    print STDERR \"\$tmpfile copied to /tmp/\$new\\n\";

}

sub outfiles {
    my \$param;
    my \$precond;
    my \$filename;
    my \@outfiles;

    push (\@outfiles,\$defs->_standout_file) if (\$defs->_interface_standout);

    foreach \$param (\$defs->parameters_order) {
        \$precond = \$defs->precond(\$param,'perl');
        if ( \$precond && ! &my_eval(\"\$precond\") ) {
            next;
        }
        if ( \$defs->type(\$param) eq \"OutFile\" ) {
            \$filename = &get_var(\$param);
            unless ( \$filename eq \"\" ) {
                push (\@outfiles,\$filename) unless (grep { \$filename eq \$_ } \@outfiles);
                \$param{\$filename} = \$param;
            }
        } 
    }

    return \@outfiles;
}

sub multiple_requests {
    # compute checksum
    # parameters' values + size of input files

    my \@values;
    my \$size;
    my \$dev; my \$ino;my \$mode;my \$nlink;my \$uid;my \$gid;my \$rdev; my \@rem;
";
print "
    foreach \$param (
";
foreach $param ( $defs->parameters_order ) {
         print "      \"$param\", \n";
}

print " 
    ) {
         if (\$defs->type(\$param) eq \"InFile\" || 
             \$defs->type(\$param) eq \"Sequence\") {
	       (\$dev,\$ino,\$mode,\$nlink,\$uid,\$gid,\$rdev,\$size,\@rem) = 
	          stat \$input->param(\$param);
	       push (\@values,\$size); 
         } else {
	       push (\@values,\$input->param(\$param)); 
         }
    }
    \$::email = \$input->param('email');
    push (\@values,\$::email, \'$command\' );

#    print STDERR \"DEBUG:  .. [ \",join(\"|\",\@values), \" ]\\n\";

    \$::checksum = MD5->hexhash(join(\" \",\@values));
    \$::request_file = \"\$requests_dir/$command.\$::checksum\";

    stat \$::request_file;
    if ( -e _ ) {
	may_be_kill(\$::request_file);
	return 1;
    } else {
	\$detached_request_file = \"\$::request_file.detached\";
	stat \$detached_request_file;
	if ( -e _ ) {
              #print STDERR \"DEBUG: request .. defined (detached) [\$detached_request_file]\\n\";
              return 2;
        } else {
#              #print STDERR \"DEBUG: request .. not defined [\$::request_file]\\n\";
              open (REQ, \"> \$::request_file\")  
                    || &panic (\"cannot create \$::request_file\");
              print REQ join(\"\\n\",\@values);
              close REQ;
              return 0;
        }
    }

}

sub may_be_kill {
    \$request_pid = \"\$::request_file.pid\";
    print STDERR \"DEBUG: request .. defined [\$::request_file]\\n\";
    stat \$request_pid;
    if ( -e _ ) {
	open (PID,\$request_pid) || return 1;
	my \$pid_to_kill=<PID>;
	chop(\$pid_to_kill);
	close(PID);
	print STDERR \"kill \$pid_to_kill\\n\";
	\$SIG{HUP} = 'IGNORE';
	kill \'HUP\' => -\$pid_to_kill;
    }
";
if ($LSF) {
     print "
    \$request_jobname = \"\$::request_file.jobname\";
    stat \$request_jobname;
    if ( -e _ ) {
	open (JOBNAME,\$request_jobname) || return 1;
	my \$jobname_to_kill=<JOBNAME>;
	chop(\$jobname_to_kill);
	close(JOBNAME);
	print STDERR \"bkill \$jobname_to_kill\\n\";
	system(\"/lsf/bin/bkill -u www1 -J \$jobname_to_kill > /dev/null 2>&1\");
    }
";
} elsif ($PBS) {
     print "
    \$request_jobname = \"\$::request_file.jobname\";
    stat \$request_jobname;
    if ( -e _ ) {
        open (JOBNAME,\$request_jobname) || return 1;
        my \$jobname_to_kill=<JOBNAME>;
        chop(\$jobname_to_kill);
        close(JOBNAME);
	\$job_id = `(qselect -N \$jobname_to_kill) 2>/dev/null`;
	if (\$job_id ne '') {
	    print STDERR \"qsig \$job_id\\n\";
	    system(\"qsig \$job_id > /dev/null 2>&1\");
	  }
      }
";
}

print "
}

# initializations: html output, tmp directory
# ne passe pas <?xml version=\\\"1.0\\\" encoding=\\\"iso-8859-1\\\"?>

#print \"Content-type: text/html\\n
#

print \$output->header(-type=>'text/html');

print \"<!DOCTYPE html PUBLIC \\\"-//W3C//DTD XHTML 1.0 Strict//EN\\\"  \\\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\\\">\";

print \"\\n<HTML>\\n\";
\$title = \$defs->title;
print \"<HEAD><TITLE>\$title</TITLE>\\n
<link rel=\\\"stylesheet\\\" href=\\\"$ROOT_URL/pise.css\\\" />
</HEAD>\\n<BODY>\\n\\n\";
\$hypertext_title = gettitle(\$defs);
print \"\$hypertext_title\\n\\n\";
my \$info = information_message();
if (\$info) {
	print \"<HR></HR><I>\$info</I><HR></HR>\\n\";
}

";

if ($verbal) {
    print "print STDERR \"<P></P>Executed on \", \`date\`, \" for \\n\", \$ENV {\'REMOTE_HOST\'}, \" (\", \$ENV{\'REMOTE_ADDR\'}, \") \\n\";\n";
    print "print STDERR \$ENV {\'HTTP_USER_AGENT\'}, \"\\n\";\n";
}

print "

if (service_down(\"$command\")) {
#    &panic (\"The service is temporarily unavailable. Try again later.\",1);
    &user_error (\"The service is temporarily unavailable. Try again later.\",1);
}


stat( \"\$tmp_dir/$command\" );
if ( \! -e _ ) {
     mkdir (\"\$tmp_dir/$command\", 0770 )
        || &panic(\"Cannot create directory \$tmp_dir/$command : \$\!\") ;
     chmod 0770, \"\$tmp_dir/$command\" ;
     system(\"touch \$tmp_dir/$command/index.html\");
}
mkdir ( \"\$scratch_dir\", 0770 )
     || &panic(\"Cannot create directory  \$scratch_dir: \$\!\") ;
chmod 0770, \"\$scratch_dir\" ;

stat( \"\$tmp_dir/REQUESTS\" );
if ( \! -e _ ) {
     mkdir (\"\$tmp_dir/REQUESTS\", 0770 )
        || &panic(\"Cannot create directory \$tmp_dir/REQUESTS : \$\!\") ;
     chmod 0770, \"\$tmp_dir/REQUESTS\" ;
}

# ---------------------------------------------
# input 
#
# read form variables and create parameters' variables
# special cases : 
#     handle file/raw data input
#     sequence format conversion
#     mandatory variables with default value
#     hidden parameters' variables to initialize

my \$user_level = (\$input->param('simple'))? \"simple\" : \"advanced\";

";

# control of multiple identical requests
# You may implement this control, but you will need to customize
# it (see multiple_requests procedure)
if ($PASTEUR) {
print "
# control of multiple identical requests
my \$requests_stat = &multiple_requests;
if ( \$requests_stat == 1) {
    &user_error (\"Two similar jobs have been submitted (you have probably clicked twice on the \\\"Run $command\\\" button?). Both jobs are cancelled. Please try again.\",0);
} elsif (\$requests_stat == 2) {
    &user_error (\"A similar job has already been submitted. Please wait for its completion.\",1);
}
";
}

print "
if (! \$input->param('email')) {
      if (! \$input->param('email2')) {
        if (not \$defs->opt_email) {
           &user_error (\"<I>email</I> has no value\");
	}
      } else {
	  \$input->param('email',\$input->param('email2'));
      }
}
if (\$input->param('email')) {
   (\$email = \$input->param('email')) =~ s/\\s//g ;
   \$input->param('email',\$email);
   if ( ! (\$email  =~ /^(\\w|-|\\+|,|@|\\.(?!\\.))+\$/ ) ) {
      &user_error (\"<I>email</I> = \$email : this value is not allowed\");
   }
}
";

if ($PASTEUR) {
print "
if (\$email) {
   \$email .= '\@pasteur.fr' unless (\$email =~ /\\\@/);
   \$email_status = Pasteur::Email::Valid(\$email);
   if (\$email_status eq undef) {
      &user_error (\"<I>email</I> = \$email : this address is not valid\");
   }
}
";
}

print "
if (\$email) {
  \$email =~ s|\\\@|\\\\\$&|g;
  \$input->param('email',\$email);
  if (&not_wanted (\$input->param('email'))) {
    &user_error (\"\$email: the service is not available for now.\");
  }
}
";

print " 
if (\$email) {
    if (not (check_local_only(\$email_status, $command))) {
	&user_error (\"$email: the service is for local use only.\");
    } 
} 
";

#
# Prevent too many jobs under PBS 
# and redirect to existing mirrors, if available.
#
if ($PASTEUR and $PBS) {
print "
if (\$email) {
   my \$queue = batch_queue(\$email_status, \"$command\");
   my \$busy = check_queue_busy(\$queue);
   if (\$busy) {
      my \@mirrors = get_mirrors($command);
      my \$date=`date`;
      chop(\$date);
      print STDERR \"\$date: CGI for $command: \$queue busy\\n\";
      my \$user_msg = \"$command: the server is too busy. Try again later.\";
      if (\$\#mirrors >= 0) {
	  \$user_msg .= \"You can find a similar service at the following location(s):<UL>\";
	  foreach my \$m (\@mirrors) {
	      my \$m_href = \"<A HREF=\\\"\$m\\\">\$m</A>\";
	      \$user_msg .= \"<LI>\" . \$m_href . \"</LI>\";
	  }
	  \$user_msg .= \"</UL>\";
      }
      &user_error (\$user_msg);
   }
}
";
}

print "
foreach \$param (
";

foreach $param ( $defs->parameters_order ) {
         print "      \"$param\", \n";
}
print " 
) {
    next if (\$defs->type(\$param) eq \"Results\"); 

    if (\$defs->ishidden(\$param)) {
       if ( \$defs->format(\$param,'perl') !~ /\\s*/  ) {
	   &set_var(\$param, 
                    &my_eval (\$defs->format(\$param,'perl'))) ;
       } elsif ( \$defs->vdef(\$param) ) {
           &set_var(\$param, 
                    &my_eval (\$defs->vdef(\$param))) ;
       }
       if (\$@) { 
           &panic(\"Cannot eval: \". \$defs->format(\$param,'perl')) ;
       }
       next ;
    }

    \$prompt = \$defs->prompt(\$param);

    \# input data : file or raw data
    if (\$defs->type(\$param) eq \"InFile\" || 
        \$defs->type(\$param) eq \"Sequence\") {
          # hidden string containing piped file
          \$paramstring = \$param . \"_string\";
	  if (\$input->param(\$paramstring)) {
	      # print STDERR \"hidden file name = \",\$input->param(\$paramstring),\"\\n\";
	      \$fname=\$input->param(\$paramstring);
	      \$fname=`basename \$fname`;
	      chop(\$fname);
#	      (\$from_cmd=\$input->param(\$paramstring)) =~ s/(\\/\\w+)+\\/(\\w+)\\/(\\d+).*/\$2/;
#	      (\$from_cmd=\$input->param(\$paramstring)) =~ s/(\$tmp_dir)\\/(\\w+)\\/(\\d+).*/\$2/;
	      # for PBS jobname, you need the tmp dir to begin with a letter
	      (\$from_cmd=\$input->param(\$paramstring)) =~ s/(\$tmp_dir)\\/(\\w+)\\/(A\\d+).*/\$2/;
	      \$fname = \"\$from_cmd.\$fname\";
	      &set_var (\$param,\$fname);
	      #print STDERR \"new hidden file name = \$fname\\n\";
	      # modif letondal 090399:
              # system(\"cp \$input->param(\$paramstring) \$scratch_dir/\$fname\");
	      system(\"ln -s \" . \$input->param(\$paramstring) . \" \$scratch_dir/\$fname\");
	      system(\"touch \" . \$input->param(\$paramstring));
	  }
          \$paramdata = \$param . \"_data\";
	  if (\$input->param(\$paramdata) =~ /^\\s+\$/ ) {
	      \$input->param(\$paramdata, \"\");
	  }
          if (\$input->param(\$param) && \$input->param(\$paramdata) ) {
               &user_error (\"<I>\$prompt</I> : enter either the filename or the data, not both\"); 
          } 
          # raw data
          if (\$input->param(\$paramdata)) {
               \$rawdata = join (\"\", 
				 split (\"\\r\", 
					\$input->param(\$paramdata)));
               chomp(\$rawdata);
	       if (\$DBSEARCH) {
		   \@rawdata_lines = split(\"\\n\",\$rawdata);
		   \$rawdata_line_nb = 0;
		   \$rawdata_sequences = \"\";
		   while (\$rawdata_lines[\$rawdata_line_nb] =~ /^\\s*(\\w+)\\:(\\w+)\\s*\$/) {
		       \$rawdata_db=\$1;
		       \$rawdata_id=\$2;
#		   print STDERR \"DEBUG> rawdata_lines[\$rawdata_line_nb] = \$rawdata_lines[\$rawdata_line_nb]\\n\";
		       \$rawdata_sequence = get_dbentry(\$rawdata_db,\$rawdata_id);
#		   print STDERR \"DEBUG> rawdata_sequence=\$rawdata_sequence\\n\";
		       if (\$rawdata_sequence) {
			   \$rawdata_sequences .= \$rawdata_sequence;
		       }
		       \$rawdata_line_nb++;
		   }
		   if (\$rawdata_sequences) {
		       \$rawdata = \$rawdata_sequences;
		   }
	       }
               &set_var (\$param,
			 \"\$param.data\");
               open(RAWDATA, \"> \$scratch_dir/\$param.data\") 
                      || &panic (\"Cannot create \$param.data file\");
               print RAWDATA \"\$rawdata\\n\";
               close (RAWDATA) || &panic (\"A problem occured while writing \$param.data: \$!\");
          }
          # file upload
          if (\$input->param(\$param)) {
	      upload_file(\$param);
	  }
     }

     if ( \$input->param(\$param) ne \"\" ) {
           if (\$defs->type(\$param) eq \"List\") {
	       my \@list = \$input->param(\$param);
               if (defined \$defs->separator(\$param)) {
	           \$separator = \$defs->separator(\$param) ;
		   &set_var (\$param, join (\"\$separator\", sort \@list ));
	       } else {
		   &set_var (\$param, join ('', sort \@list ));
	       }
           } else {
                (\$value = \$input->param(\$param)) =~ s/\\s//g;
		if ( &get_var(\$param) eq \"\") {
		    &set_var (\$param, \$value) ;
		}
           }
     } else {
           if ( \$defs->ismandatory(\$param) ) {
               if ( defined \$defs->vdef(\$param) && \$defs->vdef(\$param) ne \"\" ) {
                   &set_var (\$param, \$defs->vdef(\$param));
               }
           }
     }


}
";

#----------------------------------------------
# control input parameters values : 
#     - security
#     - mandatory parameters
#     - program specific controls
# special cases :
#     - hidden, Results
#     - precond applies here
#     - if parameter for parameters file : not the same security controls

print "    
foreach \$param (
";
foreach $param ( $defs->parameters_order ) {
         print "      \"$param\", \n";
}
print " 
) {
     next if (\$defs->type(\$param) eq \"Results\"); 
     next if (\$defs->ishidden(\$param));
     \$precond = &my_eval (\$defs->precond(\$param,'perl'));
     if (\$@) { 
         &panic(\"Cannot eval: \" . \$defs->precond(\$param,'perl'));
     }
     next if ( ! \$precond );

     undef \$value;
     \$prompt = \$defs->prompt(\$param);

     if ( &def_var(\$param) ) {    
					  
	\$value = &get_var(\$param) ;
#	print STDERR \"DEBUG> $command: \$param = \$value\\n\";
        unless (defined \$defs->paramfile(\$param)) {

             # security controls on values if on command line

             if (\$defs->type(\$param) eq \"List\" ) {
                 # test each different value ...
                 \$separator = \$defs->separator(\$param);
		 foreach \$v (split (\$separator, \&get_var(\$param) )) {
		     (\$w = \$v) =~ s/\\\'/\\\'/g ;
                     if (! (grep { \$w eq \$_ } \$defs->vlist(\$param) )) {
                         &user_error (\"<I>\$prompt</I> = \$v: this value is not allowed\");
		     }
		 }
             } elsif (\$defs->type(\$param) eq \"Switch\") {
		 if (\$value ne \"on\") {
		     &user_error (\"<I>\$prompt</I> = \$value: this value is not allowed\");
		 } else {
		     &set_var(\$param, \"True\");
		     \$value = \"True\";
		 }

             } elsif (\$defs->type(\$param) eq \"InFile\" || 
                      \$defs->type(\$param) eq \"Sequence\" ) {

             } elsif (\$defs->type(\$param) eq \"Excl\") {
		 (\$v = \$value) =~ s/\\\'/\\\'/g ;
                 if ( ! (grep { \$v eq \$_ } \$defs->vlist(\$param)) ) {
		     &user_error (\"<I>\$prompt</I> = \$value: this value is not allowed\");
		 }
	     } elsif ( ! ( \$value =~ /^(\\w|-|\\+|,|\\.(?!\\.))+\$/ ) ) {
		 &user_error (\"<I>\$prompt</I> = \$value: this value is not allowed\");
	     }
	 } 

         if (\$defs->type(\$param) eq \"InFile\" || 
              \$defs->type(\$param) eq \"Sequence\" ) {

		 (\$fname=\$value) =~ s|\$scratch_dir/|| ;
		 if ( ! ( \$fname =~ /^(\\w|-|\\+|\\.(?!\\.))+\$/ ) ) {
		     (\$user_part = \$fname) =~ s/_\\d+\$// ;
		     &user_error (\"<I>\$prompt</I> = \$user_part: this value is not allowed\");
		 }

                 push (\@infiles, \$fname);
                 &set_var (\"value\", \$fname);
                 &set_var (\$param, \$fname);
         }

     }

     unless ( &def_var(\$param) ) {
          if ( \$defs->ismandatory(\$param) ) {
	      &user_error (\"<I>\$prompt</I> has no value\");
          }
     }

     # program specific controls
     if ( defined \$defs->ctrl(\$param) ) {
          &set_var(\"vdef\",\$defs->vdef(\$param));
          &set_var(\"value\",\$value);
 	  \%ctrl = \$defs->ctrl(\$param,'perl');
          foreach \$test (keys %ctrl) {
             \$test_pos = &my_eval (\"\$test\");
	     if ( \$@) { 
		 &panic(\"Cannot eval \$test\") ;
	     }
	     if (\$test_pos ) {
                 \$msg = \$defs->ctrl(\$param,'perl',\$test);
		 &user_error (\"\$msg (<I>\$prompt</I>)\");
	     }
	  }
     }

}
";

#----------------------------------------------------------
# sequence format conversion

print "
foreach \$param (
";

foreach $param ( $defs->parameters_order ) {
         print "      \"$param\", \n";
}
print " 
) {

    ## TMP: sequence format detection (nico+patch CL 2/12/04)
    if ($PASTEUR && &def_var(\$param) && \$defs->type(\$param) eq \"Sequence\" ) {
      require \"\$WEB_LIB/convseq3.pl\";
      my \$seqfile = &get_var(\$param);
      my \@fmtlist = \$defs->seqfmt(\$param);
      my \@res;
      my \$res_outfmt = \"\";
      my \$res_infmt;
      my \$res_prg;
      if (defined \$defs->seqfmt(\$param)) {
	  \@res = convseq_convert(\"\$scratch_dir/\$seqfile\", \@fmtlist); 
	  \$res_prg = \$res[0];
	  \$res_infmt = \$res[1];
	  \$res_outfmt = \$res[2];
	  if ((\$res_outfmt ne \"unknown\") and
	      (\$res_infmt ne \$res_outfmt)) {
	      \$fromfmtseq{\$param} = \$res_infmt;
	      \$tofmtseq{\$param} = \$fmtlist[0];
	      \$prgfmtseq{\$param} = \$res_prg;
	  }
      } else {
	  \@res = convseq_format(\"\$scratch_dir/\$seqfile\"); 
	  \$res_prg = \$res[0];
	  \$res_infmt = \$res[1];
      }
      my \$date=localtime;
      if (\$res_infmt eq \"unknown\") {
	  \$squizz_warning{\$param} = \"FormatError\";
	  print STDERR \"[\$date] squizz error (FormatError) for \$scratch_dir/\$seqfile\\n\";
      } elsif (\$res_prg ne \"squizz\") {
	  \$squizz_warning{\$param} = \"FormatWarning\";
	  print STDERR \"[\$date] squizz warning (\$res_prg) (FormatWarning) for \$scratch_dir/\$seqfile\\n\";
      }
      if (\$res_infmt ne \"unknown\" and \$res_outfmt  eq \"unknown\") {
	  \$squizz_warning{\$param} = \"DataError\";
	  print STDERR \"[\$date] squizz error (DataError: sequences to alignment) for \$scratch_dir/\$seqfile\\n\";
      }
    }
    
    if ((not $PASTEUR) && &def_var(\$param) && \$defs->type(\$param) eq \"Sequence\" && defined \$defs->seqfmt(\$param)) {
    # convert sequence(s) to right format (if given)
	\@seqfmt = \$defs->seqfmt(\$param);
	\$value=&get_var(\$param);
	\$seqfile = (\$value =~ m|^\$scratch_dir|) ? 
                   \"\$value\" : \"\$scratch_dir/\$value\" ;
	if ((\$have_readseq || \$have_fmtseq || \$have_clustalw) && \$seqfile !~ /^\$scratch_dir\\/\$/) {
	    \$current_fmt= &which_seqfmt(\$seqfile) ;
	    if (! \$current_fmt ) {
		# detect 1 line raw seq (pb with readseq)
		\$newseqfile = try_1lineseq (\$seqfile);
		if (\$newseqfile) {
		    \$current_fmt= &which_seqfmt(\$newseqfile) ;
		    unlink \$seqfile;
		    rename(\$newseqfile,\$seqfile);
		}
	    }  
	    if (\$current_fmt && 
                (! (grep {\$current_fmt eq \$_} \@seqfmt)) ) {
                \$tofmt= \$seqfmt[0];
	        \$convfile=\$seqfile . \".\" . \$main::seqfmtssuff{\$tofmt};
	        &convseqfmt(\$seqfile,\$convfile,\$tofmt,\$current_fmt);
	        rename (\$seqfile, \"\$seqfile.orig\" ) || &panic(\"cannot rename \$seqfile:\$!\");
	        stat(\$convfile);
	        if (-e _) {
	            rename(\$convfile,\$seqfile);
		}
	        \$fromfmtseq{\$param} = \$current_fmt;
	        \$tofmtseq{\$param} = \$tofmt;
            } else {
		# let's try the sequence ... ?
	    }
        }
    }

}
";

#----------------------------------------------------------
# command line construction

print "
chdir(\"\$scratch_dir\") 
                  || die \"can\'t cd to \$scratch_dir: \$!\";
my \$actual_parameters = \&do_command(\$defs);
\&do_stdout(\$defs);
if ( \$defs->_interface_standout ) {
     \$defs->_standout_file(\"$command.out\");
#     print STDERR \"DEBUG> standout file:\",\$defs->_standout_file,\"\\n\";
}

\$actual_parameters =~ s|\$scratch_dir/||g ;

";

print "

#----------------------------------------------------------
# generate a script for this specific job
#----------------------------------------------------------

my \$scriptfile = \"\$scratch_dir/script\";
my \$htmlfile = \"\$scratch_dir/index.html\";
my \$scratch_url = \"\$tmp_url/$command/\$scratch_nb\" ;

open (SCRIPT, \"> \$scriptfile\") 
               || &panic (\"Cannot create $command script file (\$scriptfile)\");

print SCRIPT \"\#! /local/bin/perl\\n\" ;
print SCRIPT \"\# script generated from the \$user_level form\\n\" ;
print SCRIPT \"\# _User_: \$email\\n\\n\" ;
print SCRIPT \"use lib \\\"/local/gensoft/lib/Pise/5.a/PerlDef\\\"; \\n\";
print SCRIPT \"eval (\\\"use $command;\\\");\\n\" ;
print SCRIPT \"\\\$defs = $command->new;\\n\" ;
print SCRIPT \"require \\\"/local/gensoft/lib/Pise/5.a/PerlDef/pipeins\\\";\\n\" ;
";

print "
print SCRIPT \"use MIME::Lite;\\n\" ;
print SCRIPT \"use Mail::Internet;\\n\" ;

print SCRIPT \"require \\\"\$WEB_LIB/convseq.pl\\\";\\n\";
print SCRIPT \"require \\\"\$WEB_LIB/evaluation.pl\\\";\\n\";
print SCRIPT \"umask 007 ; \\n\" ;
print SCRIPT \"\\\$SCRATCH_DIR=\\\"\$scratch_dir\\\" ; \\n\" ;
print SCRIPT \"\\\$SCRATCH_URL=\\\"\$scratch_url\\\";\\n\"; 
print SCRIPT \"\\\$HTMLFILE=\\\"\$htmlfile\\\" ; \\n\" ;
print SCRIPT \"\\\$REQUESTFILE=\\\"\$::request_file\\\" ; \\n\" ;
print SCRIPT \"\\\$REQUESTPID=\\\"\$::request_file.pid\\\" ; \\n\" ;
print SCRIPT \"\\\$REQUEST_JOBNAME=\\\"\$::request_file.jobname\\\" ; \\n\" ;
print SCRIPT \"chdir(\\\"\$scratch_dir\\\");\\n\";
print SCRIPT \"\\\$SIG{USR1} = \\\"cgi_detach\\\" ;\\n\";
print SCRIPT \"\\\$father_gone = 0 ;\\n\" ;
#print SCRIPT \"my \\\$email ;\\n\" ;
";


print " 
print SCRIPT \"sub mail_results {\\n\" ;
print SCRIPT \"   return if (not \\\$email);\\n\" ;
print SCRIPT \"   my \\\$message;\\n\" ;
print SCRIPT \"   if (\\\$results_type eq \\\"attachment\\\") {\\n\";
print SCRIPT \"      \\\$message = new MIME::Lite ( From    => \\\"\\\$email\\\",\\n\"; 
print SCRIPT \"                To      => \\\"\\\$email\\\" ,\\n\";
print SCRIPT \"                Subject => \\\"$command attached results files\\\" ,\\n\";
print SCRIPT \"                Type    => \\\'multipart/mixed\\\' ) ;\\n\";
print SCRIPT \"   }\\n\";
print SCRIPT \"   \\\$tot_size = 0;\\n\";
print SCRIPT \"   foreach \\\$file (\\\@files_to_send) {\\n\";
print SCRIPT \"      stat(\\\$file);\\n\";
print SCRIPT \"      \\\$size = (-s _ );\\n\";
print SCRIPT \"      \\\$tot_size += \\\$size;\\n\";
print SCRIPT \"      if (\\\$size > 0) {\\n\";
print SCRIPT \"         if (\\\$results_type eq \\\"attachment\\\" && \\\$tot_size < $MAXMAILSIZE) {\\n\";
print SCRIPT \"            \\\$message->attach ( Type        => \\\'TEXT\\\' ,\\n\";
print SCRIPT \"				          Encoding    => \\\'base64\\\' ,\\n\";
print SCRIPT \"				          Disposition => \\\'attachment\\\' ,\\n\";
print SCRIPT \"				          Path        => \\\"\\\$file\\\" ) ;\\n\";
print SCRIPT \"         } elsif (\\\$size < $MAXMAILSIZE) {\\n\";
print SCRIPT \"             send_file_email(getpwuid(\\\$<) . \\\"\\\\\\\@$MAILHOST\\\",\\\"\\\$email\\\",\\\"$command \\\$file\\\",\\\$file);\\n\" ;
print SCRIPT \"         }\\n\";
print SCRIPT \"      }\\n\";
print SCRIPT \"   }\\n\";
print SCRIPT \"   if (\\\$results_type eq \\\"attachment\\\") {\\n\";
print SCRIPT \"      \\\$message->send ( ) ;\\n\";
print SCRIPT \"   }\\n\";
print SCRIPT \"}\\n\";

print SCRIPT \"sub unlock_request {\\n\" ;
print SCRIPT \"   stat \\\$REQUESTFILE;\\n\";
print SCRIPT \"   if ( -e _ ) { unlink \\\$REQUESTFILE; }\\n\";
print SCRIPT \"   stat \\\$REQUESTPID;\\n\";
print SCRIPT \"   if ( -e _ ) { unlink \\\$REQUESTPID; }\\n\";
print SCRIPT \"   stat \\\$REQUEST_JOBNAME;\\n\";
print SCRIPT \"   if ( -e _ ) { unlink \\\$REQUEST_JOBNAME; }\\n\";
print SCRIPT \"}\\n\";

print SCRIPT \"sub results {\\n\";
print SCRIPT \"    my \\\@l;\\n\";
foreach \$param ( \$defs->parameters_order ) {

    next unless ( \$defs->type(\$param) eq \"Results\" );

    \$precond = \$defs->precond(\$param,'perl');
    if ( defined \$defs->precond(\$param,'perl') && 
            ! &my_eval(\"\$precond\") ) {
        next;
    }
    if ( \$defs->filenames(\$param) =~ /\\\"/ ) {
        \$filenames = &my_eval (\$defs->filenames(\$param));
    } else {
        \$filenames = &my_eval ('\"' . \$defs->filenames(\$param) . '\"');
    }
    print SCRIPT \"    open (LS, \\\"ls \$filenames 2> /dev/null |\\\");\\n\";
    print SCRIPT \"    while (<LS>) {\\n\";
    print SCRIPT \"        chop ;\\n\";
    print SCRIPT \"        \\\$f=\\\$_;\\n\";
    print SCRIPT \"        \\\$param{\\\$f}=\$param;\\n\";
    print SCRIPT \"	   push (\\\@l, \\\$f) unless (grep {\\\$f  eq \\\$_ } \\\@l);\\n\";
    print SCRIPT \"    }\\n\";
    print SCRIPT \"    close (LS);\\n\";

}
print SCRIPT \"    return \\\@l\\n\";
print SCRIPT \"}\\n\";

print SCRIPT \"sub clean_files {\\n\" ;
my \%isclean = \$defs->isclean;
foreach \$param (keys \%isclean) {
    \$precond = &my_eval (\"\$defs->precond(\$param,'perl')\");
    next if ( ! \$precond );

    next if (! \$isclean{\$param} );
    next unless (defined \$defs->filenames(\$param));
    if ( \$defs->filenames(\$param) =~ /\\\"/ ) {
        \$filenames = &my_eval (\$defs->filenames(\$param));
    } else {
        \$filenames = &my_eval ('\"' . \$defs->filenames(\$param) . '\"');
    }

    print SCRIPT \"     open (LS, \\\"ls \$filenames |\\\") || &mail_maintainer(\\\"pb ls \$filenames: \\\$!\\\") ; \\n\" ;

    print SCRIPT \"     while (<LS>) {\\n\" ;
    print SCRIPT \"          chop ; \\n\" ;
    print SCRIPT \"          \\\$f = \\\$_ ; \\n\" ;
    print SCRIPT \"          stat(\\\"\\\$f\\\");\\n\";
    print SCRIPT \"          if ( -e _ ) {\\n\";
    print SCRIPT \"#               unlink \\\$f;\\n\";
    print SCRIPT \"          } \\n\" ;
    print SCRIPT \"     } \\n\" ;
    print SCRIPT \"     close (LS) ; \\n\" ;
}
print SCRIPT \"}\\n\" ;

print SCRIPT \"sub panic {\\n\";
print SCRIPT \"     \\\$msg=\\\$_[0];\\n\";
print SCRIPT \"     \\\$no_mail=\\\$_[1];\\n\";
print SCRIPT \"     &mail_maintainer(\\\$msg) unless (\\\$no_mail);\\n\" ;
";

if ($PASTEUR) {
print "
print SCRIPT \"     &unlock_request;\\n\" ;
";
}
print "
print SCRIPT \"     exit 1; \\n\" ;
print SCRIPT \"}\\n\";

print SCRIPT \"sub cgi_detach {\\n\" ;
print SCRIPT \"     \\\$father_gone = 1 ;\\n\" ;
print SCRIPT \"     rename(\\\$REQUESTFILE,\\\"\\\$REQUESTFILE.detached\\\");\\n\" ;
print SCRIPT \"     \\\$REQUESTFILE=\\\"\\\$REQUESTFILE.detached\\\"\\n\" ;
print SCRIPT \"}\\n\" ;

print SCRIPT \"sub send_email {\\n\" ;
print SCRIPT \"     my \\\$from=\\\$_[0];\\n\";
print SCRIPT \"     my \\\$to=\\\$_[1];\\n\";
print SCRIPT \"     my \\\$subject=\\\$_[2];\\n\";
print SCRIPT \"     my \\\$msg=\\\$_[3];\\n\";
print SCRIPT \"     my \\\$mail = new Mail::Internet ( [ \\\"From: \\\$from\\\" ,\\n\";
print SCRIPT \"                                        \\\"To: \\\$to\\\" ,\\n\";
print SCRIPT \"                                        \\\"Subject: \\\$subject\\\" ] ,\\n\";
print SCRIPT \"                                        'Body' => [ \\\$msg ] ) ;\\n\";

print SCRIPT \"     \\\$ENV{MAILADDRESS} =  \\\$from;\\n\";
print SCRIPT \"     # RFC2219\\n\";
print SCRIPT \"     \\\$mail->smtpsend ( 'Host' => '$MAILHOST' ) ;\\n\";
print SCRIPT \"}\\n\" ;

print SCRIPT \"sub send_file_email {\\n\" ;
print SCRIPT \"     my \\\$from=\\\$_[0];\\n\";
print SCRIPT \"     my \\\$to=\\\$_[1];\\n\";
print SCRIPT \"     my \\\$subject=\\\$_[2];\\n\";
print SCRIPT \"     my \\\$file=\\\$_[3];\\n\";
print SCRIPT \"     my \\\$msg = `cat \\\$file`;\\n\";
print SCRIPT \"     chomp(\\\$msg);\\n\";
print SCRIPT \"     send_email(\\\$from,\\\$to,\\\$subject,\\\$msg);\\n\" ;
print SCRIPT \"}\\n\" ;

print SCRIPT \"sub mail_maintainer {\\n\" ;
print SCRIPT \"     \\\$msg=\\\$_[0];\\n\";
my \$m;
(\$m = \$MAINTAINER) =~ s|\\\@|\\\\\$&|g ;
print SCRIPT \"      send_email(getpwuid(\\\$<) . \\\"\\\\\\\@$MAILHOST\\\",\\\"\$m\\\",\\\"message from script $command:  \\\$msg\\\",\\\$msg);\\n\" ;
print SCRIPT \"}\\n\" ;

#--------------------
# temporary HTML file

print SCRIPT \"open (HTMLFILE, \\\"> \\\$HTMLFILE \\\") || &panic(\\\"Cannot create $command html file (\\\$HTMLFILE):\\\$!\\\") ;\\n\";

#print SCRIPT \"print HTMLFILE \\\"<?xml version=\\\\\\\"1.0\\\\\\\" encoding=\\\\\\\"iso-8859-1\\\\\\\"?>\\\\n\\\";\\n\";
print SCRIPT \"print HTMLFILE \\\"<!DOCTYPE html PUBLIC \\\\\\\"-//W3C//DTD XHTML 1.0 Strict//EN\\\\\\\" \\\\\\\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\\\\\\\">\\\\n\\\";\\n\";

print SCRIPT \"print HTMLFILE \\\"<HTML>\\\\n\\\";\\n\";
\$script_hypertext_title = gettitle(\$defs);
\$script_hypertext_title =~ s/\\\"/\\\\\\\"/g;
print SCRIPT \"print HTMLFILE \\\"<HEAD><TITLE>\$title</TITLE>\\\\n\\\";\\n\";
print SCRIPT \"print HTMLFILE \\\" <link rel=\\\\\\\"stylesheet\\\\\\\" href=\\\\\\\"$ROOT_URL/pise.css\\\\\\\" />\\\\n\\\";\\n\";
print SCRIPT \"print HTMLFILE \\\"</HEAD>\\\\n\\\";\\n\";
print SCRIPT \"print HTMLFILE \\\"<BODY>\\\\n\$script_hypertext_title<HR></HR>\\\\n\\\";\\n\";
print SCRIPT \"print HTMLFILE \\\"<STRONG>Results not available yet</STRONG><BR></BR>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"<UL>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"<LI>you will receive an email upon completion of the job</LI>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"<LI>don't forget to <I>reload</I> this page then</LI>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"</UL>\\\\n\\\" ;\\n\";
if (\$defs->reference) {
   print SCRIPT \"print HTMLFILE \\\"<HR></HR>\\\\n\\\" ;\\n\";
   print SCRIPT \"print HTMLFILE \\\"<A NAME=\\\\\\\"REFERENCE\\\\\\\">References</A>:\\\\n\\\";\\n\";
   my \@references = \$defs->reference;
   foreach my \$reference (\@references) {
      print SCRIPT \"print HTMLFILE \\\"<BR></BR>\$reference\\\\n\\\";\\n\";
   }
}
print SCRIPT \"print HTMLFILE \\\"<HR></HR>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"<I><A HREF=\\\\\\\"http://www.pasteur.fr/recherche/unites/sis/Pise/\\\\\\\">Pise</A> CGI generator version \$version</I>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"</BODY></HTML>\\\\n\\\";\\n\";

print SCRIPT \"close (HTMLFILE);\\n\";

#----------------
# actual job     

print SCRIPT \"map { close \\\$_ } (0..15);\\n\";
print SCRIPT \"open (STDIN, \\\"/dev/null\\\");\\n\"; 
";

if ($LSF) {
print "

print SCRIPT \"open (STDERR, \\\"> \\\$SCRATCH_DIR/bsub.err\\\");\\n\";
\$jobname=\$scratch_nb;

\$lsf_queue = get_lsf_queue (\$email_status, $command);
\$lsf_command = \"$lsf_command\" . \" -q \$lsf_queue -J \$jobname\";

print SCRIPT \"open (BSUB, \\\"| \$lsf_command\\\");\\n\"; 
print SCRIPT \"print BSUB \\\"\$actual_parameters\\\\n\\\";\\n\";
print SCRIPT \"close BSUB;\\n\";

print SCRIPT \"close(STDIN);close(STDOUT);close(STDERR);\\n\";
\$request_jobname = \"\$::request_file.jobname\";
open(JOBNAME,\"> \$request_jobname\") || die \"cannot open \$request_jobname:\$!\";
print JOBNAME \"\$jobname\\n\";
close (JOBNAME);
";

} elsif ($PBS) {
print "

print SCRIPT \"use Fcntl ':flock';\\n\";

\$jobname=\$scratch_nb;
\$queue = batch_queue (\$email_status, \"$command\");
\$batch_command = pbs_command(\"$command\", \$queue, \$jobname);
\$wrapper = \"\$WEB_LIB/wrapper.pl\";

print SCRIPT \"open(CMDS, \\\"> \\\$SCRATCH_DIR/.command\\\");\\n\";
print SCRIPT \"print CMDS \\\"\$actual_parameters\\\\n\\\";\\n\";
print SCRIPT \"close CMDS;\\n\";

## PBS does not use umask values
print SCRIPT \"open(CMDS, \\\"> \\\$SCRATCH_DIR/$command.out\\\");\\n\";
print SCRIPT \"close CMDS;\\n\";
print SCRIPT \"open(CMDS, \\\"> \\\$SCRATCH_DIR/$command.err\\\");\\n\";
print SCRIPT \"close CMDS;\\n\";

print SCRIPT \"open (STDOUT, \\\"> \\\$SCRATCH_DIR/.qsub\\\");\\n\";

print SCRIPT \"open (BSUB, \\\"| \$batch_command\\\");\\n\";
print SCRIPT \"print BSUB \\\"cd \\\$SCRATCH_DIR && \$wrapper\\\\n\\\";\\n\";
print SCRIPT \"close BSUB;\\n\";
print SCRIPT \"if (\\\$?) {\\n\";
print SCRIPT \"  my \\\$err = \\\$? >> 8;\\n\";
print SCRIPT \"  &panic(\\\"\\\$SCRATCH_DIR: PBS command failed: \\\$err\\\\n\\\"); }\\n\";

print SCRIPT \"while ( ! -f \\\"\\\$SCRATCH_DIR/.lock\\\") { sleep 1; }\\n\";
print SCRIPT \"open LOCK, \\\">> \\\$SCRATCH_DIR/.lock\\\";\\n\";
## HACK: system calls fail if interrupted by signals, add a second one
## to remain locked ...
print SCRIPT \"flock LOCK, LOCK_EX or flock LOCK, LOCK_EX;\\n\";
print SCRIPT \"flock LOCK, LOCK_UN;\\n\";
print SCRIPT \"close LOCK;\\n\";

print SCRIPT \"close(STDIN);close(STDOUT);close(STDERR);\\n\";

\$request_jobname = \"\$::request_file.jobname\";
open(JOBNAME,\"> \$request_jobname\") || die \"cannot open \$request_jobname:\$!\";
print JOBNAME \"\$jobname\\n\";
close (JOBNAME);

";
} else {
# BATCH: this may need to be redefined
   print "
if ( \$defs->_interface_standout ) {
    print SCRIPT \"open (STDOUT, \\\"> \\\$SCRATCH_DIR/$command.out\\\");\\n\";
} else {
    my \$standout = \$defs->_standout_file ;
    print SCRIPT \"open (STDOUT, \\\"> \\\$SCRATCH_DIR/\$standout\\\");\\n\";
}
print SCRIPT \"open (STDERR, \\\"> \\\$SCRATCH_DIR/$command.err\\\");\\n\";
print SCRIPT \"system(\\\"\$actual_parameters\\\");\\n\";
print SCRIPT \"close(STDIN);close(STDOUT);close(STDERR);\\n\";
";

}

#------------------------------------
# Handle potentially entered email
#
print "
print SCRIPT \"\\\$email = \\\"\$email\\\";\\n\";
print SCRIPT \"if (\\\$father_gone) {\\n\" ; 
";
print " 
if (not \$email) { 
        print SCRIPT \"     stat \\\".email\\\";\\n\" ;
        print SCRIPT \"     if ( -e _ ) {\\n\";
        print SCRIPT \"         require \\\".email\\\";\\n\" ; 
        print SCRIPT \"     }\\n\";
} 
";

print "
print SCRIPT \"}\\n\" ;
";

print "
#------------------------------------
# give access to results in HTML page
#
# - output files
# - std error
# - input files
# - message if sequence format conversion
#

print SCRIPT \"open (HTMLFILE, \\\"> \\\$HTMLFILE \\\") || &panic(\\\"Cannot create $command html file (\\\$HTMLFILE):\\\$!\\\") ;\\n\";

######print SCRIPT \"if (\\\$father_gone) {\\n\" ;
#print SCRIPT \"     print HTMLFILE \\\"<?xml version=\\\\\\\"1.0\\\\\\\" encoding=\\\\\\\"iso-8859-1\\\\\\\"?>\\\\n\\\";\\n\";
print SCRIPT \"     print HTMLFILE \\\"<!DOCTYPE html PUBLIC \\\\\\\"-//W3C//DTD XHTML 1.0 Strict//EN\\\\\\\" \\\\\\\"http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd\\\\\\\">\\\\n\\\";\\n\";

print SCRIPT \"     print HTMLFILE \\\"<HTML>\\\\n\\\";\\n\";
print SCRIPT \"     print HTMLFILE \\\"<HEAD><TITLE>\$title</TITLE>\\\\n\\\";\\n\";

print SCRIPT \"print HTMLFILE \\\" <link rel=\\\\\\\"stylesheet\\\\\\\" href=\\\\\\\"$ROOT_URL/pise.css\\\\\\\" />\\\\n\\\";\\n\";

print SCRIPT \"     print HTMLFILE \\\"</HEAD>\\\\n<BODY>\$script_hypertext_title\\\\n\\\";\\n\";
#######print SCRIPT \"}\\n\" ;

my \$warning_started = 0;
my \$f_url;
my \$squizz_warning_message = \"\";
my \$error_type;
foreach \$param (keys %squizz_warning) {
    my \$f_orig = &get_var(\$param) . \".orig\";
    stat ( \"\$scratch_dir/\$f_orig\" );
    if ( -e _ ) {
     \$f_url = \$scratch_url . \"/\" . \$f_orig;
    } else {
     \$f_url = \$scratch_url . \"/\" . &get_var(\$param);
    }
    if (\$warning_started == 1) {
       \$squizz_warning_message .= \"<BR></BR>\";
    } else {
       \$warning_started = 1;
    }
    \$error_type = \$squizz_warning{\$param};
    if (\$error_type eq \"DataError\") {
      \$squizz_warning_message .= \"<DIV class=\\\"\$error_type\\\"><B>\$error_type: the sequence data <A HREF=\\\"\$f_url\\\" TARGET=\\\"_top\\\">\" . &get_var(\$param) . \"</A> might be of wrong type. Please check required input data type (a set of sequences <i>is not</i> an alignment). Your results are probably incorrect. <BR></BR>You might also look at the documentation: <UL><LI><A HREF=\\\"http://bioweb.pasteur.fr/docs/man/man/seqfmt.1.html\\\" TARGET=\\\"_top\\\">seqfmt</A> for sequences,</LI><LI> <A HREF=\\\"http://bioweb.pasteur.fr/docs/man/man/alifmt.1.html\\\" TARGET=\\\"_top\\\">alifmt</A> for alignments.</LI></UL></B></DIV>\\n\";
    } else {
      \$squizz_warning_message .= \"<DIV class=\\\"\$error_type\\\"><B>\$error_type: the sequence data <A HREF=\\\"\$f_url\\\" TARGET=\\\"_top\\\">\" . &get_var(\$param) . \"</A> might have an incorrect format. You should check your data and results. <BR></BR>Please look at the documentation: <UL><LI><A HREF=\\\"http://bioweb.pasteur.fr/docs/man/man/seqfmt.1.html\\\" TARGET=\\\"_top\\\">seqfmt</A> for sequences,</LI><LI> <A HREF=\\\"http://bioweb.pasteur.fr/docs/man/man/alifmt.1.html\\\" TARGET=\\\"_top\\\">alifmt</A> for alignments.</LI></UL></B></DIV>\\n\";
    }
    
}
if (\$warning_started == 1) {
    print SCRIPT \"if (\\\$father_gone) {\\n\" ;
    print SCRIPT \"    print HTMLFILE \\\"<HR></HR>\\\\n\\\" ;\\n\";
    print SCRIPT \"}\\n\" ;
    \$squizz_warning_message =~ s/\\\"/\\\\\\\"/g;
    \$squizz_warning_message =~ s/\\\\n/\\\\\\n/g;
    print SCRIPT \"print HTMLFILE \\\"\$squizz_warning_message\\\\n\\\" ;\\n\";
    print SCRIPT \"print HTMLFILE \\\"<HR></HR>\\\\n\\\" ;\\n\";
}

print SCRIPT \"print HTMLFILE \\\"<STRONG>Results:</STRONG><BR></BR>\\\\n\\\" ;\\n\";

# connexions: write forms for output files that can be used
# as input in others programs

print SCRIPT \"sub piped_programs {\\n\" ;
print SCRIPT \"    my \\\$type=\\\$_[0];\\n\" ;
print SCRIPT \"    return (sort(keys %{ \\\$pipein{\\\$type} }));\\n\" ;
print SCRIPT \"}\\n\" ;

print SCRIPT \"sub bigmail {\\n\" ;
print SCRIPT \"     (\\\$dev,\\\$ino,\\\$mode,\\\$nlink,\\\$uid,\\\$gid,\\\$rdev,\\\$size, \\\$atime,\\\$mtime,\\\$ctime,\\\$blksize,\\\$blocks) = stat(\\\$_[0]);\\n\" ;		      
print SCRIPT \"     \\\$some_bigmail=1 if (\\\$size > \$MAXMAILSIZE);\\n\";
print SCRIPT \"     return 1 if (\\\$size > \$MAXMAILSIZE);\\n\";
print SCRIPT \"     return 0;\\n\";
print SCRIPT \"}\\n\";


print SCRIPT \"sub print_form {\\n\" ;
print SCRIPT \"   my \\\$param = \\\$_[0];\\n\" ;
print SCRIPT \"   my \\\$fname = \\\$_[1];\\n\" ;
print SCRIPT \"   if (defined \\\$defs->pipeout(\\\$param)) {\\n\" ;
print SCRIPT \"         my \\\%pipeout = \\\$defs->pipeout(\\\$param);\\n\" ;

print SCRIPT \"         print HTMLFILE \\\"\\\\n<FORM name=\\\\\\\"connect_\\\$param\\\\\\\" method=\\\\\\\"POST\\\\\\\" action=\\\\\\\"$CGI_URL/lib/connect.pl\\\\\\\">\\\\n\\\" ;\\n\";

print SCRIPT \"         print HTMLFILE \\\"\\\\n<SELECT NAME=\\\\\\\"command\\\\\\\">\\\\n\\\" ;\\n\";
print SCRIPT \"         foreach \\\$test (keys \\\%pipeout ) { \\n\" ;
print SCRIPT \"            \\\$type = \\\$defs->pipeout(\\\$param,\\\$test);\\n\" ;
print SCRIPT \"            \\\@piped_programs = &piped_programs(\\\$type);\\n\" ;
print SCRIPT \"            foreach \\\$program (\\\@piped_programs) {\\n\" ;

print SCRIPT \"               print HTMLFILE \\\"\\\\n<OPTION VALUE=\\\\\\\"\\\$program\\\\\\\">\\\$program</OPTION>\\\\n\\\" ;\\n\";

print SCRIPT \"            }\\n\";


print SCRIPT \"            print HTMLFILE \\\"\\\\n</SELECT>\\\\n\\\" ;\\n\";
print SCRIPT \"            my \\\$fname_html = \\\$fname;\\n\";
print SCRIPT \"            \\\$fname_html =~ s/</\\&lt;/g;\\n\";
print SCRIPT \"            \\\$fname_html =~ s/>/\\&gt;/g;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT TYPE=\\\\\\\"submit\\\\\\\" VALUE=\\\\\\\"Run the selected program on \\\$fname_html\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"scratch_dir\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$command/\$scratch_nb\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"piped_file\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$fname_html\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"piped_variable\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$param\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"piped_file_type\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$type\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"email\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$email\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"user_level\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$user_level\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"pise_version\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$VERSION\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"PISEDIR\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$PISEDIR\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n</FORM>\\\\n\\\" ;\\n\";
print SCRIPT \"         }\\n\" ;
print SCRIPT \"   }\\n\" ;
print SCRIPT \"}\\n\" ;

require \"/local/gensoft/lib/Pise/5.a/PerlDef/pipeins\";

sub piped_programs {
    my \$type=\$_[0];
    return (sort(keys %{  \$pipein{\$type} }));
}
sub print_form {

   my \$param = \$_[0];
   if (defined \$defs->pipeout(\$param)) {
       my \%pipeout = \$defs->pipeout(\$param);
       foreach \$test (keys %pipeout) {
         \$result = &my_eval (\"\$test\");
	 if ( \$@) {
	     &panic(\"Cannot eval \$test\") ;
	 }
#	 print STDERR \"DEBUG> param=\$param test=\$test results=\$result\\n\";
	 if (\$result ) {

print SCRIPT \"print HTMLFILE \\\"\\\\n<FORM name=\\\\\\\"connect_\$param\\\\\\\" method=\\\\\\\"POST\\\\\\\" action=\\\\\\\"$CGI_URL/lib/connect.pl\\\\\\\">\\\\n\\\" ;\\n\";

print SCRIPT \"print HTMLFILE \\\"\\\\n<SELECT NAME=\\\\\\\"command\\\\\\\">\\\\n\\\" ;\\n\";
              \$type = \$defs->pipeout(\$param,\$test);
	      \@piped_programs = &piped_programs(\$type);
              \$fname=&get_var(\$param) ;
              foreach \$program (\@piped_programs) {
		  undef \$with_piped_files;
		  \$virgule=\"\";
                  foreach \$param_name (\$defs->withpipeout(\$param,\$type)) {
		      if (\$param_name =~ /=/) {
		          (\$out_param,\$in_param) = split (\"=\",\$param_name);
			  \$param_value=&get_var(\$out_param);
			  if (\$param_value) {
			      \$with_piped_files .= \$virgule . \"\$in_param=\" .\$param_value ;
			  }
		      } else {
			  \$param_value=&get_var(\$param_name);
			  if (\$param_value) {
			      \$with_piped_files .= \$virgule . \"\$param_name=\" . \$param_value;
			  }
		      }
		      \$virgule=\",\";
		  }
print SCRIPT \"            my \\\$with_piped_files_html = \\\"\$with_piped_files\\\";\\n\";
print SCRIPT \"            \\\$with_piped_files_html =~ s/</\\&lt;/g;\\n\";
print SCRIPT \"            \\\$with_piped_files_html =~ s/>/\\&gt;/g;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<OPTION VALUE=\\\\\\\"\$program,\\\$with_piped_files_html\\\\\\\">\$program</OPTION>\\\\n\\\" ;\\n\";
              }

print SCRIPT \"print HTMLFILE \\\"\\\\n</SELECT>\\\\n\\\" ;\\n\";
print SCRIPT \"            my \\\$fname_html = \\\"\$fname\\\";\\n\";
print SCRIPT \"            \\\$fname_html =~ s/</\\&lt;/g;\\n\";
print SCRIPT \"            \\\$fname_html =~ s/>/\\&gt;/g;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT TYPE=\\\\\\\"submit\\\\\\\" VALUE=\\\\\\\"Run the selected program on \\\$fname_html\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"scratch_dir\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$command/\$scratch_nb\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"piped_file\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$fname_html\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"piped_variable\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$param\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"piped_file_type\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$type\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"         print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"email\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$email\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"user_level\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$user_level\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"         print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"pise_version\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$VERSION\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"            print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"PISEDIR\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$PISEDIR\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";

print SCRIPT \"print HTMLFILE \\\"\\\\n</FORM>\\\\n\\\" ;\\n\";
          }
      }
   }
}

print SCRIPT \"sub printed_size {\\n\";
print SCRIPT \"    my \\\$size = \\\$_[0];\\n\";
print SCRIPT \"    my \\\$size_string;\\n\";
print SCRIPT \"    if (\\\$size < 1000) {\\n\";
print SCRIPT \"       \\\$size_string = \\\"\\\";\\n\";
print SCRIPT \"    } elsif (\\\$size < 100000) {\\n\";
print SCRIPT \"       \\\$size /= 1000;\\n\";
print SCRIPT \"       \\\$size_string = sprintf(\\\"%.2f Ko\\\",\\\$size);\\n\";
print SCRIPT \"    } else {\\n\";
print SCRIPT \"       \\\$size /= 1000000;\\n\";
print SCRIPT \"       \\\$size_string = sprintf(\\\"%.2f Mo\\\",\\\$size);\\n\";
print SCRIPT \"    }\\n\";
print SCRIPT \"    return \\\$size_string\\n\";
print SCRIPT \"}\\n\";

print SCRIPT \"sub file_size {\\n\";
print SCRIPT \"    my \\\$f = \\\$_[0];\\n\";
print SCRIPT \"    my \\\$size;\\n\";
print SCRIPT \"    stat(\\\$f);\\n\";
print SCRIPT \"    \\\$size = (-s _ );\\n\";
print SCRIPT \"    my \\\$i  = 5;\\n\";
print SCRIPT \"    while (\\\$size == 0 && \\\$i > 0) {\\n\";
print SCRIPT \"       sleep 1;\\n\";
print SCRIPT \"       stat(\\\$f);\\n\";
print SCRIPT \"       \\\$size = (-s _ );\\n\";
print SCRIPT \"       \\\$i--;\\n\";
print SCRIPT \"    }\\n\";
print SCRIPT \"    return \\\$size\\n\";
print SCRIPT \"}\\n\";

print SCRIPT \"sleep 2;\\n\";

print SCRIPT \"\\\@results = &results;\\n\";
print SCRIPT \"foreach \\\$f (\\\@results) {\\n\";
print SCRIPT \"    next if (\\\$f eq \\\"index.html\\\");\\n\";
#print SCRIPT \"    stat(\\\$f);\\n\";
#print SCRIPT \"    my \\\$size = (-s _ );\\n\";
print SCRIPT \"    my \\\$size = file_size(\\\$f);\\n\";
print SCRIPT \"    my \\\$f_html = \\\$f;\\n\";
print SCRIPT \"    \\\$f_html =~ s/</\\&lt;/g;\\n\";
print SCRIPT \"    \\\$f_html =~ s/>/\\&gt;/g;\\n\";
print SCRIPT \"    my \\\$size_string = printed_size(\\\$size);\\n\";
print SCRIPT \"    if (\\\$size_string eq \\\"\\\") {\\n\";
print SCRIPT \"        print HTMLFILE \\\"<P></P><A HREF=\\\\\\\"\\\$SCRATCH_URL/\\\$f_html\\\\\\\" TARGET=\\\\\\\"_top\\\\\\\">\\\$f_html</A>\\\\n\\\" ;\\n\";
print SCRIPT \"    } else {\\n\";
print SCRIPT \"        print HTMLFILE \\\"<P></P><A HREF=\\\\\\\"\\\$SCRATCH_URL/\\\$f_html\\\\\\\" TARGET=\\\\\\\"_top\\\\\\\">\\\$f_html</A> (\\\$size_string)\\\\n\\\" ;\\n\";
print SCRIPT \"    }\\n\";
#print SCRIPT \"    if (-e _ && -s _) {\\n\";
#print SCRIPT \"    if (\\\$size > 0) {\\n\";
print SCRIPT \"          \\\&print_form(\\\$param{\\\$f},\\\$f);\\n\";
#print SCRIPT \"    }\\n\";
print SCRIPT \"}\\n\";

my \$f;
\@outfiles = \&outfiles;
foreach \$f (\@outfiles) {
    print SCRIPT \"unless (grep {\\\"\$f\\\" eq \\\$_ } \\\@results) {\\n\";
    print SCRIPT \"    stat(\\\"\\\$SCRATCH_DIR/\$f\\\");\\n\";
    print SCRIPT \"    my \\\$size = (-s _ );\\n\";
    print SCRIPT \"    my \\\$size_string = printed_size(\\\$size);\\n\";
    print SCRIPT \"    \\\$f_html = \\\"\$f\\\";\\n\";
    print SCRIPT \"    \\\$f_html =~ s/</\\&lt;/g;\\n\";
    print SCRIPT \"    \\\$f_html =~ s/>/\\&gt;/g;\\n\";
#    print SCRIPT \"    if ( \\\$size != 0 ) {\\n\";
    print SCRIPT \"         if ( \\\$size_string eq \\\"\\\" ) {\\n\";
    print SCRIPT \"              print HTMLFILE \\\"<P></P><A HREF=\\\\\\\"\\\$SCRATCH_URL/\\\$f_html\\\\\\\" TARGET=\\\\\\\"_top\\\\\\\">\\\$f_html</A>\\\\n\\\" ;\\n\";
    print SCRIPT \"         } else {\\n\";
    print SCRIPT \"              print HTMLFILE \\\"<P></P><A HREF=\\\\\\\"\\\$SCRATCH_URL/\\\$f_html\\\\\\\" TARGET=\\\\\\\"_top\\\\\\\">\\\$f_html</A> (\\\$size_string)\\\\n\\\" ;\\n\";
    print SCRIPT \"         }\\n\";
#    stat(\$f);
#    if (-e _ && -s _) {			    
                            \&print_form(\$param{\$f});
#    }
#    print SCRIPT \"    }\\n\";
    print SCRIPT \"}\\n\";
}

#print SCRIPT \"print HTMLFILE \\\"<BR></BR>\\\$SCRATCH_DIR/$command.err<BR></BR>\\\";\\n\";
#print SCRIPT \"stat(\\\"\\\$SCRATCH_DIR/$command.err\\\");\\n\";
#print SCRIPT \"if ( -e _ && -s _ ) {\\n\";
print SCRIPT \"     print HTMLFILE \\\"<P></P><A HREF=\\\\\\\"\\\$SCRATCH_URL/$command.err\\\\\\\" TARGET=\\\\\\\"_top\\\\\\\">standard error file</A>\\\\n \\\" ;\\n\";
print SCRIPT \"     \\\$stderr_not_empty=1;\\n\";
#print SCRIPT \"}\\n\";

print SCRIPT \"print HTMLFILE \\\"<HR></HR>From now, this files will remain accessible for \$result_remain days at: <A HREF=\\\\\\\"\$scratch_url\\\\\\\">\$scratch_url/</A>\\\\n\\\\\\\n\\\";\\n\";
print SCRIPT \"print HTMLFILE \\\"<BR></BR>You can save them individually by the <STRONG>Save file</STRONG> function if needed.\\\\n\\\";\\n\";
my \$help;


(\$help = \$HELP) =~ s|\\\@|\\\\\$&|g ;

#print SCRIPT \"print HTMLFILE \\\"<HR></HR>Please tell us your <A HREF=\\\\\\\"mailto:\$help\\\\\\\">remarks or questions</A>, or if you have major problems.\\\\n\\\";\\n\" ;

# ------------------
# job summary button
# ------------------

print SCRIPT \"print HTMLFILE \\\"\\\\n<FORM name=\\\\\\\"summary\\\\\\\" method=\\\\\\\"POST\\\\\\\" action=\\\\\\\"$CGI_URL/lib/summary.pl\\\\\\\">\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"email\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$email\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"command\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$command\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"scratch_dir\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$command/\$scratch_nb\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"pise_version\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$VERSION\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"PISEDIR\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$PISEDIR\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
(\$unix_command = \$actual_parameters) =~ s/\\\"/\\\'/g;
\$unix_command =~ s/&/&amp;/g;
\$unix_command =~ s/</&lt;/g;
\$unix_command =~ s/>/&gt;/g;
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"unix_command\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$unix_command\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"user_level\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$user_level\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT TYPE=\\\\\\\"submit\\\\\\\" VALUE=\\\\\\\"Job summary\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n <SELECT name=\\\\\\\"summary_format\\\\\\\">\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<OPTION SELECTED=\\\\\\\"yes\\\\\\\" VALUE=\\\\\\\"normal\\\\\\\"> default format\</OPTION>\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<OPTION VALUE=\\\\\\\"freetext\\\\\\\"> free text</OPTION>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<OPTION VALUE=\\\\\\\"tabular\\\\\\\"> tabular</OPTION>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n</SELECT>\\\\n\\\" ;\\n\";
";

# save every parameter of the form and its value
print "
    foreach \$param (
";
foreach $param ($defs->parameters_order ) {
         print "      \"$param\", \n";
}

print "
    ) { 
	my \$type = \$defs->type(\$param);
	if (\$type eq \"List\") {
	    \@value = \$input->param(\$param);
	    print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"\$param\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\@value\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
	} else {
	    \$value=&get_var(\$param);
	    print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"\$param\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$value\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
	}

";

print " 
}
";

print "
print SCRIPT \"print HTMLFILE \\\"\\\\n</FORM>\\\\n\\\" ;\\n\";

# -------------------------
# end of job summary button
# -------------------------


(\$unix_command = \$actual_parameters) =~ s/\\\"/\\\'/g;
\$unix_command =~ s/&/&amp;/g;
\$unix_command =~ s/</&lt;/g;
\$unix_command =~ s/>/&gt;/g;
print SCRIPT \"print HTMLFILE \\\"<HR></HR><I>Unix exact command:</I><BR></BR><CODE>\$unix_command</CODE>\\\\n\\\" ;\\n\";

if ( \$#infiles >= 0 ) {
         print SCRIPT \"print HTMLFILE \\\"<HR></HR>\\\\n\\\";\\n\";
         print SCRIPT \"print HTMLFILE \\\"Your input data:\\\\n\\\";\\n\";
         foreach \$f (\@infiles) {
             \$f =~ s|\$scratch_dir/||g ;
	     print SCRIPT \"print HTMLFILE \\\"<BR></BR><A HREF=\\\\\\\"\\\$SCRATCH_URL\/\$f\\\\\\\" TARGET=\\\\\\\"_top\\\\\\\">\$f</A>\\\\n\\\";\\n\";
         }
}

foreach \$param (keys %fromfmtseq) {
	 \$fromfmt=\$fromfmtseq{\$param};
	 if (defined \$main::seqfmtsdesc{\$fromfmt}) {
	     \$fromfmtdesc=\$main::seqfmtsdesc{\$fromfmt};
	 } else {
	     \$fromfmtdesc=\$fromfmt;
	 }
	 \$tofmt=\$tofmtseq{\$param};
	 if (defined \$main::seqfmtsdesc{\$tofmt}) {
	     \$tofmtdesc=\$main::seqfmtsdesc{\$tofmt};
	 } else {
	     \$tofmtdesc=\$tofmt;
	 }
	 \$prgfmt = \$prgfmtseq{\$param};
	 print SCRIPT \"print HTMLFILE \\\"<P></P>The sequence file \", 
                      &get_var(\$param), \" has been converted from <I>\$fromfmtdesc</I> format to <I>\$tofmtdesc</I> format by the <I>\$prgfmt</I> program.\\\\n\\\" ;\\n\";
}

# -----------
# help button
# -----------

print SCRIPT \"print HTMLFILE \\\"\\\\n<HR></HR><FORM name=\\\\\\\"help\\\\\\\" method=\\\\\\\"POST\\\\\\\" action=\\\\\\\"$CGI_URL/lib/mailhelp.pl\\\\\\\">\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"email\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\\\$email\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"command\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$command\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"scratch_dir\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$command/\$scratch_nb\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"pise_version\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$VERSION\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"PISEDIR\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"$PISEDIR\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
(\$unix_command = \$actual_parameters) =~ s/\\\"/\\\'/g;
\$unix_command =~ s/&/&amp;/g;
\$unix_command =~ s/</&lt;/g;
\$unix_command =~ s/>/&gt;/g;
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"unix_command\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$unix_command\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"helpform\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"1\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"freetext\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"1\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";

print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT TYPE=\\\\\\\"submit\\\\\\\" VALUE=\\\\\\\"Help\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
";

# save every parameter of the form and its value
print "
    foreach \$param (
";

foreach $param ($defs->parameters_order ) {
         print "      \"$param\", \n";
}

print "

    ) {
	my \$type = \$defs->type(\$param);
	if (\$type eq \"List\") {
	    \@value = \$input->param(\$param);
	    print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"\$param\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\@value\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
	} else {
	    \$value=&get_var(\$param);
	    print SCRIPT \"print HTMLFILE \\\"\\\\n<INPUT NAME=\\\\\\\"\$param\\\\\\\" TYPE=\\\\\\\"HIDDEN\\\\\\\" VALUE=\\\\\\\"\$value\\\\\\\"></INPUT>\\\\n\\\" ;\\n\";
	}

";

print "
}
";

print "
print SCRIPT \"print HTMLFILE \\\"\\\\n</FORM>\\\\n\\\" ;\\n\";

# ------------------
# end of help button
# ------------------

if (\$defs->reference) {
   print SCRIPT \"print HTMLFILE \\\"<HR></HR>\\\\n\\\" ;\\n\";
   print SCRIPT \"print HTMLFILE \\\"<A NAME=\\\\\\\"REFERENCE\\\\\\\">References</A>:\\\\n\\\";\\n\";
   my \@references = \$defs->reference;
   foreach my \$reference (\@references) {
      print SCRIPT \"print HTMLFILE \\\"<BR></BR>\$reference\\\\n\\\";\\n\";
   }
}
print SCRIPT \"print HTMLFILE \\\"<HR></HR><I><A HREF=\\\\\\\"http://www.pasteur.fr/recherche/unites/sis/Pise/\\\\\\\">Pise</A> CGI generator version \$version</I>\\\\n\\\" ;\\n\";
print SCRIPT \"print HTMLFILE \\\"<HR></HR>\\\\n\\\" ;\\n\";


#####print SCRIPT \"if (\\\$father_gone) {\\n\" ;
print SCRIPT \"     print HTMLFILE \\\"</BODY></HTML>\\\\n\\\";\\n\";
#####print SCRIPT \"}\\n\" ;


print SCRIPT \"close (HTMLFILE);\\n\";
print SCRIPT \"&clean_files;\\n\";


print SCRIPT \"# let father know I am finished (but only if not gone)\\n\";
print SCRIPT \"if (! \\\$father_gone) {\\n\" ;
print SCRIPT \"     kill 'USR1', getppid;\\n\";
#print SCRIPT \"     kill 'USR1', \$\$;\\n\";
print SCRIPT \"     # synchronization\\n\";
print SCRIPT \"     sleep 10;\\n\";
print SCRIPT \"}\\n\" ;


print SCRIPT \"if (\\\$father_gone) {\\n\" ;
";
print "
print SCRIPT \"     stat \\\".results\\\";\\n\" ;
print SCRIPT \"     if ( -e _ ) { \\n\";
print SCRIPT \"       require \\\".results\\\";\\n\" ; 
print SCRIPT \"     } else {\\n\"; 
"; 
if ($DONT_EMAIL_RESULTS) {
   print "
print SCRIPT \"       \\\$results_type=\\\"url\\\";\\n\"; 
";
} else {
   print "
print SCRIPT \"       \\\$results_type=\\\"files\\\";\\n\"; 
";
} 
print "
print SCRIPT \"     }\\n\"; 
"; 

print "
print SCRIPT \"     if (\\\$results_type ne \\\"url\\\" && \\\$stderr_not_empty) {\\n\";
print SCRIPT \"           push (\\\@files_to_send, \\\"$command.err\\\");\\n\"; 
print SCRIPT \"}\\n\";

\# mail des fichiers de sortie
print SCRIPT \"if (\\\$results_type ne \\\"url\\\") {\\n\";
foreach \$f (\@outfiles) {
	 next if (\$f =~ /\\\.html/) ;
	 print SCRIPT \"     stat(\\\"\\\$SCRATCH_DIR/\$f\\\");\\n\";
	 print SCRIPT \"     if ( -s _ && (! bigmail(\\\"\$f\\\")) ) {\\n\";
         print SCRIPT \"          push (\\\@files_to_send, \\\"\$f\\\");\\n\"; 
	 print SCRIPT \"     }\\n\";
}
print SCRIPT \"}\\n\";

print SCRIPT \"if (\\\$results_type ne \\\"url\\\") {\\n\";
print SCRIPT \"  foreach \\\$f (\\\@results) {\\n\";
print SCRIPT \"	    next if (\\\$f =~ /\\\\\\.html/) ; \\n\";
print SCRIPT \"	    next if (bigmail (\\\"\\\$f\\\")) ; \\n\";
print SCRIPT \"      push (\\\@files_to_send, \\\"\\\$f\\\");\\n\"; 
print SCRIPT \"  }\\n\";
print SCRIPT \"}\\n\";

my \$url=\"\$scratch_url\/index.html\";
print SCRIPT \"     \\\$URL=\\\"\$url\\\" ; \\n\";
my \$warning=\"available for \$result_remain days\";
print SCRIPT \"     if (\\\$some_bigmail) {\\n\";
\$msg=\"Some files were too big to be sent by email. They are available at the following URL:\$url\";
print SCRIPT \"         \\\$MSG=\\\"\$msg\\\" ; \\n\";
print SCRIPT \"        send_email(getpwuid(\\\$<)  . \\\"\\\\\\\@$MAILHOST\\\",\\\"\\\$email\\\",\\\"access all $command results URL (\$warning)\\\",\\\$MSG);\\n\" ;
print SCRIPT \"     } elsif (\\\$results_type ne \\\"url\\\" && \\\$\\\#files_to_send > 10) {\\n\";
\$msg=\"There are too many files to be sent by email. They are available at the following URL:\$url\";
print SCRIPT \"         \\\$results_type=\\\"url\\\" ; \\n\";
print SCRIPT \"         \\\$MSG=\\\"\$msg\\\" ; \\n\";
print SCRIPT \"        send_email(getpwuid(\\\$<)  . \\\"\\\\\\\@$MAILHOST\\\",\\\"\\\$email\\\",\\\"access all $command results URL (\$warning)\\\",\\\$MSG);\\n\" ;
print SCRIPT \"     } else {\\n\";
print SCRIPT \"        send_email(getpwuid(\\\$<) . \\\"\\\\\\\@$MAILHOST\\\",\\\"\\\$email\\\",\\\"access all $command results URL (\$warning)\\\",\\\$URL);\\n\" ;
print SCRIPT \"        &mail_results;\\n\";
print SCRIPT \"     }\\n\";

#print SCRIPT \"if (\\\$results_type ne \\\"url\\\") {\\n\";
#print SCRIPT \"    &mail_results;\\n\";
#print SCRIPT \"}\\n\";

print SCRIPT \"}\\n\" ; # if father_gone
";

if ($PASTEUR) {
print "
print SCRIPT \"&unlock_request;\\n\";
";
}

print "
close SCRIPT ;
chmod 0770 , \$scriptfile;

#------------------------------------------------------
# log

my \$remote = \$ENV{'REMOTE_HOST'};
if (! \$remote) {
    \$remote = \$ENV{'REMOTE_ADDR'};
}

my \$d=`date`;
chop(\$d);
my \$new_log=0;
stat(\$LOG);
if ( ! -e ) {
    \$new_log=1;
}
open (LOG, \">> \$LOG\") || &panic (\"Cannot open log file \$LOG:\$!\");
if (\$email) {
   print LOG \"$command||\$user_level form||\$actual_parameters||\$email||\$scratch_dir||\$d||\$remote||\\n\";
} else {
    print LOG \"$command||\$user_level form||\$actual_parameters||NO_EMAIL||\$scratch_dir||\$d||\$remote||\\n\";
}

close LOG;
if (\$new_log) {
    system(\"chmod 660 \$LOG\");
    # chgrp soft...?
}

#-------------------------------------------------------
# run the script
#-------------------------------------------------------
#

\$SIG{CHLD} = \"child_end\";
\$SIG{USR1} = \"child_usr1\";

if ( \$pid = fork ) {
	 \# father

#	 print STDERR \"CGI (\$\$) waiting (\$child_wait seconds) for $command child (\$pid)\\n\";

	 \$request_pid = \"\$::request_file.pid\";
	 open(PID,\"> \$request_pid\") || die \"cannot open \$request_pid:\$!\";
	 print PID \"\$pid\\n\";
	 close (PID);

         sleep \$child_wait;
	 
#	 print STDERR \"CGI not waiting anymore for $command child (\$pid) [done? \$child_done]\\n\";
         if ( \$child_done ) {
           \# print HTML result
#	   print STDERR \"printing HTML results page (\$htmlfile)\\n\";
	   open(HTMLRES, \$htmlfile) || &panic(\"cannot read html result (\$htmlfile)\");
	   while (<HTMLRES>) {
	       next if (/<.xml/);
	       next if (/XHTML/);
	       next if (/<\\/?HTML>/);
	       next if (/<\\/?BODY>/);
	       next if (/<HEAD>/);
	       next if (/<\\/?HEAD>/);
	       next if (/<link>/);
	       print;
	   }
######	   print while (<HTMLRES>);
	   close(HTMLRES);
         } elsif (\$child_err) {
	     &panic(\"An error occured while executing $command\", 1);
         } else {

	     # detach child, i.e: don't wait for results, let child know it
#	     print STDERR \"CGI for $command detach child (\$pid)\\n\";
	     kill 'USR1', \$pid ;
	     print \"<HR></HR>\";
#	     if (\$email_status eq 'remote') {
#	         print \"<strong>Your $command job has been submitted with an \\\"external user\\\" priority.</strong>\\n\";
#	     } else {
#		 print \"<strong>Your $command job has been submitted with a \\\"local user\\\" priority.</strong>\\n\";
#	     }
	     print \"<strong>Your $command job has been submitted</strong>\\n\";
             if (\$input->param('email')) {
         	     (\$tmp_email=\$input->param('email')) =~ s/\\\\// ;
	     }
 	     print \"<HR></HR>\\n\";
";

print "

my \$info = information_message('long_job');
if (\$info) {
         print \"<HR></HR><I>\$info</I><HR></HR>\\n\";
}

	     if (\$warning_started) {

		 \$squizz_warning_message =~ s/\\\\//g;
		 print \"\$squizz_warning_message\\n\";
		 print \"<FORM name=\\\"cancel\\\" method=\\\"POST\\\" action=\\\"http://bioweb.pasteur.fr/cgi-bin/seqanal/lib/cancel_job.pl\\\">\\n\";
		 print \"<INPUT NAME=\\\"command\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"$command\\\"></INPUT>\\n\";
		 print \"<INPUT NAME=\\\"scratch_dir\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"$command/\$scratch_nb\\\"></INPUT>\\n\";
		 print \"<INPUT NAME=\\\"email\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"\$email\\\"></INPUT>\\n\";
		 print \"<INPUT TYPE=\\\"submit\\\" VALUE=\\\"Cancel this job\\\"></INPUT>\\n\";
		 print \"</FORM >\\n\"; 
		 print \"<HR></HR>\\n\";
	     }

";

if ($DONT_EMAIL_RESULTS) {
       print "
       if (\$email) {
  	     print \"<BR></BR>End of job will be notified <I>by email</I> to: <STRONG>\$tmp_email</STRONG>\\n\";
             print \"<INPUT NAME=\\\"results_type\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"url\\\"></INPUT>\\n\"; 
       }
";
} else {
       print "
             if (\$email) {
		 print \"<BR></BR>Results files will be sent <I>by email</I> to: <STRONG>\$tmp_email</STRONG>\\n\";
		 print \"<BR></BR>You may change the way you will receive these results <I>(you don't have to confirm the default choice)</I>.\\n\";
	     } else {
		 print \"<BR></BR>You may request to receive results files by email.\\n\";
             }
#	     print \"<BR></BR>Type of e-mail you wish to receive:\\n\";
             print \"<FORM name=\\\"results\\\" method=\\\"POST\\\" action=\\\"$CGI_URL/lib/results.pl\\\">\\n\";
             if (\$email) {
                print \"<INPUT NAME=\\\"email\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"\$email\\\"></INPUT>\\n\";
             } else {
		 print \"<B>Email:</B>\\n\";
                 print \"<INPUT NAME=\\\"email\\\" SIZE=40></INPUT><BR></BR>\\n\";
             }
             print \"<INPUT NAME=\\\"command\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"$command\\\"></INPUT>\\n\";
             print \"<INPUT NAME=\\\"scratch_dir\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"$command/\$scratch_nb\\\"></INPUT>\\n\";
             print \"<INPUT NAME=\\\"PISEDIR\\\" TYPE=\\\"HIDDEN\\\" VALUE=\\\"$PISEDIR\\\"></INPUT>\\n\";
             if (\$email) {
                 print \"<INPUT TYPE=\\\"submit\\\" VALUE=\\\"Change results reception to ...\\\"></INPUT>\\n\";
             } else {
                 print \"<INPUT TYPE=\\\"submit\\\" VALUE=\\\"Set E-mail.\\\"></INPUT>\\n\";
             }
             print \"<SELECT NAME=\\\"results_type\\\">\\n\";
             print \"<OPTION VALUE=\\\"files\\\"> one result file by email (default)</OPTION>\\n\";
             print \"<OPTION SELECTED=\\\"yes\\\" VALUE=\\\"url\\\"> notification only (with url)</OPTION>\\n\";
             print \"<OPTION VALUE=\\\"attachment\\\"> results as MIME email attachments</OPTION>\\n\";
             print \"</SELECT>\\n\";

             print \"</FORM >\\n\"; 
";
}

print "
       if (\$email) {
	     print \"<BR></BR>Results will also be available <I>upon completion of the job</I> <A HREF=\\\"\$url\\\" TARGET=\\\"_top\\\">here</A> (wait for the email).\\n\";
       } else {
	     print \"<BR></BR>Results will be available <I>upon completion of the job</I> <A HREF=\\\"\$url\\\" TARGET=\\\"_top\\\">here</A>.\\n\";
       }
	     print \"<P></P>\";
             print \"Please wait for the results of this query before submitting another query request. Thank-you.\\n\";
	     print \"<P></P>\";
             my \$tmp_help = \$help;
             \$tmp_help =~ s/\\\\//;
	     print \"Please tell us your <A HREF=\\\"mailto:\$tmp_help\\\">remarks or questions</A>, or if you have major problems.\\n\" ;
	     print \"<HR></HR>\";
(\$unix_command = \$actual_parameters) =~ s/&/&amp;/g;
\$unix_command =~ s/</&lt;/g;
\$unix_command =~ s/>/&gt;/g;
	     print \"<I>Unix exact command:</I><BR></BR>\\\"\$unix_command\\\"<BR></BR>\\n\";
             if (\$defs->reference) {
		 print \"<HR></HR>\" ;
		 print \"<A NAME=\\\"REFERENCE\\\">References</A>:\\n\";
		 my \@references = \$defs->reference;
		 foreach my \$reference (\@references) {
		     print \"<BR></BR>\$reference\\n\";
		 }
	     }
	     print \"<HR></HR>\";
             print \"<I><A HREF=\\\"http://www.pasteur.fr/recherche/unites/sis/Pise/\\\">Pise</A> CGI generator version \$version</I><HR></HR>\\n\" ;
	 }
} elsif ( defined \$pid ) {
    # child
    setpgrp();
    exec \"$nice_command /local/bin/perl \$scriptfile \" ;
    \&panic (\"Cannot exec script file: \$!\");
} else {
    \&panic (\"Cannot fork: \$!\");
}

print \"</BODY></HTML>\\n\";

close(STDOUT);


exit;


";


1;


