from Pise import PiseFactory

email = 'letondal@pasteur.fr'
query ='MALK_ECOLI'
db = "swissprot"

factory = PiseFactory(email=email)
golden = factory.program("golden")
golden.query(query)
golden.db(db)
job = golden.run()

if job.error():
    print job.error_message()
else:
    print job.jobid()


