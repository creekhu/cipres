#
# Pasteur specific checks
#

## Checks for valid local users
sub check_local {
  my ($who) = @_;

  my $local = $who;
  $local =~ s/\\\@pasteur\.fr$//;
  $local =~ tr/A-Z/a-z/;

  if ($local eq "pise-bioapi") { return 0; }

  ## Check user list
  my $found = 0;
  open(PASS, "< /bioweb/etc/passwd") or
    die "Cannot open: /bioweb/etc/passwd: !$\n";
  while(<PASS>) {
    chomp;
    next if (! /^$local$/);
    $found = 1; last; }
  close(PASS);
  
  ## Found ... ok
  if ($found == 1) { return 0; }

  ## Not found ... err
  my $date = localtime;
  my $remote = $ENV{'REMOTE_HOST'} || $ENV{'REMOTE_ADDR'};
  my $msg = "not allowed on this server (for now)";
  print STDERR "[$date] User $who ($local) from $remote: $msg\n";

  return 1; }

1;
