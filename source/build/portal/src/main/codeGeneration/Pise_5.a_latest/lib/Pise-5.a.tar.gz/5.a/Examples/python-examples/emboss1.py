from Pise import PiseFactory
from Bio.SeqIO import FASTA
import sys

handle = open(sys.argv[1])
it = FASTA.FastaReader(handle)
seq = it.next()
handle.close()
  
factory = PiseFactory(email='letondal@pasteur.fr')

cusp = factory.program('cusp',
                       location='http://jeeves.bimcore.emory.edu:7000/cgi-bin/Pise/5.a/cusp.pl',
                       sequence = seq,
                       verbose=1)
j=cusp.run()
if j.error():
    print "Error: " + j.error_message()
else:
    j.verbose(0)
    print "Output:\n", j.content(".out")


