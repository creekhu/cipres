#TODO:

require "/local/gensoft/lib/Pise/5.a/lib/web.pl";

sub panic {
  my($msg) = @_;
  print STDERR $msg, "\n";
  die;
}
sub clean_esc {
    my $s = $_[0];
    $s =~ s/\\//g ;
    return $s;
}

sub print_headers {

    my $defs = $_[0];
    my $user_level = $_[1];

    $begin_file = "begin.html";

    print "<html>\n";
    print "<head>\n";
    print "<title>\n";
    my $title = $defs->title;
    print "$title\n";
    print "</title>\n";
    print "</head>\n";
    print "<body>\n";
    print "<h1>\n";
    
    if ($defs->description) {
        $title_name = $defs->title; 
	$title_text = ": " . $defs->description;
        if ($defs->authors) {
	    if ($defs->reference) {
		$title_text .= " (<a href=\"$www_gensoft\#REFERENCE\">" . $defs->authors . "</a>)";
	    } else {
		$title_text .= " (" . $defs->authors . ")";
	    }
	}
    } else {
	@title_parts = split(' ', $defs->title);
        $title_name = $title_parts[0]; 
        $title_text = join(' ',@title_parts[1..$#title_parts]);
    }
    $doc_aname = $title_name;
    $doc_aname =~ s/-//g ; 
    $doc_aname =~ s/\://g ;
    $doc_aname =~ tr/a-z/A-Z/ ;
    if ($defs->doclink) {
	print "<a href=\"",$defs->doclink,"\">$title_name</a> $title_text\n";
    } else {
	# this is an url where to find documentation about (all) programs
	# the name of the program, say 'xx' will be appended (#xx) 
	# not used if $PASTEUR=0
	if ($PASTEUR) {
	    $www_gensoft = "http://bioweb.pasteur.fr/docs/softgen.html";
	    print "<a href=\"$www_gensoft\#$doc_aname\">$title_name</a> $title_text\n";
	} else {

	    print "$title_name$title_text\n";

	}
    }

    print "</h1>\n";

    if (-e $begin_file) {
        open (BEGIN, "< $begin_file") || die "Cannot open $begin_file: $!";
        while (<BEGIN>) {
	    print;
        }
        close (BEGIN);
    }

    $cgi_command = $command . ".pl" ;
    print "<BR></BR>\n";
    print "<FORM NAME=\"main\" ENCTYPE = \"multipart/form-data\"  METHOD=\"POST\" ACTION=\"$CGI_URL/$cgi_command\">\n";
    if ($user_level eq "simple") {
       print "<INPUT NAME=\"simple\" TYPE=\"HIDDEN\" VALUE=\"yes\"></INPUT>\n";
    }
    print "<INPUT NAME=\"Title\" TYPE=\"HIDDEN\" VALUE=\"$title\"></INPUT>\n";
    print "<INPUT NAME=\"Cmd\" TYPE=\"HIDDEN\" VALUE=\"$command\"></INPUT>\n";

    $command_label = ($defs->type($command) eq "String") ? "Run $command" : "Run" ;
    print "<INPUT TYPE=\"reset\" VALUE=\"Reset\"></INPUT>";
    print " <INPUT TYPE=\"submit\" VALUE=\"$command_label\"></INPUT>\n";

}

sub print_footer {
    my $defs = $_[0];
    my $user_level = $_[1];

    if ($defs->reference) {
	print "<A NAME=\"REFERENCE\">\nReferences</A>:\n";
	my @references = $defs->reference;
	foreach my $reference (@references) {
	    print "<BR></BR>$reference\n";
	}
    }
    $end_file = "end.html";
    $VERSION = $ENV{'VERSION'} ;

    if (-e $end_file) {
	open (END, "< $end_file") || die "Cannot open $begin_file: $!";
	while (<END>) {
	    print;
	}
	close (END);
    }
    $date = `date +"%d %b %Y %H:%M"` ;
    chop($date);
    print "\n<p></p>\n<i><A HREF=\"http://www.pasteur.fr/recherche/unites/sis/Pise/\">Pise</a> form generator version: $VERSION ($date)</i>\n";

    # to have help always at the top of the browser window
    if (defined %comments) {
	for $l (0 .. 50) {
	    print "<br></br>";
	}
    }
    print "\n</body>\n";
    print "\n";
    print "</html>\n";

}

sub print_one_param {
    my ($defs, $user_level, $param , $type, $paragraph ) = @_ ;
    undef $vdef;

    my $opt_email = 0;
    eval { 
	if ($defs->opt_email()) {
              $opt_email = 1;
        }
    };  

    $string = &clean_esc($defs->prompt($param));
#    print STDERR "print_one_param: $param ($user_level)\n";
    if (defined $defs->comment($param)) {
	($text_param = $param) =~ s/_/ /g ;
	if ( $string =~ /\b$text_param\b/i ) {
	    ($html_string = $string) =~	s|$text_param|<A HREF=\"\#$param\">$&</a>|i ;
	} else {
	    $html_string = "<A HREF=\"\#$param\">$string</a>";
	}
    }
    
    if (defined ${"${command}::piped"}{$param} ) {
#    print STDERR "DEBUG> make-html-utils.pl $param $type piped\n";
        if ($type eq "InFile" || $type eq "Sequence")  {
            my $piped_file = "$tmp_dir/" . ${"${command}::piped"}{$param};
            my $piped_file_name = `basename $piped_file` ;
            chop($piped_file_name);
	    $paramstring = $param . "_string";
            my $piped_url = "$tmp_url/" . ${"${command}::piped"}{$param};
            print "<INPUT NAME=\"$paramstring\" TYPE=\"HIDDEN\" VALUE=\"$piped_file\"></INPUT>\n";
            print "<p></p> $string: ";
	    print "your <A HREF=\"$piped_url\">$piped_file_name</a> file";
	    print "\n<p></p>\n";
        } elsif ($type eq "Mail") {
	     $prompt="your e-mail";
	     if ( defined $defs->comment($param)) {
		 $prompt= "your <A HREF=\"\#$param\">e-mail</a>";
	     } 
	     $vdef = ${"${command}::piped"}{$param};
             if ($opt_email) {
                 if ($vdef) {
		     print "<INPUT NAME=\"$param\" SIZE=\"40\" VALUE=\"$vdef\" >   $prompt (optional)</INPUT>";
		 } else {
		     print "<INPUT NAME=\"$param\" SIZE=\"40\"  >   $prompt (optional)</INPUT>";
		 }
             } else {
                 if ($vdef) {
		     print "<img src=\"$IMAGES_DIR/red-bullet.gif\"/> <INPUT NAME=\"$param\" VALUE=\"$vdef\" SIZE=\"40\" >   $prompt</INPUT>";
		 } else {
		     print "<img src=\"$IMAGES_DIR/red-bullet.gif\"/> <INPUT NAME=\"$param\" SIZE=\"40\" >   $prompt</INPUT>";
		 }
            }
        }
        print "\n<br></br>\n";
        return;
    }

    if ($user_level eq "simple" && $type ne "Mail") {
        if ( ! ($defs->issimple($param) )) {
#	print STDERR "level simple $param issimple=", $defs->issimple($param),, " vdef=",$defs->vdef($param),"\n";
	  if (defined $defs->vdef($param)) {
	    if ($type eq "List") {
		foreach $v (@{ $defs->vdef($param) }) {
		    print "<INPUT NAME=\"$param\" TYPE=\"HIDDEN\" VALUE=\"$v\"></INPUT>\n";
		}
	    } else {
		if ($type eq "Switch") {
		    if ($defs->vdef($param)) {
			$vdef = "on" ;
		    } else {
			$vdef ="";
		    }
		} else {
		    $vdef = $defs->vdef($param); 
		}
		print "<INPUT NAME=\"$param\" TYPE=\"HIDDEN\" VALUE=\"$vdef\"></INPUT>\n";
	    }
	  }
          return;
	}
    }

    $mandatory = '';

    if ($user_level eq "advanced") {
        if ( ($type eq "Excl" && (! (defined $defs->vdef($param))))  || (! ($type eq "Switch" || $type eq "Excl")) ) {
	    if ( $defs->ismandatory($param) ) {
	    if (defined $defs->precond($param,'perl')
		    && $defs->precond($param,'perl') ne '1' ) {
		    $mandatory = "<img src=\"$IMAGES_DIR/blue-bullet.gif\"/> ";
	        } else {
		    $mandatory = "<img src=\"$IMAGES_DIR/red-bullet.gif\"/> ";
	        }
	    }
        }
    }
    if (! ($type eq "Switch" || $type eq "Paragraph")) {
	if (defined $defs->vdef($param)) {
	    $vdef = "VALUE=\"" . $defs->vdef($param) . "\"";
	}
	else {
	    $vdef ="";
	}
    }
    elsif ($type eq "Switch")  {
	if (defined $defs->vdef($param) && $defs->vdef($param)) {
	    $vdef = "CHECKED";
	}
	else {
	    $vdef ="";
	}
    }
    elsif ($type eq "Paragraph")  {
	null;
    }
    else {
	die "Missing type???";
    }

    if ($type eq "Mail") { 
	$prompt="your e-mail";
	if ( defined $defs->comment($param) ) {
                $prompt= "your <A HREF=\"\#$param\">e-mail</a>";
        } 
        if (defined $defs->vdef($param)) {
                   $vdef = $defs->vdef($param);
        } else {
	           $vdef = "";
        }
        if ($opt_email) {
                  print "<INPUT NAME=\"$param\" SIZE=40 VALUE=\"$vdef\" >  $prompt (optional)</INPUT>";
	} else {
	    print "<img src=\"$IMAGES_DIR/red-bullet.gif\"/> <INPUT NAME=\"$param\" SIZE=40 VALUE=\"$vdef\" >   $prompt</INPUT>"; 
        }
    }
    elsif ($type eq "InFile" || $type eq "Sequence" ) {

	if ($type eq "Sequence" && defined $defs->vdef($param) && defined $defs->vdef($param) ne "") {

            if ($user_level eq "advanced") {
		$vdef = $defs->vdef($param);
	        if ( defined $defs->comment($param) ) {
	            print "<br></br>$mandatory $html_string";
		} else {
		    print "<br></br>$mandatory $string ";
		}
		print "<INPUT NAME=\"$param\" SIZE=50 TYPE=\"file\" VALUE=\"$vdef\"></INPUT>";
	    } 
            return;
        }
	$paramdata = $param . "_data";
        if (defined $defs->vdef($paramdata)) {
            $vdef = $defs->vdef($paramdata);
        } elsif (defined $defs->vdef($param)) {
            $vdef = $defs->vdef($param);
        } else {
	    $vdef = "";
	}
	if ($user_level eq "simple") {
	    if ( defined $defs->comment($param) ) {
		print "<br></br> $html_string";
	    } else {
		print "<br></br> $string ";
	    }
	    if ( $type eq "Sequence" && defined $defs->seqfmt($param) ) {
		$seqfmt=1;
		print " (<A HREF=\"\#fmtseq\">format</a>)<br></br>";
	    }
	    print "<TEXTAREA NAME = \"$paramdata\" ROWS = 10 COLS = 50>";
            my @l = split (/\\n/, $vdef);
            print join("\n",@l);
            print "</TEXTAREA><p></p>";
	} else {
	    if ( defined $defs->comment($param) ) {
	        print "<br></br>$mandatory $html_string";
	    } else {
		print "<br></br>$mandatory $string ";
	    }
	    print " : please enter <A HREF=\"#_data\">either</a> :
        <ol>
        <li> the name of a <STRONG>file</STRONG>:
	     <INPUT NAME=\"$param\" SIZE=50 TYPE=\"file\"></INPUT>
        <li> <EM>or</EM> the <STRONG>actual data</STRONG> here:
";
#	     <TEXTAREA NAME = \"$paramdata\" ROWS = 5 COLS = 50>$vdef</TEXTAREA>
#        </ol>
# ";
	    print "<TEXTAREA NAME = \"$paramdata\" ROWS = 5 COLS = 50>";
            my @l = split (/\\n/, $vdef);
            print join("\n",@l);
            print "</TEXTAREA></ol><p></p>";
	    if ( $type eq "Sequence" && defined $defs->seqfmt($param) ) {
	        $seqfmt=1;
		print "\n(sequence <A HREF=\"\#fmtseq\">format</a>)<br></br>";
	    }
            unless (defined $defs->comment('_data')) {
                my @comment = (
			       "if you are using Netscape 2.x or later, you can select a file by typing its name, or better, by selecting it with the Netscape file browser (<STRONG>Browse</STRONG> button)"  ,
			       "OR you can type your data in the next area, or cut and paste it from another application." ,
			       "(but not both)"
			       );
$defs->comment('_data', \@comment);
$defs->prompt('_data',"enter either the name of a file or the actual data");
                push ( @{ $comments{$paragraph} }, "_data");
            }
        }
    }
    elsif ($type eq "OutFile") {
	print $mandatory ;
	if ( defined  $defs->comment($param) ) {
	    $string = $html_string;
	}
	if ( $vdef =~ /\$/ ) {
	    print "<INPUT NAME=\"$param\">   $string</INPUT>\n";
	} else {
	    print "<INPUT NAME=\"$param\" $vdef>   $string</INPUT>\n";
	}
    }
    elsif ($type eq "Switch") {
	print $mandatory ;
	if ( defined  $defs->comment($param) ) {
	    print "<INPUT TYPE=\"checkbox\" NAME=\"$param\" $vdef>   $html_string</INPUT>\n";
	} else {
	    print "<INPUT TYPE=\"checkbox\" NAME=\"$param\" $vdef>   $string</INPUT>\n";
	}
    }
    elsif ($type eq "Excl") {
	print $mandatory ;
	@values = $defs->vlist($param) ;
	$vdef = $defs->vdef($param);
	$prompt_size = 0;
	$i=0;
	while ($i <= $#values) {
	    $prompt_size += length($values[$i+1]);
	    $i++;
	}
	if ( $#values > 6 || $prompt_size > 70) {
	    print "<SELECT NAME=\"$param\">\n";	
	    # an empty line in the choices if not mandatory
	    print "<OPTION>\n" if (! $defs->ismandatory($param));
	    $i=0;
	    while ($i <= $#values) {
		$value= $values[$i];
		$prompt=$values[$i+1];
		if ($value eq $vdef) {
		    print "<OPTION selected VALUE=\"$value\"> $prompt\n";
		} else {
		    print "<OPTION VALUE=\"$value\"> $prompt\n";
		}
		$i+=2;
	    }
	    if ( defined $defs->comment($param) ) {
		print "</SELECT>   $html_string\n";		
	    } else {
		print "</SELECT>   $string\n";		
	    }
	} else {
	    if ( defined $defs->comment($param)  ) {
		print "$html_string ?\n";
	    } else {
		print "$string ?\n";
	    }
	    if ( ! $defs->ismandatory($param) ) {
                if (defined $vdef) {
		    print "<INPUT TYPE=\"radio\" NAME=\"$param\" VALUE=\"$vdef\" > [default]</INPUT>\n ";
                } else {
		    print "<INPUT TYPE=\"radio\" NAME=\"$param\" VALUE=\"\" > [default]</INPUT>\n ";
		}
	    }
	    $i=0;
	    while ($i <= $#values) {
		$value= $values[$i];
		$prompt=$values[$i+1];
		print "<INPUT TYPE=\"radio\" NAME=\"$param\" VALUE=\"$value\" ";
		if (defined $vdef && ($value eq $vdef)) {
		    print " CHECKED ";
		}
		print "> $prompt</INPUT>\n";
		$i+=2;
	    }
	}
	print "\n";
    }
    elsif ($type eq "List") {
	@values = $defs->vlist($param) ;
	@vdef = @{ $defs->vdef($param) };
        # print STDERR "$0: $type $param (vdef=@vdef)\n";
	if ( defined $defs->comment($param) ) {
	    print "<br></br>$mandatory $html_string:";
	} else {
	    print "<br></br>$mandatory $string:";
	}
	print "<br></br><SELECT NAME=\"$param\" MULTIPLE>\n";		
	$i=0;
	while ($i <= $#values) {
	    $value= $values[$i];
	    $prompt=$values[$i+1];
            $value =~ s/\(/\\\(/g;
            $value =~ s/\)/\\\)/g;
	    if (grep (/^$value$/, @vdef) ) {
		print "<OPTION selected VALUE=\"$value\"> $prompt\n";
	    } else {
		print "<OPTION VALUE=\"$value\"> $prompt\n";
	    }
	    $i+=2;
	}
	print "</SELECT>\n";		
    }
    elsif ($type eq "Integer" || $type eq "Float") {
	if ( defined $defs->comment($param) ) {
	    print "$mandatory <INPUT NAME=\"$param\" $vdef>   $html_string</INPUT>\n";
	} else {
	    print "$mandatory <INPUT NAME=\"$param\" $vdef>   $string</INPUT>\n";
	}
    }
    elsif ($type eq "String") {
	if (defined $defs->size($param) ) {
	    $size="SIZE=" . $defs->size($param);
        } else {
	    if ( defined $defs->vdef($param) && $defs->vdef($param) ne "" && length($defs->vdef($param)) > 20) {
	        $size="SIZE=" . length($defs->vdef($param));
	    } else {
	        $size="";
	    }
        }
	if (defined $defs->comment($param) ) {
	    print "$mandatory <INPUT NAME=\"$param\" $size $vdef>   $html_string</INPUT>\n";
	} else {
	    print "$mandatory <INPUT NAME=\"$param\" $size $vdef>   $string</INPUT>\n";
	}
    }	
    elsif ($type eq "Label") {
	print "<BR></BR>$string\n";
    }	
    elsif ($type eq "Paragraph") {
	print "<A HREF=\"\#$param\">$string ";
	print "($vdef)" if ($vdef);
	print "</A>\n";
    }
    elsif ($type eq "Results") {
    }
    else {
	&panic ("AAAAAAAAAAA! Unknown type $type for parameter $param");
    }
    print "\n<br></br>\n";
}

1;
