
package Maker;


sub do_something {
    local ($title, 
	   $command, 
	   $seqinput,
	   $seqtype,
	   *parameter_type, 
	   *parameters_attributes, 
	   *parameters_order,
	   *top_parameters) = @_;
    
    $PISEDIR = $ENV{'PISEDIR'} ;
    $VERSION = $ENV{'VERSION'} ;
    $perloopise = "$PISEDIR/Maker/perloo.pm";
    
    print "

# perl description of \"$command\" parameters (Version $VERSION)

package $command;

sub new {
    my \$proto = shift;
    my \$class = ref(\$proto) || \$proto;
    my \$self  = {};
    \$self->{COMMAND}   = \"$command\";
    \$self->{VERSION}   = \"$VERSION\";
    \$self->{TITLE}   = \"$title\";
    \$self->{REFERENCE}   = \"$reference\";


";
    foreach $param (keys (%parameter_type)) {
	if ($parameter_type{$param} eq "Paragraph") {
	    %attributes = %{$parameters_attributes{$param}};
	    if ( defined $attributes{'group'}) {
		foreach $p ( @{$attributes{'vlist'}} ) {
		    unless ( defined $parameters_attributes{$p}{'group'} ) {
			$parameters_attributes{$p}{'group'} =  $attributes{'group'};
		    }
		}
	    }
	    if ( defined $attributes{'precond'}{'perl'}) {
		foreach $p ( @{$attributes{'vlist'}} ) {
		    unless (defined $parameters_attributes{$p}{'precond'} ) {
			$parameters_attributes{$p}{'precond'}{'perl'} =  $attributes{'precond'}{'perl'};
		    } else {
			$parameters_attributes{$p}{'precond'}{'perl'} =  $attributes{'precond'}{'perl'} 
			. " && " . $parameters_attributes{$p}{'precond'}{'perl'};
		    }
		}
	    }
	}
    }
    
    print "
    \$self->{_INTERFACE_STANDOUT} = undef;
    \$self->{_STANDOUT_FILE} = undef;
";

    print "
    \$self->{TOP_PARAMETERS}  = [\n";
    foreach $param (@top_parameters) {
	print "       \"$param\",\n";
    }

    print "    ];\n";

    print "
    \$self->{PARAMETERS_ORDER}  = [\n";
    foreach $param (@parameters_order) {
	print "       \"$param\",\n";
    }
    print "    ];\n";
    
    $seqinput = 0 unless ($seqinput); # no sequences input (seqlab)
    $seqtype = "0" unless ($seqtype); #
    $seqnb = 0;

    print "    
    \$self->{TYPE}  = {\n";
    foreach $param (keys (%parameter_type)) {
	print "\t\"$param\" => \'", $parameter_type{$param}, "\',\n";
        $seqnb++ if ($parameter_type{$param} eq "Sequence");
    }
    print "    };\n";

    if (! $seqinput) {
        if ($seqnb > 0) {
	    $seqinput = ($seqnb <= 3) ? $seqnb : 3;
	}
    }
    if ($seqtype eq "0") {
        if ($seqnb > 0) {
	    $seqtype = "B";
	}
    }

    print "
    \$self->{SEQINPUT}  = $seqinput; #1=only 1 seq,2=2 seqs,3=any nb (SeqLab)
    \$self->{SEQTYPE}  = \"$seqtype\"; # P(rot)/N(uc)/B(oth) (SeqLab)
";

    print "    
    \$self->{FORMAT}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'format'} ) {
            print "\t\"$param\" => {\n";             
            foreach $format ( keys %{ $attributes{'format'} } ) {
	         print "\t\t\"$format\" => \'", $attributes{'format'}{$format}, "\',\n";

            }
            print "\t},\n";
        }
    }
    print "    };\n";
 
   
    print "    
    \$self->{FILENAMES}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'filenames'} ) {
	     print "\t\"$param\" => \'", $attributes{'filenames'}, "\',\n";
        }
    }
    print "    };\n";
    
    print "    
    \$self->{SEQFMT}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'seqfmt'} ) {
	     print "\t\"$param\" => [", 
	     join ("," , 
	          map {"$_"}
	          @{ $attributes{'seqfmt'}} 
	          ), 
	      "],\n";
        }
    }
    print "    };\n";
    
    
    print "    
    \$self->{GROUP}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'group'} ) {
	     $group{$param} = $attributes{'group'};
	     print "\t\"$param\" => ", $attributes{'group'}, ",\n";
        } else {
             $group{$param} = &max_group_nr + 1;
        }
    }
    print "    };\n";
    
    print "    
    \$self->{BY_GROUP_PARAMETERS}  = [\n";
    foreach $param (sort by_group keys (%parameter_type)) {
	print "\t\"$param\",\n";
    }
    print "    ];\n";

    print "    
    \$self->{SIZE}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'size'}) {
	    print "\t\"$param\" => ", $attributes{'size'}, ",\n";
	}
    }
    print "    };\n";


    print "    
    \$self->{ISHIDDEN}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'hidden'}) {
	    print "\t\"$param\" => 1,\n";
	} else {
	    print "\t\"$param\" => 0,\n";
	}
    }
    print "    };\n";

    print "    
    \$self->{ISCOMMAND}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'command'}) {
	    print "\t\"$param\" => 1,\n";
	} else {
	    print "\t\"$param\" => 0,\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{ISMANDATORY}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'mandatory'}) {
	    print "\t\"$param\" => 1,\n";
	} else {
	    print "\t\"$param\" => 0,\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{PROMPT}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'prompt'} ) {
	    print "\t\"$param\" => ", " \"$attributes{'prompt'}\" ", ",\n";
        }
    }
    print "    };\n";
    
    print "    
    \$self->{ISSTANDOUT}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'standout'}) {
	    print "\t\"$param\" => 1,\n";
	} else {
	    print "\t\"$param\" => 0,\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{VLIST}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined @{ $attributes{'vlist'}} ) {
	    map {s/\'/\\\'/g} @{ $attributes{'vlist'}};
	    map {s/ +/ /g} @{ $attributes{'vlist'}};
	    print "\t\"$param\" => [", 
	    join ("," , 
		  map {"\'$_\'"}
		  @{ $attributes{'vlist'}} 
		  ), 
	    "],\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{FLIST}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'flist'} }) {
	    print "\t\"$param\" => {\n";
	    foreach $k (keys %{ $attributes{'flist'} }) {
		$v = $attributes{'flist'}{$k};
		print "                            \'$k\' => \'$v\',\n";
	    }
	    print "                       },\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{SEPARATOR}  = {\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "List") {
	%attributes = %{$parameters_attributes{$param}};
	print "\t\"$param\" => \'", $attributes{'separator'}, "\',\n";
      }
    }
    print "    };\n";
    
    print "    
    \$self->{VDEF}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'vdef'}) {
	    if ($parameter_type{$param} eq "List") {
	        print "\t\"$param\"	=> [";
	        foreach $v ( @{ $attributes{'vdef'}} ) {
		    print "\'$v\',";
	        }
	        print " ],\n";
	    } else {
	        print "       \"$param\" => \'", $attributes{'vdef'}, "\',\n";
	    }
        }
    }
    print "    };\n";


    print "    
    \$self->{PRECOND}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'precond'} ) {
            print "\t\"$param\" => {\n";             
            foreach $format ( keys %{ $attributes{'precond'} } ) {
	         print "\t\t\"$format\" => \'", $attributes{'precond'}{$format}, "\',\n";

            }
            print "\t},\n";
        } else {
	    print "\t\"$param\" => {
		\"perl\"  => \'1\',
	    },\n";
	}
    }
    print "    };\n";
 
    my @msgs;
    my @lgs;
    print "    
    \$self->{CTRL}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'ctrl'} }) {
	    print "\t\"$param\" => {\n";
            @msgs = keys %{ $attributes{'ctrl'} };
            @lgs = ();
	    foreach $msg (@msgs) {
                foreach $lg (keys %{ $attributes{'ctrl'}{$msg} } ) {
                    push (@lgs, $lg) if (!(grep { $lg eq $_ } @lgs));
                }
            }
            foreach $lg (@lgs) {
	        print "\t\t\'$lg\' => { \n";
                foreach $msg (@msgs) {
                    $test = $attributes{'ctrl'}{$msg}{$lg};
                    if ($test) {
	                print "\t\t\t\'$test\' => \"$msg\" ,\n";
#print STDERR "CTRL: param=$param, msg=$msg lg=$lg\n$lg\n";
#print STDERR "CTRL: test = $test\n";
                    }
                }
	        print "\t\t},\n";
	    }
	    print "\t},\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{PIPEOUT}  = {\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "OutFile" ||
          $parameter_type{$param} eq "Results"  ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'pipe'} }) {
	    print "\t\"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'pipe'} }) {
                foreach $lg (keys %{ $attributes{'pipe'}{$type} } ) {
                    if ( $lg = 'perl') {
                        $test = $attributes{'pipe'}{$type}{$lg};
		        print "              \'$test\' => \"$type\",\n";
                    }
                }
	    }
	    print "                       },\n";
	}
      }
    }
    print "    };\n";
    
     print "    
    \$self->{WITHPIPEOUT}  = {\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "OutFile" ||
          $parameter_type{$param} eq "Results" ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'withpipe'} }) {
	    print "\t\"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'withpipe'} }) {
		print "\t\t\"$type\" => [\n";
                foreach $paramname (@{ $attributes{'withpipe'}{$type} } ) {
		    print "\t\t\t\'$paramname\',\n";
                }
		print "             ]\n";
	    }
	    print "                       },\n";
	}
      }
    }
    print "    };\n";
   
    print "    
    \$self->{PIPEIN}  = {\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "InFile" ||
          $parameter_type{$param} eq "Sequence" ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'pipe'} }) {
	    print "\t\"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'pipe'} }) {
                foreach $lg (keys %{ $attributes{'pipe'}{$type} } ) {
                    if ( $lg = 'perl') {
                        $test = $attributes{'pipe'}{$type}{$lg};
		        print "\t\t\"$type\" => \'$test\',\n";
                    }
                }
	    }
	    print "                       },\n";
	}
      }
    }
    print "   };\n";

     print "    
    \$self->{WITHPIPEIN}  = {\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "InFile" ||
          $parameter_type{$param} eq "Sequence" ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'withpipe'} }) {
	    print "           \"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'withpipe'} }) {
		print "             \"$type\" => [\n";
                foreach $paramname (@{ $attributes{'withpipe'}{$type} } ) {
		    print "                   \'$paramname\',\n";
                }
		print "             ]\n";
	    }
	    print "                       },\n";
	}
      }
    }
    print "    };\n";
   
    print "    
    \$self->{ISCLEAN}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'clean'}) {
	    print "       \"$param\" => 1,\n";
	} else {
	    print "       \"$param\" => 0,\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{ISSIMPLE}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'simple'}) {
	    print "       \"$param\" => 1,\n";
	} else {
	    print "       \"$param\" => 0,\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{PARAMFILE}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'paramfile'}){
	    print "       \"$param\" => \'", $attributes{'paramfile'}, "\',\n";
        }
    }
    print "    };\n";
    
    
    print "    
    \$self->{COMMENT}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined @{ $attributes{'comment'}} ) {
	    map {s/\'/\\\'/g} @{ $attributes{'comment'}};
	    map {s/ +/ /g} @{ $attributes{'comment'}};
	    print "       \"$param\" => [", 
	    join ("," , 
		  map {"\'$_\'"}
		  @{ $attributes{'comment'}} 
		  ), 
	    "],\n";
	}
    }
    print "    };\n";
    
    print "    
    \$self->{SCALEMIN}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'scalemin'}){
	    print "       \"$param\" => \'", $attributes{'scalemin'}, "\',\n";
        }
    }
    print "    };\n";

    print "    
    \$self->{SCALEMAX}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'scalemax'}){
	    print "       \"$param\" => \'", $attributes{'scalemax'}, "\',\n";
        }
    }
    print "    };\n";
    
    print "    
    \$self->{SCALEINC}  = {\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'scaleinc'}){
	    print "       \"$param\" => \'", $attributes{'scaleinc'}, "\',\n";
        }
    }
    print "    };
";
    
    print "
    bless (\$self, \$class);
    return \$self;
}
";
    print "# -- begin inclusion of $perloopise\n";
    open(LIB,$perloopise) || die "cannot open $perloopise: $!";
    while (<LIB>) {
        print;
    }
    close LIB;
    print "# -- end inclusion of $perloopise\n";

    print "
1;
";

}

sub by_group {
    my %attributes_a = %{$parameters_attributes{$a}};
    my %attributes_b = %{$parameters_attributes{$b}};
    $attributes_a{'group'} <=> $attributes_b{'group'};
}

sub max_group_nr {
    return $group{$by_group_parameters[$#by_group_parameters]};
}

1;


