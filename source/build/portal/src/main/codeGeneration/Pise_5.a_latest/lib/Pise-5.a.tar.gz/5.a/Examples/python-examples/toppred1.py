from Pise import PiseFactory
import sys

email = 'letondal@pasteur.fr'

factory = PiseFactory()
program = factory.program("toppred",graph_output=1,profile_format="ps")
job = program.run(query=sys.argv[1])
if job.error():
    print job.error_message()
else:
    print "url of the job: " + job.jobid()
    print job.stdout()
    print job.get_results()
    job.save('.ps')

