#! /local/bin/perl -w

use Cwd;
use File::Basename;
use Getopt::Std;

## Inits
my $tmpdir = '/bioweb/htdocs/seqanal/tmp';

## Parse command line options
my %opts = ();
if (! getopts('ho:s:z:', \%opts)) {
    usage(); exit(1); }
if ($opts{'h'}) {
    usage(); exit(0); }

my $size = defined($opts{'s'}) ? $opts{'s'} : 0;
my $old = defined($opts{'o'}) ? $opts{'o'} : 0;
my $zip = defined($opts{'z'}) ? $opts{'z'} : 0;

my $bigsize = $size * 1024 * 1024 * 1024;
my $jobtime = $old * 24 * 60 * 60;
my $ziptime = $zip * 60 * 60;

## Search & Proceed all programs directories
my $pwd = getcwd; my $now = time;
chdir $tmpdir || die "$tmpdir: chdir failed";
opendir TMP, '.' || die "$tmpdir: opendir failed";
while (my $prgdir = readdir TMP) {
    
    ## Skip files & Specials
    next if (! -d $prgdir);
    next if ($prgdir =~ /^\./);
    next if ($prgdir eq 'REQUESTS');

    ## Proceed all jobs dirs
    chdir $prgdir || die "$prgdir: chdir failed";
    opendir PRG, '.' || die "$prgdir: opendir failed";
    while (my $jobdir = readdir PRG) {

	## Skip index files & Specials
	next if ($jobdir eq 'index.html');
	next if ($jobdir =~ /^\./);

	## Delete oldest jobs directories
	my @st = stat $jobdir;
	if ($old && $now - $st[9] - $jobtime > 0) {
	    system "rm -rf $jobdir";
	    if ($?) { die "$jobdir: cannot remove\n"; }
	    next; }

	## Delete biggest jobs files
	next if (! -d $jobdir);
	next if ($size == 0 && $zip == 0);
	chdir $jobdir || die "$jobdir: chdir failed";
	opendir JOB, '.' || die "$jobdir: opendir failed";
	while (my $file = readdir JOB) {
	    
	    ## Skip Specials
	    next if ($file =~ /^\./);
	    
	    my @st = stat $file;
	    next if ($#st == -1);

	    ## Delete biggest files
	    if ($size && $st[7] >= $bigsize) {
		unlink $file; next; }

	    ## Delete archives
	    if ($zip && $file =~ /\.(tar\.gz|zip)$/ &&
		$now - $st[9] - $ziptime > 0) {
		unlink $file; next; }
	    
	}
	closedir JOB || die "$jobdir: closedir failed";
	chdir '..' || die "..: chdir failed";

    }
    closedir PRG || die "$prgdir: closedir failed";
    chdir '..' || die "..: chdir failed";

}
closedir TMP || die "$tmpdir: closedir failed";
chdir $pwd || die "$pwd: chdir failed";


sub usage {
    my $prog = basename $0;
    print STDERR "usage: $0 [options]\n\n";
    print STDERR "options:\n";
    print STDERR "  -h       ... Print this message and exit.\n";
    print STDERR "  -o <val> ... Delete files older than <val> days.\n";
    print STDERR "  -s <val> ... Delete files bigger than <val> Go.\n";
    print STDERR "  -z <val> ... Delete archives older than <val> hours.\n"; }

