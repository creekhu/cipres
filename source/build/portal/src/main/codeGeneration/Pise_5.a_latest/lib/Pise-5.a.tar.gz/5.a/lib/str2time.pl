
sub str2time
{
    my($date) = shift;

    # Split date string
    my(@w) = split(' ', $date);

    # Remove useless weekday, if it exists
    if ($w[0] =~ /^\D/) { shift(@w); }

    if (!$w[0]) { return undef; }

    my($day, $mn, $yr, $hr, $min, $sec, $adate, $atime);
    my($offset) = 0;

    # Check which format
    if ($w[0] =~ /^\D/)   # Must be ctime (Feb  3 17:03:55 GMT 1994)
    {
        $mn    = shift(@w);
        $day   = shift(@w);
        $atime = shift(@w);
        shift(@w) if @w > 1;
        $yr    = shift(@w);
    }
    elsif ($w[0] =~ m#/#) 
    {   # Must be common logfile (03/Feb/1994:17:03:55 -0700)
        ($adate, $atime) = split(/:/, $w[0], 2);
        ($day, $mn, $yr) = split(/\//, $adate);
        shift(@w);
        if ( defined $w[0] and $w[0] =~ m#^([+-])(\d\d)(\d\d)$# )
        {
            $offset = (3600 * $2) + (60 * $3);
            if ($1 eq '+') { $offset *= -1; }
        }
    }
    elsif ($w[0] =~ /-/)  # Must be rfc850 (08-Feb-94 ...)
    {
        ($day, $mn, $yr) = split(/-/, $w[0]);
        shift(@w);
        $atime = $w[0];
    }
    else                  # Must be rfc822 (09 Feb 1994 ...)
    {
        $day   = shift(@w);
        $mn    = shift(@w);
        $yr    = shift(@w);
        $atime = shift(@w);
    }
    if ($atime)
    {
        ($hr, $min, $sec) = split(/:/, $atime);
    }
    else
    {
        $hr = $min = $sec = 0;
    }

    if (!$mn || ($yr !~ /\d+/))     { return undef; }
    if (($yr > 99) && ($yr < 1970)) { return undef; }
    # Epoch started in 1970

    if ($yr < 70)    { $yr += 100;  }
    if ($yr >= 1900) { $yr -= 1900; }
    if ($yr >= 138)  { return undef; }
    # Epoch counter maxes out in year 2038, assuming "time_t" is 32 bit

    # Translate month name to number
    my $mon = $MoY{$mn};
    return undef unless defined $mon;

    # Translate to seconds since Epoch
    return (Time::Local::timegm($sec, $min, $hr, $day, $mon, $yr) + $offset);
}

1;
