
## Sequence format checker

use strict;

use File::Basename;

## Sequence format
my %compat = ( 1 => 'IG', 2 => 'GENBANK', 3 => 'NBRF', 4 => 'EMBL',
	       5 => 'GCG', 8 => 'FASTA', 9 => 'ZUKER', 11 => 'PHYLIP',
	       12 => 'PHYLIP', 13 => 'RAW', 14 => 'PIR', 15 => 'MSF',
	       17 => 'NEXUS', 100 => 'CLUSTAL' );

## Get sequence format
sub convseq_format {
  my ($seqfile) = @_;

  my $infmt;

  ## Check with squizz
  $infmt = undef;
  open (FMT, "squizz $seqfile 2>&1 |");
  while (<FMT>) {
    next if (! /: (.+) format\.$/);
    $infmt = $1; last; }
  close (FMT);
  if ($? == 0 and defined $infmt and $infmt ne 'UNKNOWN') {
    return ('squizz', $infmt); }

  ## Check with readseq
  $infmt = undef;
  open (FMT, "readseq -v -p < $seqfile 2>&1 |");
  while (<FMT>) {
    next if (! /^Sequence.*format=\s+(\d+)\.\s+(\S+),/);
    $infmt = $2; last; }
  close (FMT);
  if ($? == 0 and defined $infmt and $infmt !~ /Plain/) {
    return ('readseq', $infmt); }

  ## Check with fmtseq
  $infmt = undef;
  open (FMT, "fmtseq -li $seqfile 2>&1 |");
  while (<FMT>) {
    next if (! /^The Sequences of .+ \((\S+)\)/);
    $infmt = $1; last; }
  close (FMT);
  ## Warning: unknown formats are identified as `Plain'
  if ($? == 0 and defined $infmt and $infmt !~ /Plain/) {
    return ('fmtseq', $infmt); }

  ## Check with clustalw
  $infmt = undef;
  open (FMT, "clustalw -convert -infile=$seqfile -outfile=/dev/null 2>&1 |");
  while (<FMT>) {
    next if (! /^Sequence format is (\S+)/);
    $infmt = $1; last; }
  close (FMT);
  if ($? == 0 and defined $infmt and $infmt !~ /unknown/) {
    return ('clustalw', $infmt); }

  return ('none', 'unknown'); }


## Convert sequence file
sub convseq_convert {
  my ($seqfile, @seqfmt) = @_;

  ## Check for valid file name
  if ($seqfile =~ m,/$,) { return; }

  ## Get input format and program
  my ($prg, $infmt) = convseq_format($seqfile);

  ## Set output formats
  foreach (@seqfmt) {
    next if (! /^\d+$/ or ! exists $compat{$_});
    $_ = $compat{$_}; }

  ## Log format detection
  open (LOG, '>> /bioweb/logs/seqfmt.log');
  print LOG "** $seqfile **\nIN: $prg ... $infmt\nOUT: @seqfmt\n";
  close (LOG);

  ## Log format in work directory
  my ($seq,$log,undef) = File::Basename::fileparse($seqfile, '');
  open (LOG, ">> $log/.seqfmt");
  print LOG "$seq: $infmt ($prg)\n";
  close (LOG);

  ## FIXME: To be removed later ... to enable conversion.
  return ($prg, $infmt);

  ## Do not convert unknown format
  if ($prg ne "squizz") { return ($prg, $infmt); }

  ## Check if already in expected format
  my $ok = grep(/^$infmt$/, @seqfmt);
  if ($ok != 0) { return ($prg, $infmt); }

  ## Convert sequence/alignment
  my $outfile = "$seqfile.squizz"; my $orifile = "$seqfile.orig";
  foreach (@seqfmt) {
    open (FMT, "squizz -c $_ $seqfile >$outfile 2>/dev/null |");
    close (FMT);
    if ($? or -z $outfile) { next; }
    last; }
  if (-z $outfile) {
    print STDERR "SQUIZZ: $seqfile formatting failed.\n";
    unlink ($outfile);
    return ($prg, $infmt); }

  ## Rename old and new files
  rename ($seqfile, $orifile);
  rename ($outfile, $seqfile);

  ## return results
  return ($prg, $infmt); }

1;
