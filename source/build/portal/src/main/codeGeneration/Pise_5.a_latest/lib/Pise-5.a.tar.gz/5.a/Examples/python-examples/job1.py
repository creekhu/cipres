# directly create a job from an url

from Pise import PiseJob
j=PiseJob(jobid="http://bioweb.pasteur.fr/seqanal/tmp/golden/A13636310301041/", verbose=1, submit=0)
print j.stdout()
