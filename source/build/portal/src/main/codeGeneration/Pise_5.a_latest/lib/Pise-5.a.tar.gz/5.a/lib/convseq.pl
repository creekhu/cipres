
use File::Basename;

%main::seqfmtsdesc = (
	    1, "IG",
	    2, "GenBank",
	    3, "NBRF",
	    4, "EMBL",
	    5, "GCG",
	    6, "DNAStrider",
	    7, "Fitch",
	    8, "fasta",
	    11, "Phylip sequential",
	    12, "Phylip interleaved",
	    13, "Plain",
	    14, "PIR",
	    15, "MSF",
	    16, "ASN",
	    17, "PAUP",
	    100, "CLUSTALW",
	    );


# desc of fmtseq
%main::seqfmtsdesc2 = (
	    1, "IG/Stanford",
	    2, "GenBank",
	    3, "NBRF",
	    4, "EMBL",
	    5, "GCG",
	    6, "not known by fmtseq",
	    7, "not known by fmtseq",
	    8, "FASTA",
	    11, "PHYLIP-seq",
	    12, "PHYLIP-int",
	    13, "Plain",
	    14, "PIR",
	    15, "MSF",
	    16, "ASN.1",
	    17, "not known by fmtseq",
	    100, "Clustalw",
	    );
%main::readseq2fmtseq = (
	    1, 14,
	    2, 5,
	    3, 12,
	    4, 3,
	    5, 16,
	    6, 0,
	    7, 0,
	    8, 9,
	    11, 20,
	    12, 19,
	    13, 2,
	    14, 6,
	    15, 17,
	    16, 7,
	    17, 0,
	    100, 21,
	    );

sub format_nb {
    my $name=$_[0];
    my $number;
    foreach $number (keys %seqfmtsdesc) {
	if ($name =~ /$seqfmtsdesc{$number}/i || 
	    $seqfmtsdesc{$number} =~ /$name/i 
	    ) {
	    return $number;
	} elsif ($name =~ /$seqfmtsdesc2{$number}/i || 
	    $seqfmtsdesc2{$number} =~ /$name/i) {
	    return $number;
	}
    }
    return 0;
}

%main::seqfmtssuff = (
	    1, "ig",
	    2, "gb",
	    3, "nbrf",
	    4, "embl",
	    5, "gcg",
	    6, "dnastrider",
	    7, "fitch",
	    8, "fasta",
	    11, "ph",
	    12, "ph",
	    13, "plain",
	    14, "pir",
	    15, "msf",
	    16, "asn",
	    17, "paup",
	    100, "aln",
	    );

%main::gcgcmd = (
		 1, "topir",
		 8, "tofasta",
		 14, "topir"
		 );

$main::converter_to_run = "readseq";

sub which_seqfmt {
    my $seqfile=$_[0];
    my $format;
    my $format_name;
    my $date=localtime;

#    print STDERR "DEBUG> readseq $seqfile\n";
     open (READSEQ, "readseq -v -p -a < $seqfile 2>&1 |") 
	|| die "cannot open:$!";
#    open (READSEQ, "readseq -v -a $seqfile 2>&1 |") 
#	|| die "cannot open:$!";
    while (<READSEQ>) {
	chop;
	if (/format=\s+(\d+)\.\s+(\S+).*,/) {
	    close READSEQ;
	    $format=$1;
	    if ($format != 13) {
		print STDERR "[$date] sequence is in $1 ($2) format (match=$&) ($seqfile)\n";
		return $format;
	    } else {
		# found raw -- let's try fmtseq ?
		if ((! defined $have_fmtseq) || (defined $have_fmtseq && $have_fmtseq)) {
		    open (FMTSEQ, "fmtseq -li $seqfile 2>&1 |") 
			|| die "cannot open:$!";
		    while (<FMTSEQ>) {
			chop;
			if (/The Sequences.+\((\w+)\)/) {
			    close FMTSEQ;
			    $format_name=$1;
			    $format=format_nb($format_name);
			    print STDERR "[$date] sequence is in $format_name ($format) format (match=$&)\n";
			    $main::converter_to_run = "fmtseq";
			    return $format;
			}
		    }
		    close FMTSEQ;
		    # a "raw" format according to readseq, but not recognized
		    # by fmtseq 
		    $main::converter_to_run = "readseq";
		    return 13;
		}
	    }
	}
    }
    close READSEQ;

    # Removed by C. Letondal 30/11/2004 (clustalw loops forever when 
    #  provided a incorrect format)
    #
    # not found -- let's try clustalw ?
    #print STDERR "[$date] format unknown to readseq, let's try clustalw ($seqfile)\n";
    #my $tmpfile = POSIX::tmpnam;
    #open (CLUSTALW, "clustalw -infile=$seqfile -outfile=$tmpfile -convert |grep 'Sequence format is Clustal' |");
    #my $clustalw=0;
    #while (<CLUSTALW>) { 
	#$clustalw=1; 
	#last; 
    #};
    #close CLUSTALW;
    #stat ($tmpfile);
    #if ( -e _ ) {
	#unlink $tmpfile;
    #}
    #if ($clustalw) {
	#print STDERR "[$date] format is clustalw ($seqfile)\n";
	#$main::converter_to_run = "clustalw";
	#return 100; # code for clustalw !!
    #} 

    if ((! defined $have_fmtseq) || (defined $have_fmtseq && $have_fmtseq)) {
	print STDERR "[$date] let's try fmtseq ($seqfile)\n";
	open (FMTSEQ, "fmtseq -li $seqfile 2>&1 |") || die "cannot open:$!";
	while (<FMTSEQ>) {
	    #print STDERR "debug> fmtseq:\n\t$_";
	    chop;
	    if (/The Sequences.+\((.+)\)/) {
		close FMTSEQ;
		$format_name=$1;
		$format=format_nb($format_name);
		print STDERR "[$date] sequence is in $format_name ($format) format (match=$&)\n";
		if ($format == 100) {
		    print STDERR "[$date] Warning: $format_name has not been recognized by clustalw\n";
		}
		$main::converter_to_run = "fmtseq";
		return $format;
	    }
	}
	close FMTSEQ;
	print STDERR "[$date] format is unknown for fmtseq ($seqfile)\n";
    }

    return 0;

}

sub try_1lineseq {
    # should fixed by fmtseq

    # detect 1 line seq (pb with readseq)
    my $seqfile=$_[0];
    my @_seq;
    my $date=localtime;

    print STDERR "[$date] trying to fix 1 line sequence ($seqfile)\n";

    open(SEQ,$seqfile);
    my $l=0;
    while (<SEQ>) {
	push (@_seq,$_);
	chop;
	$l++ if (! /^\s*$/);
    }
    close SEQ;
    if ($l == 1) {
	open(NEWSEQ,"> $seqfile.8");
	my $base = basename $seqfile;
	chop($base);
	print NEWSEQ "> $base.8\n";
	print NEWSEQ "$seq[0]\n";
	close NEWSEQ;
	return "$seqfile.8";
    } else {
	return 0;
    }
}

sub converror {
    print STDERR "$_[0]\n";
    return -1;
}

sub convseqfmt {
    my $from=$_[0];
    my $to=$_[1];
    my $tofmt=$_[2];
#    my $clustalw=$_[3]; # from file is in clustalw format
    my $fromfmt=$_[3];
    my @toseq;
    my $tofmtname;
    my $tmpfile;
    my $date=localtime;

    if ($fromfmt == 100) { 
	# print STDERR "convseqfmt> original format is clustalw ($from)\n";
	if ($tofmt == 12) {
	    $tofmtname="PHYLIP";
	} elsif ($tofmt == 15) {
	    $tofmtname="GCG";
	} elsif ($tofmt == 14) {
	    $tofmtname="PIR";
	} elsif ($tofmt == 100) {
	    $tofmtname="CLUSTALW";
	} else {
	    # unknown target format for direct clustalw format conversion
	    $tmpfile = POSIX::tmpnam;
	    print STDERR "[$date] converting (1) $from to GCG format by clustalw\n";
	    system("clustalw -infile=$from -outfile=$tmpfile -convert -output=GCG > /dev/null");
	    stat($tmpfile);
	    if (-e _) {
		print STDERR "[$date] converting (2) $tmpfile to $tofmt format by readseq\n";
		system("readseq -a -p -f$tofmt < $tmpfile > $to 2> /dev/null");
		unlink $tmpfile;
		return 1;
	    } else {
		return 0;
	    }
	}

	print STDERR "[$date] converting $from to $tofmtname format by clustalw\n";
	system("clustalw -infile=$from -outfile=$to -convert -output=$tofmtname > /dev/null");
	stat($to);
	if ((! (-e _)) || -z _ ) {
	    if ((! defined $have_fmtseq) || (defined $have_fmtseq && $have_fmtseq)) {
		my $fmtseq_fmt = $readseq2fmtseq{$tofmt};
		print STDERR "[$date] clustalw failed: converting $from to $tofmtname format($fmtseq_fmt) by fmtseq\n";
		open(FROM, "fmtseq  -all -p -f$fmtseq_fmt < $from 2> /dev/null |") 
		    || &converror ("cannot open fmtseq on $from:$!");
		open (TO, "> $to") || &converror("cannot open $to:$!");
		while (<FROM>) {
		    print TO;
		}
		close FROM;
		close TO;
		return 1;
	    } else {
		return 0;
	    }
	}
	return 1;

    } elsif ($tofmt == 100) {
	if ($fromfmt == 8 || $fromfmt == 15) {
	    print STDERR "[$date] converting $from to clustalw format by clustalw\n";
	    system("clustalw -infile=$from -outfile=$to -convert > /dev/null");
	    stat($to);
	    if ((! (-e _)) || -z _ ) {
		if ((! defined $have_fmtseq) || (defined $have_fmtseq && $have_fmtseq)) {
		    print STDERR "[$date] clustalw failed: converting $from to clustalw format(21) by fmtseq\n";
		    open(FROM, "fmtseq  -all -p -f21 < $from 2> /dev/null |") 
			|| &converror ("cannot open fmtseq on $from:$!");
		    open (TO, "> $to") || &converror("cannot open $to:$!");
		    while (<FROM>) {
			print TO;
		    }
		    close FROM;
		    close TO;
		    return 1;
		} else {
		    return 0;
		}
	    }
	    return 1;
	} elsif ($fromfmt == 13) {
	    print STDERR "[$date] converting a Plain format ($fromfmt) into a Clustalw ($tofmt) format is not possible : copying $from into $to\n";
	    system("cp $from $to");
	    return 0;
	} else {
	    $tmpfile = POSIX::tmpnam;
	    print STDERR "[$date] converting (1) $from to GCG (15) format by readseq\n";
	    system("readseq -a  -p -f15 < $from > $tmpfile 2> /dev/null");
	    stat($from);
	    print STDERR "[$date] converting (2) $tmpfile to clustalw format by clustalw\n";
	    system("clustalw -infile=$tmpfile -outfile=$to -convert > /dev/null");
	    stat($to);
	    if ((! (-e _)) || -z _ ) {
		if ((! defined $have_fmtseq) || (defined $have_fmtseq && $have_fmtseq)) {
		    stat($tmpfile);
		    if ((! (-e _)) || -z _ ) {
			$tmpfile = $from;
		    }
		    print STDERR "[$date] clustalw failed: converting (3) $tmpfile to clustalw format(21) by fmtseq\n";
		    open(FROM, "fmtseq  -all -p -f21 < $tmpfile 2> /dev/null |") 
			|| &converror ("cannot open fmtseq on $from:$!");
		    open (TO, "> $to") || &converror("cannot open $to:$!");
		    while (<FROM>) {
			print TO;
		    }
		    close FROM;
		    close TO;
		    if ($tmpfile ne $from) {
			unlink $tmpfile;
		    }
		    return 1;
		} else {
		    stat($tmpfile);
		    if ((! (-e _)) || -z _ ) {
			unlink $tmpfile;
		    }
		    return 0;
		}
		unlink $tmpfile;
		return 1;
	    }
	}

    } else {
	if ($fromfmt == 13) {
	    my $fmtseq_tofmt = $readseq2fmtseq{$tofmt};
	    print STDERR "[$date] converting $from to $fmtseq_tofmt format by fmtseq\n";
	    open(FROM, "fmtseq  -all -p -f$fmtseq_tofmt < $from 2> /dev/null |") 
		|| &converror ("cannot open fmtseq on $from:$!");
	    open (TO, "> $to") || &converror("cannot open $to:$!");
	    while (<FROM>) {
		print TO;
	    }
	    close FROM;
	    close TO;
	    stat($to);
	    if ((! (-e _)) || -z _ ) {
		print STDERR "[$date] fmtseq failed!! ... converting $from to $tofmt format by readseq\n";
		open(FROM, "readseq -a  -p -f$tofmt < $from 2> /dev/null |") 
		    || &converror ("cannot open readseq on $from:$!");
		open (TO, "> $to") || &converror("cannot open $to:$!");
		while (<FROM>) {
		    print TO;
		}
		close FROM;
		close TO;
	    }
	    return 1;
		
	    return 1;
	} else {
	    if ($main::converter_to_run eq "readseq") {
		print STDERR "[$date] converting $from to $tofmt format by readseq\n";
		open(FROM, "readseq -a  -p -f$tofmt < $from 2> /dev/null |") 
		    || &converror ("cannot open readseq on $from:$!");
		open (TO, "> $to") || &converror("cannot open $to:$!");
		while (<FROM>) {
		    print TO;
		}
		close FROM;
		close TO;
		return 1;
	    } else {
		my $fmtseq_tofmt = $readseq2fmtseq{$tofmt};
		print STDERR "[$date] converting $from to $fmtseq_tofmt format by fmtseq\n";
		open(FROM, "fmtseq  -all -p -f$fmtseq_tofmt < $from 2> /dev/null |") 
		    || &converror ("cannot open fmtseq on $from:$!");
		open (TO, "> $to") || &converror("cannot open $to:$!");
		while (<FROM>) {
		    print TO;
		}
		close FROM;
		close TO;
	    }

	}
    }
}

