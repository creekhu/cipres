#!/usr/local/bin/perl

use strict;
use IPC::Shareable;
#$IPC::Shareable::Debug = 1;

my $checksum=$ARGV[0];
%::glue = (
	  'status' => 'aaaa',
	  'pid' => 'gggg',
	  'date' => 'rrrr',
	  'url' => 'zzzz',
	  'unix' => '5555',
	  );

sub unlock_ident {

    tie(%::status,"IPC::Shareable", $::glue{'status'},
	{ 'create' => 'No' }) || print "status doesnt exist\n";
    print "status = $::status{$checksum}\n";
    tie(%::status,"IPC::Shareable", $::glue{'status'}, { 'destroy' => 'Yes' });
    unless (defined $::status{"$checksum"}) {
	print STDERR "Done status.\n";
    }

    tie(%::pid,"IPC::Shareable", $::glue{'pid'},
	{ 'create' => 'No' }) || print "pid doesnt exist\n";
    print "pid = $::pid{$checksum}\n";
    tie(%::pid,"IPC::Shareable", $::glue{'pid'},
	{ 'destroy' => 'Yes' }) ; 
    unless (defined $::pid{"$checksum"}) {
	print STDERR "Done pid.\n";
    }

    tie(%::date,"IPC::Shareable", $::glue{'date'},
	{ 'create' => 'No' })  || print "date doesnt exist\n" ;
    print "date = $::date{$checksum}\n";
    tie(%::date,"IPC::Shareable", $::glue{'date'},
	{ 'destroy' => 'Yes' } ); 
    unless (defined $::date{"$checksum"}) {
	print STDERR "Done date.\n";
    }

    tie(%::url,"IPC::Shareable", $::glue{'url'},
	{ 'create' => 'No' })    || print "url doesnt exist\n" ;
    print "url = $::url{$checksum}\n";
    tie(%::url,"IPC::Shareable", $::glue{'url'},
	{ 'destroy' => 'Yes' }) ; 
    unless (defined $::url{"$checksum"}) {
	print STDERR "Done url.\n";
    }

    tie(%::unix,"IPC::Shareable", $::glue{'unix'},
	{ 'create' => 'No' })    || print "unix doesnt exist\n" ; 
    print "unix = $::unix{$checksum}\n";
    tie(%::unix,"IPC::Shareable", $::glue{'unix'},
	{ 'destroy' => 'Yes' }) ; 
    unless (defined $::unix{"$checksum"}) {
	print STDERR "Done unix.\n";
    }

}

&unlock_ident;

