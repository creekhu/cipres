#
# Generate the biok code for a command's parameters
#

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";

package Maker;

$command=$ARGV[0];

$VERSION=$ENV{'VERSION'};
$PISEDIR=($ENV{'PISEDIR'})? $ENV{'PISEDIR'} : "/local/gensoft/lib/Pise";
$PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : "/local/gensoft/lib/Pise/5.a/PerlDef";

if (defined $ARGV[1]) {
    if ($ARGV[1] eq "simple") {
	$level = "simple";
	print STDERR "make-biok.pl level: $level\n";
    } else {
	$required=$ARGV[1];
	require "$required";
    }
}
eval ("use $command;");
$defs = $command->new;

#TODO: PiseParam, parameters_list declarations

print "[self] proc initparams args {\n";
print "    [self] instvar parameters_list\n";
print "    set parameters_list {}\n";
print "}\n";

print "[self] proc drawform args {\n";
print "    [self] instvar parameters_list\n";
print "    [self] instvar tnbform\n";
print "    [self] instvar pise\n";
print "    [self] instvar tnbform\n";
print "    [self] instvar display\n"; 
print "    if {\$display} {\n";
print "        if [info exists pise] {\n";
print "            set tnbform [builder new TabNotebook -name $command -title $command -into \$pise]\n";
print "        } else {\n";
print "            set tnbform [builder new TabNotebook -name $command -title $command]\n";
print "        }\n";
print "    }\n";
print "    [self] instvar top\n";
print "    if {\$display} {\n";
print "        set top [\$tnbform addpage top]\n";
print "    }\n";
print "    [self] do_parameters\n";
print "    if {\$display} {\n";
print "        \$tnbform openpage top\n";
print "    }\n";
print "}\n";

print "[self] proc do_parameters args {\n";
print "    [self] instvar display"; 
print "    [self] instvar top"; 
print "    [self] instvar tnbform\n";
print "    [self] instvar parameters_list\n";
&do_parameters ($defs, 'top', $defs->top_parameters);
print "}\n";


sub do_parameters {
    my ($defs, $paragraph, @parameters_list) = @_ ;
    my $param;
    foreach $param (@parameters_list) {
	next if ($defs->ishidden($param));
	if ( $level eq "simple" && (! ($defs->issimple($param) ))) {
	    next;
	}
	if ($defs->type($param) eq "Paragraph") {

	    print_one_param($defs,
			    $param,
			    $defs->type($param),
	                    $paragraph);
	    $string = $defs->prompt($param);

	    foreach $p ( $defs->vlist($param) ) {
		push @{ $parameters_todo{$param} }, $p;
	    }
	    &do_parameters($defs,
			   $param, 
			   @{$parameters_todo{$param}});

       } else {
	    print_one_param($defs,
			    $param,
			    $defs->type($param),
	                    $paragraph);
       }

    }

}

sub print_one_param {
    my ($defs, $param , $type, $paragraph) = @_ ;

    undef $vdef;
    $string = wrap_string (esc_tcl ( clean_esc($defs->prompt($param)) ));
    $vdef = $defs->vdef($param);
    $string =~ s/\n/ /g;
    print "
    set param [names autoname piseparam]
    PiseParam \$param -name $param -type $type 
    lappend parameters_list \$param
";

    if ($type eq "Paragraph") {
	print "    if {\$display} {\n";
	print "        set $param [\$tnbform addpage $param]\n";
	print "    }\n";
	# paragraph title?
	print "    \$param set ishidden 0\n";
	return; 
    } 

    if ( $defs->ismandatory($param) ) {
	print "    \$param set mandatory 1\n";
    } else {
	print "    \$param set mandatory 0\n";
    }

    if ($defs->ishidden($param) || $type eq "Results" ) {
	print "    \$param set ishidden 1\n";
	if ($vdef) {
	    print "    \$param set vdef $vdef\n";
	} else {
	    print "    \$param set vdef \"\"\n";
	}
	return
    }
    print "    \$param set ishidden 0\n";

    if ($type eq "InFile" || $type eq "Sequence" ) {
	# TODO: there is a Sequence class!
	print "    if {\$display} {\n";
	print "         \$param set object [builder new Text -name $param -into \$$paragraph -prompt \"$string\"]\n";
	print "         set paramobject [\$param set object]\n";
	print "         \$param set data [\$paramobject set data]\n";
	print "    } else {\n";
	print "         set textdata [names autoname textdata]\n";
	print "         TextData \$textdata;\n";
	print "         \$param set data \$textdata\n";
	print "    }\n";
	@pipeins = $defs->pipein($param);
	if ($#pipeins gt 0) {
	    print "    \$param set pipeins [list ", $pipeins[0] , "]\n";
	}
    } elsif ($type eq "OutFile" || $type eq "String" || $type eq "Integer" || $type eq "Float") {
	print "    if {\$display} {\n";
	print "        \$param set object [builder new Field -name $param -into \$$paragraph -prompt \"$string\"]\n";
	print "        set paramobject [\$param set object]\n";
	print "        \$param set data [\$paramobject set data]\n";
	print "    } else {\n";
	print "         set fielddata [names autoname fielddata];\n";
	print "         FieldData \$fielddata;\n";
	print "         \$param set data \$fielddata;\n";
	print "    }\n";
	if ($vdef) {
	    print "    [\$param set data] setvalue $vdef\n";
	} 
    } elsif ($type eq "Switch") {
	print "    if {\$display} {\n";
	print "        \$param set object [builder new Switch -name $param -into \$$paragraph -prompt \"$string\"]\n";
	print "        set paramobject [\$param set object]\n";
	print "        \$param set data [\$paramobject set data]\n";
	print "    } else {\n";
	print "         set switchdata [names autoname switchdata]\n";
	print "         SwitchData \$switchdata\n";
	print "         \$param set data \$switchdata\n";
	print "    }\n";
	if ($vdef) {
	    print "     [\$param set data] switchon\n";
	} 
    } elsif ($type eq "Excl") {
	@vlist = $defs->vlist($param) ;
	$n = 0;
	undef @values;
	undef @prompts;
	while ($n <= $#vlist) {
	    $value = "{" . $vlist[$n] . "}";
	    push (@values, $value);
	    $prompt = "{" . $vlist[$n+1] . "}";
	    $prompt =~ s/\n/ /g;
	    push (@prompts, $prompt);
	    $n+=2;
	}
	$values = "{" . join (" ", @values) . "}";
	$prompts = "{" . join (" ", @prompts) . "}";
	if ($vdef && $vdef ne "" && $vdef ne "\"\"") {
	    ($printed_vdef = $vdef) =~ s/\-/\\-/g;
	    print "    if {\$display} {\n";
	    print "        \$param set object [builder new ChoiceList -name $param -into \$$paragraph -prompt \"$string\" -prompts $prompts -values $values -selected {$printed_vdef}]\n";
	    print "    } else {\n";
	    print "         set choicedata [names autoname choicedata]\n";
	    print "         ChoiceListData \$choicedata -prompts $prompts -values $values\n";
            print "         \$choicedata set selected $vdef\n";
	    print "         \$param set data \$choicedata\n";
	    print "    }\n";
	} else {
	    print "    if {\$display} {\n";
	    print "        \$param set object [builder new ChoiceList -name $param -into \$$paragraph -prompt \"$string\" -prompts $prompts -values $values]\n";
	    print "    } else {\n";
	    print "         set choicedata [names autoname choicedata]\n";
	    print "         ChoiceListData \$choicedata -prompts $prompts -values $values\n";
	    print "         \$param set data \$choicedata\n";
	    print "    }\n";
	}
	print "    if {\$display} {\n";
	print "        set paramobject [\$param set object]\n";
	print "        \$param set data [\$paramobject set data]\n";
	print "    }\n";
    } else {
	# not found... (TODO: List)
	print "    if {\$display} {\n";
	print "        \$param set object [builder new Field -name $param -into \$$paragraph -prompt \"$string\"]\n";
	print "        set paramobject [\$param set object]\n";
	print "        \$param set data [\$paramobject set data]\n";
	print "    }\n";
    }

    if ($vdef) {
	print "    \$param set vdef $vdef\n";
    } else {
	print "    \$param set vdef \"\"\n";
    }

    # if display?
    print "    if {\$display} {\n";
    print "        \$paramobject setalias $param\n";
    print "    }\n";

} 

sub clean_esc {
    my $s = $_[0];
    $s =~ s/\\//g ;
    return $s;
}
sub esc_tcl {
    my $s = $_[0];
    $s =~ s/\[/\\[/g ;
    $s =~ s/\]/\\]/g ;
    return $s;
}

sub wrap_string {
    my $string = $_[0];
    my $l = length($string);
    my $i = 0;
    my $label = "";
    my @words=split(/\s/,$string);
    my $word;
    my @substrs;

    my $substr = "";
    foreach $word (@words) {
	if (length($substr) < 40) {
	    $substr .= "$word ";
	} else {
	    push (@substrs, $substr);
	    $substr = "$word ";
	}
    }
    push (@substrs, $substr);
    $label = join ("\n", @substrs);
    return $label;
}

1;


