#!/local/bin/perl

require "str2time.pl";

$date_id=shift @ARGV;
if ($date_id =~ /^\s*$/) {
    $date_id = `date +"%Y%m"`;
    chomp($date_id);
    print STDERR "Please rather provide a date identifier -- defaulted to $date_id\n";
}
$results="log-$date_id.results.html";
$users_results="log-$date_id.users.html";
$min_date_num=999999999999999999999999999;
$max_date_num=0;

read_data();
init_html();
do_programs();
do_users();
end_html();

sub read_data {
    while (<>) {
	($program,$level,$command,$user,$tmpdir,$date) = split (/\|\|/,$_);
	$user =~ tr/A-Z/a-z/ ; 
	$user =~ s/\\// ; 
	if ($user =~ /^$/) {
	    print STDERR "no user??\n($_)\n\n";
	    next;
	}
	$user .= '@pasteur.fr' unless ($user =~ /\@/);
	$date_num=str2time($date);
	#print STDERR "$date ($date_num)\n";
	if ($date_num) {
	    if ($date_num < $min_date_num) {
		$min_date_num = $date_num;
		$min_date = $date;
		#print STDERR " min date = $min_date\n";
	    }
	    if ($date_num > $max_date_num) {
		$max_date_num = $date_num;
		$max_date = $date;
		#print STDERR " max date = $max_date\n";
	    }
	    $level{$program}{$user}{$date_num}=$level;
	    $command{$program}{$user}{$date_num}=$command;
	    $date{$program}{$user}{$date_num}=$date;
	} else {
	    print STDERR "warning: no date ($_)\n";
	}
    }
    $total_days = sprintf ("%d",(($max_date_num - $min_date_num) / 3600) / 24 );
}

sub init_html {
    open (RESULT, "> $results") || die "cannot open $results: $!";
    print RESULT "
<HTML>
<HEAD>
<TITLE>Web interfaces logs</TITLE>
</HEAD>
<BODY>
<P>
<H1>Web interfaces logs</H1> <h4>from \n\t$min_date\n<br>to\n\t$max_date</h4>
<P>
";

    print RESULT "<hr>\n";
    print RESULT "<h1><a href=\"\#programs\">Programs</a></h1>";
    print RESULT "<ul>\n";
    print RESULT "<li><a href=\"\#pg_byname\">Sorted by program name</a>\n"; 
    print RESULT "<li><a href=\"\#pg_jobs\">Sorted by number of jobs</a>\n";
    print RESULT "<li><a href=\"\#pg_users\">Sorted by number of users</a>\n";
    print RESULT "</ul>\n";  

    print RESULT "<hr>\n"; 
    print RESULT "<h1><a href=\"$users_results\">Users</a></h1>";
    print RESULT "<ul>\n";
    print RESULT "<li><a href=\"$users_results#local\">List of local users</a>\n";
    print RESULT "<li><a href=\"$users_results#external\">List of external users</a>\n";
    print RESULT "<li><a href=\"$users_results#domains\">Total by top domains</a>\n"; 
    print RESULT "<li><a href=\"$users_results#byjobs\">List of users by number of jobs</a>\n";
    print RESULT "<li><a href=\"$users_results#bypgs\">List of users by programs</a>\n";
    print RESULT "</ul>\n";  
    print RESULT "<hr>\n"; 
}

sub end_html {

    print RESULT "

</BODY>
</HTML>
";
    close RESULT;
}

sub do_programs {
    stat_by_pgs();

    print RESULT "
<a name=programs><H1>Programs</H1>

<h4>$total_pgs programs used, $total_jobs jobs, $daily jobs / day </h4>\n";

    do_pgs_by_name();
    do_pgs_by_jobs();
    do_pgs_by_users();


}

sub stat_by_pgs {

    $total_jobs=0;
    $total_pgs = 0;
    undef %total_jobs_pg;

    foreach $program (sort (keys %command)) {
	$total_pgs++;
	$total_users{$program}=0;
	$total_jobs_pg{$program}=0;
	foreach $user (sort (keys %{ $command{$program}} )) {
	    $total_users{$program}++;
	    foreach $date_num (sort (keys %{ $command{$program}{$user}} )) {
		$total_jobs++;
		$total_jobs_pg{$program}++;
		$niveau{$user}{$program}{$date_num} = $level{$program}{$user}{$date_num};
	    }
	}
    }

    if ($total_days > 0) {
	$daily=sprintf("%.2f",$total_jobs/$total_days);
    }

}

sub do_pgs_by_name {

    print RESULT "
<a name=pg_byname><TABLE border=1 width=100%>
";
    foreach $program (sort (keys %command)) {
	print RESULT "\n<TR><TD>$program\n";
	print RESULT "<TD>$total_users{$program} user(s) <TD>$total_jobs_pg{$program} job(s)</TR>\n";
    }

    print RESULT "
</TABLE>
";
}

sub do_pgs_by_jobs {

    print RESULT "<a name=pg_jobs><h2>Programs used sorted by number of jobs</h2>\n";

    print RESULT "
<TABLE border=1 width=100%>
";
    foreach $program (sort {$total_jobs_pg{$b} <=> $total_jobs_pg{$a}} (keys %total_jobs_pg)) {
	print RESULT "\n<TR><TD>$program\n";
	print RESULT "<TD>$total_users{$program} user(s) <TD>$total_jobs_pg{$program} job(s)</TR>\n";
    }

    print RESULT "
</TABLE>
";
}

sub do_pgs_by_users {

    print RESULT "<a name=pg_users><h2>Programs used sorted by number of users</h2>\n";

    print RESULT "
<TABLE border=1 width=100%>
";
    foreach $program (sort {$total_users{$b} <=> $total_users{$a}} (keys %total_users)) {
	print RESULT "\n<TR><TD>$program\n";
	print RESULT "<TD>$total_users{$program} user(s) <TD>$total_jobs_pg{$program} job(s)</TR>\n";
    }

    print RESULT "
</TABLE>
";
}

sub do_users {

    stat_by_users();

open (BYUSERS, "> $users_results") || die "cannot open $users_results: $!";

print BYUSERS "
<HTML>
<HEAD>
<TITLE>Users</TITLE>
</HEAD>
<BODY>

<P>
";

    print BYUSERS "
<hr>
<a name=users><H1>Users</H1>
";
    print BYUSERS "<hr>\n"; 
    print BYUSERS "<ul>\n";
    print BYUSERS "<li><a href=\"#local\">List of local users</a>\n";
    print BYUSERS "<li><a href=\"#external\">List of external users</a>\n";
    print BYUSERS "<li><a href=\"#domains\">Total by top domains</a>\n"; 
    print BYUSERS "<li><a href=\"#byjobs\">List of users by number of jobs</a>\n";
    print BYUSERS "<li><a href=\"#bypgs\">List of users by programs</a>\n";
    print BYUSERS "</ul>\n";  
    print BYUSERS "<hr>\n"; 

    print BYUSERS "
<p>$total_users users ($total_local_users local users), have used $total_pgs programs in $total_jobs jobs (advanced: $total_advanced)</h4>
";

    do_users_by_name();
    do_by_domains();
    do_users_by_jobs();
    do_users_by_pgs();

    print BYUSERS "<hr>\n";
    
print BYUSERS "
</BODY>
</HTML>
";
close BYUSERS;

}

sub stat_by_users {
    $total_users = 0;
    $total_local_users = 0;
    $total_local_jobs = 0;
    $total_external_users = 0;
    $total_external_jobs = 0;
    $total_advanced = 0;
    undef %total_jobs_user;

    foreach $user (sort (keys %niveau)) {
	$total_users++;
	if ($user =~ /\@.*pasteur\.fr/) {
	    $local_users{$user} = 1;
	    $total_local_users++;
	} else {
	    $external_users{$user} = 1;
	    $total_external_users++;
	    if ($user =~ /.+\@.+\.\w+$/ ) {
		($country=$user) =~ s/.+\.(\w+)$/$1/ ;
		$total_users_by_country{$country}++;
	    }
	}
	$total_pgs{$user}=0;
	$total_jobs_user{$user}=0;
	foreach $program (sort (keys %{ $niveau{$user} } )) {
	    $total_pgs{$user}++;
	    foreach $date_num (sort (keys %{ $niveau{$user}{$program} } )) {
		$total_jobs_user{$user}++;
		if ($user =~ /\@.*pasteur\.fr/) {
		    $total_local_jobs++;
		} else {
		    $total_external_jobs++;
		}
		if ($niveau{$user}{$program}{$date_num} =~ "advanced") {
		    $total_advanced++;
		}
	    }
	}
    }
}

sub do_users_by_name {
    print BYUSERS "<hr>\n";
    print BYUSERS "<a name=local> <h2>Local users</h2>";
    print BYUSERS "<h4>$total_local_users local users / $total_local_jobs total jobs</h4>";

    foreach $user (sort (keys %local_users)) {
	print BYUSERS "\n<br><A HREF=\"\#$user\">$user</A>: $total_pgs{$user} program(s) / $total_jobs_user{$user} job(s)\n";
    }

    print BYUSERS "<hr>\n";
    print BYUSERS "<a name=external><h2>External users</h2>";
    
    $total_external_users = $total_users - $total_local_users;
    print BYUSERS "<h4>$total_external_users external users / $total_external_jobs total jobs</h4>";
    
    foreach $user (sort (keys %external_users)) {
	print BYUSERS "\n<br><A HREF=\"\#$user\">$user</A>: $total_pgs{$user} program(s) / $total_jobs_user{$user} job(s)\n";
    }


}

sub do_by_domains {
    print BYUSERS "<hr>\n";
    print BYUSERS "<a name=domains> <h2>By top domain:</h2>\n";
    foreach $country (reverse (sort {$total_users_by_country{$a} <=> $total_users_by_country{$b} } keys %total_users_by_country)) {
	print BYUSERS "<br><b>$country</b>: $total_users_by_country{$country}\n";
    }
}

sub do_users_by_jobs {
    print BYUSERS "<hr>\n";
    print BYUSERS "<a name=byjobs> <h2>List of users by number of jobs:</h2>\n";

    foreach $user (sort {$total_jobs_user{$b} <=> $total_jobs_user{$a}} (keys %total_jobs_user)) {
	print BYUSERS "\n<br><A NAME=$user><b>$user:</b> ";
	print BYUSERS "$total_jobs_user{$user} job(s) $total_pgs{$user} program(s)\n";
	print BYUSERS "\n<ul>\n";
	foreach $program (sort (keys %{ $niveau{$user} }) ) {
	    @jobs = keys %{ $niveau{$user}{$program}};
	    $jobs = $#jobs + 1;
	    print BYUSERS "\n<li>$program ($jobs)\n";
	}
	print BYUSERS "\n</ul>\n";
    }
}

sub do_users_by_pgs {
    print BYUSERS "<hr>\n";
    print BYUSERS "<a name=bypgs> <h2>List of users by programs:</h2>\n";

    foreach $program (sort (keys %command)) {
	print BYUSERS "\n<br><b>$program ($total_users{$program} users, $total_jobs_pg{$program} jobs):</b><ul>\n";
	foreach $user (sort (keys %{ $command{$program}})) {
	    print BYUSERS "\n<li><A HREF=\"\#$user\">$user</A>: ";
	    print BYUSERS "$total_pgs{$user} program(s) $total_jobs_user{$user} jobs(s)\n";
	}
	print BYUSERS "\n</ul>\n";
    }
}
