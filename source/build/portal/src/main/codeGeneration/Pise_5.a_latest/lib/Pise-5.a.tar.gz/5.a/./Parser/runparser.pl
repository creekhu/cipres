#! /local/bin/perl

use lib "/local/gensoft/lib/Pise/5.a/Parser";
use XML::Parser::PerlSAX;
use PiseParser;

my $xml = ($ARGV[0])? $ARGV[0] : '-';

$VERSION = ($ENV{'VERSION'}) ? $ENV{'VERSION'} : "5.a" ;
$PISEDIR = ($ENV{'PISEDIR'}) ? $ENV{'PISEDIR'} : "/local/gensoft/lib/Pise" ;

my $my_handler = PiseParser->new($PISEDIR,$VERSION);
$parser = XML::Parser::PerlSAX->new  (Handler => $my_handler);
$parser->parse (Source => { SystemId => $xml });

