#
# command line generation : 
#
# TODO:
#

sub do_command {

    my $defs = $_[0] ;
    my $command_line = "" ;
    my $precond;
    my $format;
    my $paramfile;

    foreach $param ( $defs->by_group_parameters ) {
	if ( defined $defs->precond($param,'perl') ) {
	    $precond = $defs->precond($param,'perl');
	    unless ( &my_eval ("$precond") ) {
		next;
	    }
	}
    	if ( defined $defs->format($param,'perl') || 
             defined $defs->flist($param)) {
            undef $paramfile;
	    if (defined $defs->paramfile($param)) {
		# not on the command line, in a parameter file instead
		($paramfile=$defs->paramfile($param)) =~ s/ //g ;
		if ( ! $openparamfile{$paramfile} ) {
		    open($paramfile, "> $paramfile")
			|| &panic("cannot open $paramfile:$!");
		    $openparamfile{$paramfile} = 1;
		}
	    }
	    if ( ! $defs->ishidden($param)) {
		if (&get_var($param) !~ /^\s*$/ ) {
		    &set_var("value", &get_var($param)) ;
		} else {
		    &set_var("value", undef);
		}
		&set_var("vdef", $defs->vdef($param));
	    }

	    if ( defined $defs->flist($param,&get_var("value")) ) {
                $format = $defs->flist($param,&get_var("value"));
            } else {
                $format = $defs->format($param,'perl');
            }
	    $arg = &my_eval("$format"); 
            if ($@) { 
		&panic("cannot eval format \"$format\" for $param (value is \"" .
		       &get_var("value") . "\")");
            }

	    if ( $paramfile ne "") {
		if ($arg ne "" ) {
		    print $paramfile $arg; 
		}
	    } else {
		$command_line .= $arg ;
	    }
    	}
    }

    $command_line =~ s/ +/ /g ;
    $command_line =~ s/^ // ;
    $command_line =~ s|\"|\\$&|g; ;
    $command_line =~ s|\@|\\$&|g; ;
    $command_line =~ s|_SQ_|\\\'|g; ;
    $command_line =~ s|_DQ_|\\\"|g; ;

    # close parameters files
    foreach $f (keys %openparamfile) {
	close($f);
	$openparamfile{$f} = 0;
    }

    foreach $p (keys %old) {
	$$param = $old{$p};
    }

    return $command_line;

}


sub do_stdout {

# scan parameters for explicit standard output file
# and set accordingly either:
# $defs->_interface_standout
# ${"${command}::_standout_file"}
# 
# (each interface generator has to manage a different kind 
# of "standard output")
# 

    my $defs = $_[0];
    my $precond;
    my $param;
    my $explicit_standout = 0;
    unless (defined $defs->_interface_standout) {
	$defs->_interface_standout(1);
    }

    if (defined $defs->isstandout) {
        my %standout = $defs->isstandout;
        foreach $param (keys %standout ) {
	    $precond = $defs->precond($param,'perl');
	    if ( defined $defs->precond($param,'perl') && 
		! &my_eval("$precond") ) {
		next;
	    }
	    # there is an explicit parameter for standard output
	    if ( $standout{$param} ) {
#print STDERR "explicit stdout\n";
		$explicit_standout = 1;
		if ( &get_var($param) eq "" ) {
		    $defs->_interface_standout(1);
		} else {
		    $defs->_interface_standout(0);
		    $defs->_standout_file(&get_var($param));
		}
		last;
	    }
        }
    }

    return;

}

1;
