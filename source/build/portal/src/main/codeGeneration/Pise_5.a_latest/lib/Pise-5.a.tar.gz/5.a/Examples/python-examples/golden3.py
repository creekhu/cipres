from Pise import PiseFactory
from Pise import JobError
from Bio.SwissProt import SProt

factory = PiseFactory(email='letondal@pasteur.fr')
golden = factory.program("golden",db="swissprot")
golden.verbose(1)
for id in ['MALK_ECOLI', '100K_RAT', '108_LYCES']:
    j=golden.run(query=id)
    #print j.stdout()
    print "jobid: ", j.jobid()
    try:
        handle = j.fh('golden.out')
    except Pise.JobError, e:
        print "probably not found e: ",e
        continue
    
    sp = SProt.Iterator(handle, SProt.RecordParser())
    record = sp.next()
    print record.entry_name
    print record.sequence
    handle.close()
    
