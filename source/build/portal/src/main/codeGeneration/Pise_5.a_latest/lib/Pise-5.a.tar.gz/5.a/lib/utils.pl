
# return the list of parameters with attribute simple = True
sub simple_parameters {
    my $command = $_[0] ;
    my @plist;

    for $p (@{"${command}::parameters_order"}) {
       if (${"${command}::simple"}{$p}) {
	   push (@plist, $p);
       } 
    }
    return @plist;
}

# return the list of parameters with attribute mandatory = True
sub mandatory_parameters {
    my $command = $_[0] ;
    my @plist;

    for $p (@{"${command}::parameters_order"}) {
       if (${"${command}::mandatory"}{$p}) {
	   push (@plist, $p);
       } 
    }
    return @plist;
}

1;
