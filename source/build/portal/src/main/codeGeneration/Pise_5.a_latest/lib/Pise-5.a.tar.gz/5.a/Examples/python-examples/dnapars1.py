from Pise import PiseFactory
import Bio.Clustalw
import sys

alig = Bio.Clustalw.parse_file(sys.argv[1])          

factory = PiseFactory(email='letondal@pasteur.fr')
dnapars = factory.program('dnapars', infile=alig, print_tree=1,verbose=1)
j=dnapars.run()
if j.error():
    print "Error: " + j.error_message()
else:
    j.verbose(0)
    print "Output:\n", j.content("outfile")

