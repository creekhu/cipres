
#
# output files
#

sub results {
    my $command = $_[0];
    my $param = $_[1];
    my $filenames;
    my @l;
    my $f;

    if ( ${"${command}::filenames"}{$param} =~ /\"/ ) {
	$filenames = &my_eval (${"${command}::filenames"}{$param});
    } else {
	$filenames = &my_eval ('"' . ${"${command}::filenames"}{$param} . '"');
    }

    open (LS, "ls $filenames 2> /dev/null |") || return @l;
    while (<LS>) {
	chop ;
	stat($_);
	if ((-M _) < 0) {
	    push (@l, $_);
	}
    }
    close (LS);
    return @l;
}

sub do_output {
    my $command = $_[0] ;
    my $param;
    my $precond;
    my $filename;
    my @results;
    my @outfiles;

    push (@outfiles,${"${command}::_standout_file"}) if (${"${command}::_interface_standout"});

    foreach $param ( @{ "${command}::parameters_order" } ) {
	$precond = ${"${command}::precond"}{$param};
	if ( defined ${"${command}::precond"}{$param} && 
	    ! &my_eval("$precond") ) {
	    next;
	}
        if ( ${"${command}::type"}{$param} eq "OutFile" ) {
            $filename = &get_var($param);
            unless ( $filename eq "" ) {
                push (@outfiles,$filename) unless (grep { $filename eq $_ } @outfiles);
            }
        } elsif ( ${"${command}::type"}{$param} eq "Results"  ) {
	    @results = &results($command,$param);
	    foreach $f (@results) {
		push (@outfiles, $f) unless (grep { $f eq $_ } @outfiles) ;
            }
	}
    }

    return @outfiles;
}

1;


