#! /local/bin/perl

use CGI;
use POSIX;

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";

my $input = new CGI;
$user_level=$input->param('user_level');
my $scratch_dir=$input->param('scratch_dir');

my $date=localtime;

#$ENV{'PISEDIR'}=$PISEDIR;
#$ENV{'CGI_DIR'}=$CGI_DIR;

require "/local/gensoft/lib/Pise/5.a/lib/web.pl";


$command=$input->param('command');

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";
eval ("use $command;");

my $defs = $command->new;
my $def = POSIX::tmpnam;
open (PERLDEF, "> $def") || die "cannot open $def:$!";
# to indicate that's a initform.pl intialization (make-simple-html.pl)
print PERLDEF "\$INITFORM = 1;\n";

if (defined $input->param('param')) {
    @params=$input->param('param');
#    print STDERR "several time param: @{ $FORM{'param'}}\n";
} else {
    @params= ( $input->param('param') );
#    print STDERR "1 time param: $FORM{'param'}\n";
}
foreach $param (@params) {
    #print STDERR "DEBUG> initform.pl $param\n";
    # **on one single line**
    $paramdata=$param . "_data";
    $type = $defs->type($param) ;
    if ($type eq "List") {
	$param_value=join (" ", sort ( $input->param($param)));
	print STDERR "DEBUG> ($type) (1) $param_value ($FORM{$param})\n";
	if (! $param_value) {
	    $param_value=$input->param($param);
	}
	print STDERR "DEBUG> ($type) (2) $param_value\n";
    } else {
	$param_value=(defined $input->param($paramdata)) ? $input->param($paramdata) : $input->param($param);
    }
    if ($type eq "Sequence" || $type eq "InFile") {
	my $file = ($scratch_dir)? "/$tmp_dir/$scratch_dir/$param_value" : "";
	if ($file && -f $file) {
	    my $rawdata="";
	    open(VALUE,$file) || die "cannot open $file: $!";
	    while (<VALUE>) {
		$_ =~ s/\"/\\\"/g;
		$rawdata .= $_;
	    }
	    close VALUE;
	    print PERLDEF "\$defs->vdef($param", "_data,\"";
	    $rawdata =~ s/\@/\\\@/;
	    print PERLDEF $rawdata;
	    print PERLDEF "\");\n";
	    $hidden{$param . "_data"}  = $rawdata;
	}
    } else {

	if ($param eq "email") {
	    if ($param_value =~ /\\/) {
		$param_value =~ s/\@/\@/;
	    } else {
		$param_value =~ s/\@/\\\@/;
	    }
	    print STDERR "[$date] initform.pl: $scratch_dir ($param_value)\n";
	} 
	if ($type eq "List") {
	    @list_values = split(' ',$param_value);
	    print PERLDEF "\$defs->vdef($param,";
	    print PERLDEF "[", join(', ',@list_values), "]);\n";
	    print PERLDEF "\@{ \$hidden{$param} } = ";
	    print PERLDEF "[", join(', ',@list_values), "];\n";
	} else {
	    $param_value =~ s/\"/\\\"/g;
	    print PERLDEF "\$defs->vdef(\'$param\',\"$param_value\");\n";
	    print PERLDEF "\$hidden{$param} = \"$param_value\";\n";
	}
   }
}
if (defined $scratch_dir) {
    print PERLDEF "\$scratch_dir=\"$scratch_dir\";\n";
}
print PERLDEF "1;\n";
close(PERLDEF);

# DEBUG
#open (TMP, $def) || die "cannot open $tmp: $!";
#while (<TMP>) { print STDERR $_; }; close TMP;
#print STDERR "DEBUG> initform.pl $def\n";

print "Content-type: text/html\n\n";

$make_html= "perl /local/gensoft/lib/Pise/5.a/Maker/";
$make_html .= ($user_level eq "simple")? "make-simple-html.pl" : "make-html.pl"; 
$make_html .= " $command $def"; 
open (HTML,"$make_html |") || die "cannot run $make_html:$!";
if ($scratch_dir) {
    chdir("/$tmp_dir/$scratch_dir") || die "can't cd to $scratch_dir: $!";
    my $custom_html = ($user_level eq "advanced")? "my_$command.html" : "my_$command-simple.html";
    open (CUSTOM, "> $custom_html") || die "cannot open $custom_html:$!";
    while (<HTML>) {
	print CUSTOM;
    }
    close(CUSTOM);

    print $input->start_html("Save your default values for $command.");
    print $input->h1("Save your default values for $command.");
    print "Save this form on your local disk, in <I>source</I> format:\n";
    print $input->a({href=>"$tmp_url/$scratch_dir/$custom_html"},"$custom_html");
    print $input->end_html;

} else {
    while (<HTML>) {
	print;
    }
}

close(HTML);
unlink $def;

