
# local features (batch system...)
# you probably should set this to 0
$PASTEUR=1;

# path in the url where you want the cgi to be accessible from the
# HTML form
# - this may not be the same path as for CGI-INSTALL-DIR (which is
#   the complete file path (e.g. /http/cgi-bin/seqanal))
# - this is the path actually used for the POST mark in the HTML page
# example: http://bioweb.pasteur.fr/cgi-bin/seqanal

$ROOT_WEB = "/bioweb";
$ROOT_URL = "http://bioweb.pasteur.fr/seqanal";

$CGI_DIR = "/cgi-bin/seqanal";
if (defined $ENV{'CGI_DIR'}) {
    $CGI_DIR=$ENV{'CGI_DIR'};
}
$CGI_URL = "http://bioweb.pasteur.fr/cgi-bin/seqanal";
if (defined $ENV{'CGI_URL'}) {
    $CGI_URL=$ENV{'CGI_URL'};
}


# where to work:
# this is the prefix for jobs results sub-directories
# for example, clustalw results are accessible at
# http://bioweb.pasteur.fr/seqanal/tmp/clustalw/xx
# where xx is a random umber
$tmp_url = "http://bioweb.pasteur.fr/seqanal/tmp"; 
$tmp_dir = "$ROOT_WEB/htdocs/seqanal/tmp"; 

# images url (for red-bullet.gif and blue-bullet.gif)
# see http://bioweb.pasteur.fr/images/red-bullet.gif
# and http://bioweb.pasteur.fr/images/blue-bullet.gif
# Images files in are distributed in the Images subdirectory.
$IMAGES_DIR="http://bioweb.pasteur.fr/images";

# who receives emails when problems occur
# PLEASE change it ;-)
$maintainer = "pise\\\@pasteur.fr";
#$help="help\\\@pasteur.fr";
$help="bioweb\\\@pasteur.fr";
# local mailhost
# PLEASE change it ;-)
$MAILHOST="mail.pasteur.fr";

# where to log jobs
$log="$ROOT_WEB/logs/bioweb.log";

# path for executing programs (mandatory)
$path = "/local/gensoft/bin/scripts:/local/gensoft/bin:/usr/local/bin:/usr/bin:/bin:/usr/sbin";

# database searching enabled (see lib/db.pl)
$DBSEARCH=1;

# max size for any file (2 Go)
$FILELIMIT = 4294967296 / 2;

# set this to 1 if you don't want results to be sent by email
# (this must be set at installation time)
# Notice: This does not make email optional.
# See Makefile.global to make the email optional for all programs
# or do a: make PROGRAM=program OPT_EMAIL=1
# to make it optional for a specific program
$DONT_EMAIL_RESULTS = 0;

# max size for results by email (2 Mo)
$MAXMAILSIZE = 2 * 1048576;

# parameter for nice (programs are run by the CGI with a given nice priority)
$NICE_VALUE=5;

# how long should results be available on the server?
# See Scripts/clean.pl
$RESULT_REMAIN=10;

# do you have readseq .... I hope so :-(
$READSEQ=1;

# do you have clustalw .... I hope so :-(
$CLUSTALW=1;

# do you have fmtseq 
# (SEQIO package ftp://ftp.cs.ucdavis.edu/pub/strings/seqio.tar.gz)
# (our local copy: ftp://ftp.pasteur.fr/pub/GenSoft/unix/programming/seqio-1.2.2.tar.gz)
$FMTSEQ=1;

## BATCH system to use

# LSF: Load Sharing Facility
$LSF = 0;

# PBS: Portable Batch System
$PBS = 1;

1;
