#! /local/bin/perl
#
# send tcl code for program
# 

use CGI;

$request=new CGI;

$command=$request->param('command');
print $request->header(-type=>'text/plain');

$VERSION="5.a";
$PISEDIR="/local/gensoft/lib/Pise/$VERSION";
$ENV{'VERSION'}=$VERSION;
$ENV{'PISEDIR'}=$PISEDIR;
print STDERR "request for $command make-tcl\n";
$make_tcl= "perl $PISEDIR/Maker/make-tcl.pl";
$make_tcl .= " $command"; 
open (TCL,"$make_tcl |") || die "cannot run $make_tcl:$!";
$i=0;
while (<TCL>) {
    print;
    $i++;
}
close(TCL);
print STDERR "$i line(s) read\n";
