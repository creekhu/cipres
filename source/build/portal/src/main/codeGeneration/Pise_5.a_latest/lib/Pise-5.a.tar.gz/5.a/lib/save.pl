#! /local/bin/perl

# save.pl
# summary.pl, mailhelp.pl should be symbolic links to save.pl

use CGI;
use File::Basename;
use MIME::Lite ;

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";

# Get the input
my $input = new CGI;

$command=$input->param('command');
$scratch_dir=$input->param('scratch_dir');

if (defined $input->param('summary_format')) {
    if ($input->param('summary_format') eq "tabular") {
	$tabular= 1;
    } elsif ($input->param('summary_format') eq "freetext") {
	$freetext=1;
    }
} else {
    $tabular=$input->param('tabular');
    $freetext=$input->param('freetext');
}
$savefiles=$input->param('savefiles');
$helpform=$input->param('helpform');
$save_format = $input->param('save_format');
$email=$input->param('email');
$email =~ s|\\||g;
$user_level=$input->param('user_level');
if (defined $input->param('pise_version')) {
    $VERSION=$input->param('pise_version');
} else {
    $VERSION="5.a";
}

if (defined $input->param('PISEDIR')) {
    $PISEDIR=$input->param('PISEDIR');
} else {
    $PISEDIR="/local/gensoft/lib/Pise/$VERSION";
}
$ENV{'PISEDIR'}=$PISEDIR;

if (defined $input->param('PERLDEFDIR')) {
    $PERLDEFDIR=$input->param('PERLDEFDIR');
} else {
    $PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : "/local/gensoft/lib/Pise/5.a/PerlDef";
}

require "$PISEDIR/lib/web.pl";
use lib "/local/gensoft/lib/Pise/5.a/PerlDef";
eval ("use $command;");
my $defs = $command->new;

my $date=localtime;
$me = basename $0;

print STDERR "[$date] $me: $command ($scratch_dir) (", $input->param('summary_format'), ") ($email) \n";

printf "Content-type: text/html\n\n";

if ($helpform) {
    print "
<h3>help on your $command job</h3>
";
} elsif ($savefiles) {
    print "
<h3>Save your $command job</h3>
";
} else {
    print "
<h3>$command job summary</h3>
";
}

if ($email) {
    print "
<i>Your e-mail:</i> $email
<BR><BR>
";
} 

if ($tabular) {
    print "

<TABLE border=1>
";
} elsif ($freetext || $helpform) {

    if ($helpform) {
	print "<I>Put your message in the box below. The first lines are aimed at informing the help people about your job</I>.\n";
        print "<FORM method=POST action=\"$CGI_URL/lib/help.pl\">\n";
        if (not $email) {
	    print "Your e-mail: <INPUT NAME=\"email\" SIZE=40 ><BR></BR>\n"; 
	}
        print "Subject: <INPUT NAME=\"subject\" SIZE=70>\n";
 
    } else {
        print "<FORM method=POST action=\"$CGI_URL/lib/annot.pl\">\n";
        print "<INPUT NAME=\"email\" TYPE=\"HIDDEN\" VALUE=\"$email\">\n";
        print "<INPUT NAME=\"command\" TYPE=\"HIDDEN\" VALUE=\"$command\">\n";
    }

    if ($helpform) { 
         print " 
<TEXTAREA NAME=\"message\" ROWS=25 COLS=80>
";
	 my $unix_command = $input->param('unix_command');
         if ($email) {
	     print "E-mail: $email\n";
         } 
         print "
Url: <URL:$tmp_url/$scratch_dir>
Unix exact command: $unix_command

Parameters for $command:

";
    } else {
         print "
<TEXTAREA NAME=\"freearea\" ROWS=15 COLS=80>
";
    }
}

$br = "";

foreach $param ($input->param) {
    #print STDERR "DEBUG> param=$param\n";
    $prompt = $defs->prompt($param) ;
    $type = $defs->type($param) ;
    $value = $input->param($param);
    if ($type eq "List") {
	@vdef = @{ $defs->vdef($param) };
	$separator = $defs->separator($param) ;
	$vdef = join ($separator,sort( @vdef));
	$value = join ($separator,sort(split(/\s/,$value)));
#	print STDERR "DEBUG> [$date] $me: List type vdef = $vdef value = $value ($separator) ($command)\n";
    } else {
	$vdef = $defs->vdef($param) ;
    }
    if ($prompt) {
	if (($type eq "InFile" || $type eq "Sequence") && $value ) {
            if ($tabular) {
		print "<TR><TD>$prompt</TD><TD><A HREF=\"$tmp_url/$scratch_dir/$value\">$value</A>\n";
	    } elsif ($freetext || $helpform) {
		print "$prompt:\t<URL:$tmp_url/$scratch_dir/$value>\n";
	    } else {
		print "$br $prompt:\t<A HREF=\"$tmp_url/$scratch_dir/$value\">$value</A>\n";
		$br = "<BR>";
	    }
        } elsif ($type eq "Switch") {
            #print STDERR "DEBUG> save.pl $param: val=$value def=$vdef\n";
	    if (($value && ! $vdef) || (! $value && $vdef)) {
		if (! $value) {
		    if ($tabular) {
			print "<TR><TD>$prompt</TD><TD>False</TD></TR>\n";
		    } elsif ($freetext || $helpform) {
                        print "$prompt:\tFalse\n";
		    } else {
                        print "$br $prompt:\tFalse\n";
			$br = "<BR>";
		    }
		} else {
		    if ($tabular) {
			print "<TR><TD>$prompt</TD><TD>True</TD></TR>\n";
		    } elsif ($freetext || $helpform) {
                        print "$prompt:\tTrue\n";
		    } else {
                        print "$br $prompt:\tTrue\n";
			$br = "<BR>";
		    }
		}
	    }
        } elsif ($type ne "Paragraph" ) {
            if (defined $value && $value ne $vdef) {
		if ($tabular) {
		    print "<TR><TD>$prompt</TD><TD>$value</TD></TR>\n";
		} elsif ($freetext || $helpform) {
                    print "$prompt:\t$value\n";
		} else {
                    print "$br $prompt:\t$value\n";
 		    $br = "<BR>";
		}
	    }
	}
    }
}

if ($helpform) {
    print "
-------------------------------------------------------------------
Your message:
";
}

if ( ! $tabular ) {
    print "
</TEXTAREA>
";
}

if ($helpform) {
    $help =~ s/\\//g;
    print "<Input TYPE=\"submit\" VALUE=\"Send message to $help\">\n";
    foreach $param ($input->param) {
	if ($param eq "savefiles") {
        } elsif ($param eq "tabular") {
        } else {
	    if ($param ne "email" || $input->param($param) ne "") {
		print "<INPUT NAME=\"$param\" TYPE=\"HIDDEN\" VALUE=\"",$input->param($param),"\">\n" ;
	    }
        }
    }
}

if ($freetext  && (! $helpform)) {
    if ($email) {
	print "<Input TYPE=\"submit\" VALUE=\"Send this text to: $email\">\n";
    } else {
	print "<Input TYPE=\"submit\" VALUE=\"Send this text to: \">\n";
        print "<INPUT NAME=\"email\" SIZE=40> (enter your email)\n";
    }
}

if ($tabular) {
    print "
</TABLE>
";
} else {
    print "
</FORM>
"; 
}

if ($savefiles) {
    print STDERR "[$date] $me: saving $command in $save_format (",$input->param('email'), ")\n";
    chdir "$tmp_dir/$scratch_dir";
    open (LS, "ls * |");
    while (<LS>) {
	chop;
	$f=$_;
	if ($f ne "script" && $f ne "index.html" && $f ne "bsub.err" &&
	    $f ne "$command.zip" && $f ne "$command.tar.gz" ) {
	    push (@l,$f);
	}
    }
    close LS;
    if ($save_format eq "tarfile") {
	stat("$command.tar.gz");
	if (! (-e _) ) {
	    # option h in tar : Forces tar to follow symbolic links as if 
	    # they were normal files or directories. 
	    # (problem for big files, but necessary for piped files)
	    $cmd = "tar chf - " . join (" ",@l) . " > $command.tar; gzip $command.tar";
	    system($cmd);
	}
	print "<HR><i>Job input and output files:</i> <A HREF=\"$tmp_url/$scratch_dir/$command.tar.gz\">$command.tar.gz</A>\n";
        print "<BR> Enter: <BR><CODE>gunzip -c $command.tar.gz | tar xvf -</CODE><BR>on your Unix box to get your files.\n";
    } elsif  ($save_format eq "zip") {
	stat("$command.zip");
	if (! (-e _) ) {
	    $cmd = "zip $command " . join (" ",@l);
	    system($cmd);
	}
	print "<HR><i>Job input and output files:</i> <A HREF=\"$tmp_url/$scratch_dir/$command.zip\">$command.zip</A>.\n";
        print "<BR> Enter: <BR><CODE>unzip -d $command</CODE><BR>on your computer to get your files.\n";

    } elsif  ($save_format eq "MIME") {
	if ($email) {
	    my $message = new MIME::Lite ( 
				      From    => $email ,
				      To      => $email ,
				      Subject => "$command files (<URL:$tmp_url/$scratch_dir>)" ,
				      Type    => 'multipart/mixed' ) ;
	    $tot_size = 0;
	    foreach $file (@l) {
		stat($file);
		$size = (-s _ );
		$tot_size += $size;
		if ($size > 0 && $tot_size < $MAXMAILSIZE) {
		    $message->attach ( Type        => 'TEXT' ,
				       Encoding    => 'base64' ,
				       Disposition => 'attachment' ,
				       Path        => "$file" ) ;
		    if ($sent_files) {
			$sent_files .= ", $file";
		    } else {
			$sent_files = "$file";
		    }
		}

	    }
	    $message->send ( ) ;
	
	    print "<HR><i>Job input and output files:</i> $save_format: the files  ($sent_files) have been encoded and sent by email to: $email.\n";
	} else {
	    print "<HR></HR><B>For MIME attachment, you must provide a valid email.</B>\n";
	}
    } else {
	print "<HR><i>Job input and output files:</i> $save_format: this format is not implemented yet.\n";
    }
}


if ( ! $helpform ) {
    print "<HR><i>Unix exact command:</i><BR><CODE>",$input->param('unix_command'),"</CODE><HR>\n";
}


if ((! $savefiles) && (! $helpform)) {
    # Save button
    print "<FORM method=POST action=\"$CGI_URL/lib/save.pl\">\n";
    foreach $param ($input->param) {
	if ($param eq "savefiles") {
	} elsif ($param eq "tabular") {
	} elsif ($param eq "freetext") {
	} elsif ($param eq "helpform") {
	} elsif ($param eq "summary_format") {
	} else {
	    if ($param ne "email" || $input->param($param) ne "") {
		print "<INPUT NAME=\"$param\" TYPE=\"HIDDEN\" VALUE=\"",$input->param($param),"\">\n" ;
	    }
	}
    }
    print "<INPUT NAME=\"summary_format\" TYPE=\"HIDDEN\" VALUE=\"tabular\">\n" ;
    print "<INPUT NAME=\"savefiles\" TYPE=\"HIDDEN\" VALUE=\"1\">\n" ;
    print "<Input TYPE=\"submit\" VALUE=\"Save job files\">\n" ;
    print "
<select name=\"save_format\">
<option value=\"tarfile\">gzipped tar file
<option SELECTED value=\"MIME\">MIME attachments
<option value=\"zip\">zip
</select>
";
   if (not $email) {
	    print "e-mail (for MIME attachment): <INPUT NAME=\"email\" SIZE=40 >\n"; 
    }
    print "\n</FORM>\n" ;
    print "<I>This \"Save job files\" button allows you to save the input and output files of this job in the chosen format. By choosing MIME, you may also receive the results by email as attachments.</I>";


    # button "Save form"
    print " 
<FORM method=POST action=\"$CGI_URL/lib/initform.pl\">
";
    foreach $param ($input->param) {
	$prompt = $defs->prompt($param) ;
        if ($prompt) {
	    print "<INPUT NAME=\"param\" TYPE=\"HIDDEN\" VALUE=\"$param\">\n" ;
	    print "<INPUT NAME=\"$param\" TYPE=\"HIDDEN\" VALUE=\"",$input->param($param),"\">\n" ;
	}
    }
    my $tmp_email;
    ($tmp_email = $email) =~ s|\@|\\\@|g;

    print "<INPUT NAME=\"param\" TYPE=\"HIDDEN\" VALUE=\"email\">\n" ;
    print "<INPUT NAME=\"email\" TYPE=\"HIDDEN\" VALUE=\"$tmp_email\">\n" ;
    if (!  $user_level) {
       $user_level = "simple";
    }
    print " 
<INPUT NAME=\"command\" TYPE=\"HIDDEN\" VALUE=\"$command\">
<INPUT NAME=\"VERSION\" TYPE=\"HIDDEN\" VALUE=\"$VERSION\">
<INPUT NAME=\"scratch_dir\" TYPE=\"HIDDEN\" VALUE=\"$scratch_dir\">
<BR>
<Input TYPE=\"submit\" VALUE=\"Save $command form with these default values\">
<INPUT NAME=\"user_level\" TYPE=\"HIDDEN\" VALUE=\"$user_level\">
</FORM>
";
    print "<I>This \"Save $command form...\" button allows you to save a form with the values that you have used for this job as default values (except input sequence or other input data). <B>Do not bookmark this form</B>, but instead <B>save</B> it <B>as</B> a local file. </I>";


    # button "Macro"
    print " 
<FORM method=POST action=\"$CGI_URL/lib/webmacro.pl\">
";
    ($tmp_email = $email) =~ s|\@|\\\@|g;
	
    print "<INPUT NAME=\"param\" TYPE=\"HIDDEN\" VALUE=\"email\">\n" ;
    print "<INPUT NAME=\"email\" TYPE=\"HIDDEN\" VALUE=\"$tmp_email\">\n" ;
    if (! $user_level) {
	$user_level = "simple";
    }
    print " 
<INPUT NAME=\"command\" TYPE=\"HIDDEN\" VALUE=\"$command\">
<INPUT NAME=\"scratch_dir\" TYPE=\"HIDDEN\" VALUE=\"$scratch_dir\">
<INPUT NAME=\"VERSION\" TYPE=\"HIDDEN\" VALUE=\"$VERSION\">
<INPUT NAME=\"user_level\" TYPE=\"HIDDEN\" VALUE=\"$user_level\">
<BR>
<Input TYPE=\"submit\" VALUE=\"Register the whole procedure\">
</FORM>
";
    print "<I>Save all the commands you have done with their parameters for later reuse.</I>\n";


    print "<HR>\n";

}
