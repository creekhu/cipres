#
# Generate the code for a (bio)python module
#

package Maker;

my $command=$ARGV[0];

my $perldef = "/local/gensoft/lib/Pise/5.a/PerlDef/$command.pm";

require $perldef;

my $defs = $command->new;
my $title = "Python class for:\n\n\t";
$title .= $defs->title . "\t" . $defs->description;
if ($defs->authors) {
    $title .= " (" . $defs->authors . ")";
}
if (defined $defs->reference) {
    $title .= "\n\n\tReferences:\n";
    foreach my $ref ($defs->reference) {
	$title .= "\n\t\t" . $ref . "\n"; 
    }
}

print "
from Pise import PiseApplication

class $command(PiseApplication):

\t\"\"\"
      $title

";

my @parameters = $defs->parameters_order;

foreach my $param (@parameters) {
    my $type = $defs->type($param);
    my $prompt = $defs->prompt($param);
    my %pipein = $defs->pipein($param);
    my %pipeout = $defs->pipeout($param);

    print "\n\t\t$param ($type)\n\t\t\t$prompt\n";
    
    foreach my $in (keys %pipein) {
	if ($in) {
	    print "\t\t\tpipe: $in\n";
	}
    }
    foreach my $out (keys %pipeout) {
	if ($out) {
	    print "\t\t\tpipe: ",$pipeout{$out},"\n";
	}
    }
}


print "
\t\"\"\"

\tdef __init__(self, **args):

\t\tself._command = \"$command\"

\t\tself._parameters = [
";

foreach my $param (map { "\"$_\"," } @parameters) {
    print "\t\t\t$param\n";
    
}

print "\t\t]
";

print "
\t\tself._param_type = {
";
foreach my $param ( @parameters) {
    my $type = $defs->type($param);
    print "\t\t\t\"$param\" : '$type',\n";
    
}
print "\t\t}
";

print "
\t\tself._vdef = {
";
foreach my $param ( @parameters) {
    my $vdef = $defs->vdef($param);
    if (defined $vdef) {
	print "\t\t\t\"$param\" : '$vdef',\n";
    }
    
}
print "\t\t}
";

print "
\t\tself._pipetype = {
";
foreach my $param ( @parameters) {
    my $pipeins = $defs->pipein($param);
    if ($pipeins) {
	my %pipeins = $defs->pipein($param);
	print "\t\t\t\"$param\" :[\n";
	foreach my $pipein (keys %pipeins) {
	    if ($pipein) {
		print "\t\t\t\t '$pipein',\n";
	    } 
        }
	print "\t\t\t],\n";
    }
    
}
print "\t\t}
";

print "\n\n\t\tPiseApplication.__init__(self, **args)\n";

