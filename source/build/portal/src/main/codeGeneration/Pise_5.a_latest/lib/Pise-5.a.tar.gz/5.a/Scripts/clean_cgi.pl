#! /local/bin/perl

#
# This is an old script, use instead clean.pl
#

require "/local/gensoft/lib/Pise/5.a/lib/web.pl";

$days = $ARGV[0];
$delzipfiles = $ARGV[1];

if (! $days) {
    $days = 5; # 5 days
}

$resdir=$tmp_dir;

open(LS,"ls $resdir |") || die "cannot open $resdir:$!";
@ls = <LS>;
close(LS);

$now = time;
$delay = $days * 24 * 60 * 60;  
$zipdelay = 60 * 60;

if ($delzipfiles) {
    print STDERR "cleaning zip and gzip files older than $zipdelay seconds in $resdir...\n";
} else {
    print STDERR "cleaning files older than $days days in $resdir...\n";
}

foreach $pg_dir (@ls) {
    chop($pg_dir);
    next if ($PASTEUR && ($pg_dir =~ /irene/i || $pg_dir =~ /CINEMA/i));

    # pb si fichier en modif a l'interieur du repertoire (jobs longs 
    # qui ne creent pas de nouveaux fichiers)
    # $cmd = "find $resdir/$pg_dir ! -name '.' ! -name $d -type d -mtime +1 -prune -exec rm -rf \\{\\} \\;";
    # system($cmd);

    opendir(PG,"$resdir/$pg_dir");
    @tmpdirs = readdir PG;
    close PG;
    foreach $tmpdir (@tmpdirs) {
	next if ($tmpdir eq ".");
	next if ($tmpdir eq "..");
	stat("$resdir/$pg_dir/$tmpdir");
	if ( -d _ ) {
	    if ($delzipfiles) {
		opendir(DIR,"$resdir/$pg_dir/$tmpdir");
		@allfiles = readdir DIR;
		close DIR;
		foreach $file (@allfiles) {
		    next if (! ($file eq "$pg_dir.tar.gz" || $file eq "$pg_dir.zip"));
		    @status = stat ("$resdir/$pg_dir/$tmpdir/$file");
		    $mtime = $status[9];
		    $diff = $now - $mtime;
		    if ($diff > $zipdelay ) {
			# print STDERR "deleting $resdir/$pg_dir/$tmpdir/$file ($diff $mtime)\n";
			$cmd="rm -f $resdir/$pg_dir/$tmpdir/$file";
			system ("$cmd");
		    }
		}
	    } elsif (is_old_dir("$resdir/$pg_dir/$tmpdir")) {
		$cmd="rm -rf $resdir/$pg_dir/$tmpdir";
		system ("$cmd");
	    }
	}
    }
}
$cmd = "find $resdir -name core -exec rm -f \\{\\} \\;";
system($cmd);

sub is_old_dir {
    my $dir=$_[0];
    my ($dev,$ino,$mode,$nlink,$uid,$gid,$redev,$size,$atime,$mtime,$ctime,$blksize,$blocks);
    my $diff;
    my $file;

    opendir(DIR,$dir);
    @allfiles = readdir DIR;
    close DIR;

    foreach $file (@allfiles) {
	next if ($file eq ".");
	next if ($file eq "..");
	($dev,$ino,$mode,$nlink,$uid,$gid,$rdev,$size,$atime,$mtime,$ctime,$blksize,$blocks) = stat("$dir/$file");
	$diff = $now - $mtime;
	if ($diff < $delay ) {
	    return 0;
	}
    }
    return 1;
}
