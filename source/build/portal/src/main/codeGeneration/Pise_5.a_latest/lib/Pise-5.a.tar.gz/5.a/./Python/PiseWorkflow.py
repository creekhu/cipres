"""


This is an adaptation of PiseWorkflow.pm (C. Letondal, S. Thoraval)
by P.Tuffery and C. Letondal

Usage should be the transposition of the perl syntax.

Compared to the perl module, internal management differ largely.
More general workflow including multiple input and output are now possible.

Simple example:

from PiseWorkflow import *
from Pise import PiseFactory
import Bio.Clustalw

# alig = Bio.Clustalw.parse_file(sys.argv[1])          

factory  = PiseFactory()
dnapars  = factory.program('dnapars', infile=alig, print_treefile=True,verbose=True)
drawtree = factory.program('drawtree', verbose=True)

from PiseWorkflow import *
x = PiseWorkflow(verbose=0)
x.addpipe(method=clustalw, tomethod=drawtree, pipetype="phylip_tree")
x.run()

print x


"""

import sys
import string
import os
import random
# import cPickle
import fcntl


from Pise import *

class SingleTask:
    """
    Class for a single task of the workflow
	fields are:
	method      : PISE instance
	methodid    : unique id of the method in the workflow (from 0).
	tomethodids : a list of ids to which the method is piped (output)
	ffrom       : a list of ids pied to the method (input)
	pipetype    : a list of the types of the parameters for each of ffrom
	status      : a string describing the status of the task.
		One of: declared, lauchned, waiting, running, done, error
	error       : error string (if any)
	job         : PISE job instance (PISE.submit())

        __str__()   : a method to print the status and error string.
		could be html as well.
    """
    def __init__(self, method = None, methodid = None, tomethodids = None, ffrom= None , pipetype= None, status= "declared", error= "", job= None):
        self.data = {}
        self.data ["method"]      = method
        self.data ["methodid"]    = methodid
        if tomethodids == None:
            self.data ["tomethodids"] = []
        else:
            self.data ["tomethodids"] = tomethodids
        if ffrom == None:
            self.data ["ffrom"] = []
        else:
            self.data ["ffrom"] = ffrom
        if pipetype == None:
            self.data ["pipetype"] = []
        else:
            self.data ["pipetype"] = pipetype
        self.data ["job"]         = None

	# for print purpose 
	self.__status = ""
	self.__error = ""
    
    def method(self,value = None):
        if value == None:
            return self.data ["method"]
        else:
            self.data ["method"]      = value
    
    def methodid(self,value = None):
        if value == None:
            return self.data ["methodid"]
        else:
            self.data ["methodid"]      = value
    
    def tomethodids(self,value = None):
        if value == None:
            return self.data ["tomethodids"]
        else:
            self.data ["tomethodids"]      = value
    
    def ffrom(self,value = None):
        if value == None:
            return self.data ["ffrom"]
        else:
            self.data ["ffrom"]      = value
     
    def pipetype(self,value = None):
        if value == None:
            return self.data ["pipetype"]
        else:
            self.data ["pipetype"]      = value
     
    def job(self,value = None):
	# print >>sys.stderr, "SingleTask/job: job assign:",value
        if value == None:
            return self.data ["job"]
        else:
            self.data ["job"]      = value

    def _print(self, status, error):
	self.__status = status
	self.__error = error
	return self.__str__()

    def __str__(self):
	s = ''
        s += ("task %s " % self.data["methodid"]) + "\n"
        s += ("ffrom       : %s" % self.data["ffrom"]) + "\n"
        s +=  ("tomethodids : %s" % self.data["tomethodids"]) + "\n"
        s += ("pipetype    : %s" % self.data["pipetype"]) + "\n"
        s += ("status      : %s" % self.__status) + "\n"
        s += ("error       : %s" % self.__error) + "\n"
        s += ("job         : %s" % self.data["job"]) + "\n"
        s += "--------\n"
	self.__status = ""
	self.__error = ""
 	return s
       
class PiseWorkflow:
    """
    tasks: a list of the PISE tasks, the way their are chained, etc
    status: the status and error message for each task
    """
    def __init__(self, method = None, verbose = 0):
        self.ntasks   = 0
        self.tasks    = []
        self.status   = []
        self.error    = []
        self.interval = 0.01
        self.verbose  = verbose
	self.parent   = True
        self.level    = 0

        if method != None:
            task = SingleTask(method = method, methodid = self.ntasks)
            self.ntasks += 1
            self.tasks.append(task)
            self.methods.append(method)
            self.status.append("declared")
            self.error.append("")

    def _method(self, method = None):
        """
        _method
        This one scans for the registered methods and returns the one
        (if any) that corresponds to the 'method'.
        method must be a PiseApplication, but this _method will
        work with strings as well for debug.
        """
        if method == None:
            return None
        for task in self.tasks:
            if task.method() == method:
                return task
        return None
        
    def addpipe(self, method = None, tomethod = None, pipetype = None, verbose = 0):
        """
        addpipe
        Defines a pipe between method and tomethod, the data passed is of pipetype
        method and tomethod must be a PiseApplication.
        pipetype is a string.
        the verbose flag may help debug if addpipe fails (0 -> 1)

        Tested on September 14th, 2005
        
        Usage:
        addpipe(method, tomethod, pipetype)
        """
        
        if (method == None) or (tomethod == None):
            if verbose:
                sys.stderr.write("%s\n" % "addpipe: undefined method or tomethod argument")
            return
        if pipetype == None:
            if verbose:
                sys.stderr.write("%s\n" % "addpipe: undefined pipetype argument")
            return

        m = self._method(method)
        if m == None:
            # Are we starting a workflow ?
            self.tasks.append(SingleTask(method = method, methodid = self.ntasks))
            self.status.append("declared")
            self.error.append("")
            self.ntasks += 1
            m = self._method(method)

        p = self._method(tomethod)
        if p == None:
            self.tasks.append(SingleTask(method = tomethod, methodid = self.ntasks, ffrom = [m.methodid()], pipetype = [pipetype]))
            self.status.append("declared")
            self.error.append("")
            self.ntasks += 1
            p = self._method(tomethod)
        else:
            p.data["ffrom"].append(m.methodid())
            p.data["pipetype"].append(pipetype)
            
        m.data["tomethodids"].append(p.methodid())


    def run(self, interval = 100, html = None, verbose = 0):
        """
        run the complete workflow
        Workflows MUST be run by calling run.
        interval :
        html     :
        verbose  : some debugging facility
        """
        self.interval = int(interval)
        self.verbose = verbose
        self.html = None
        
        if html != None:
            self.html = html
            try:
                f = open(self.html)
                f.close()
            except:
                self.html = None

        key = int(random.random()*100000)
        if self.html == None:
            self.html = ("jobs_%5d" % key)
            f = open(self.html,"w")
            f.close()
        sys.stderr.write("PiseWorkflow/run: Jobs\'s informations will be written and updated in file %s\n" % self.html)
        self.dump = ("%5d.dump" % key)
        sys.stderr.write("PiseWorkflow/run: dump file is  %s\n" % self.dump)

        # before we start, we MUST write the tasks to the dump file
        # We reset all the tasks (if mutliple runs, but unmanaged yet)
        for i in range(0,len(self.tasks)):
            self.status[i] = "declared"
        self._statuswrite()

        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/run: initial states:"
            print >>sys.stderr, self
        

        self._launch() # here the run really starts

        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/run: final workflow status:"
            print >>sys.stderr, self

    def _statuswrite(self):
        try: 
            f = open(self.dump, "w")
            fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            for i in range(0,len(self.tasks)):
                f.write("%d %s \"%s\" \"%s\"\n" % (self.tasks[i].methodid(),self.status[i],self.error[i],self.tasks[i].job()))
            f.flush()
            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            f.close()
        except:
            return


    def _statusread(self, verbose = 0):
        try: 
            f = open(self.dump, "r")
            try:
                fcntl.flock(f.fileno(), fcntl.LOCK_EX)
            except IOError, (error, message):
                if verbose:
                    print >>sys.stderr, "PiseWorkflow/statusread:  (parent ? ", self.parent, ")", self.dump, " fileno: ", f.fileno()
                    print >>sys.stderr, "PiseWorkflow/statusread: exception during flock()", message
            if verbose: 
                print >>sys.stderr, "PiseWorkflow/_statusread:"
            lines = f.readlines()
            for i in range(0,len(self.tasks)):
                if verbose: 
                    print >>sys.stderr, "PiseWorkflow/_statusread: lines[i]=", lines[i]
                s  = string.split(lines[i],"\"")
                if verbose: 
                    print >>sys.stderr, "PiseWorkflow/_statusread: s=", s
                it = string.split(s[0])
                self.status[i] = it[1]
                self.error[i]  = s[1]
                self.tasks[i].job(s[3])
                if verbose: 
                    print >>sys.stderr, "PiseWorkflow/_statusread: t1[1]=%s s[1]=%s s[3] =%s" % (it[1],s[1],s[3])

            fcntl.flock(f.fileno(), fcntl.LOCK_UN)
            f.close()
        except Exception, e:
            print >>sys.stderr, "PiseWorkflow/_statusread: exception during open: ", e


    def _statusupdate(self, rank, verbose = 0):
        """
        rank is the rank of the task (current task) to update in the status dump file
        """
        
        # 1. We read the content
        f = open(self.dump, "r+")
        fcntl.flock(f.fileno(), fcntl.LOCK_EX)

        lines  = f.readlines()
        status = []
        error  = []
	job    = []
        for i in range(0,len(self.tasks)):
            s  = string.split(lines[i],"\"")
            it = string.split(s[0])
            status.append(it[1])
            error.append(s[1])
	    job.append(s[3])

        # 2. We update it
        status[rank] = self.status[rank]
        error[rank]  = self.error[rank]
        job[rank]    = self.tasks[rank].job()
        if verbose:
            print >>sys.stderr, "PiseWorkflow/_statusupdate: status job=", self.status[rank], job[rank]
        
        # 3. we write it back
        f.seek(0)
        for i in range(0,len(self.tasks)):
            f.write("%d %s \"%s\" \"%s\"\n" % (self.tasks[i].methodid(),status[i],error[i],job[i]))
        
        # 4. unlock, close file
        f.flush() # make sure we have updated the file
        fcntl.flock(f.fileno(), fcntl.LOCK_UN)
        f.close()
        if verbose:
            print >>sys.stderr, "PiseWorkflow/_statusupdate: done"

    def _launch(self, methodids = [0]):
        """
        Recursive travel among the graph of the workflow.
        This one makes the forks.
        From PiseWorkflow.pm _init -> launch to avoid confusion here.
        """

        self.level += 1
        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_launch: considering :",methodids, "lauch level ",self.level
            
        children  = 0 # Obsolete since we have a list of children pids (next line)
        childpids = []

        # We process a list of methods
        for methodid in methodids:

            if self.status[methodid] != "declared":
                continue

            # We make sure all parents are completed
            self._statusread()
            if self.verbose:
                print >>sys.stderr, "PiseWorkflow/_launch: considering methodid :",methodid

            # for parent in self.tasks[methodid].ffrom():
            parents = self.tasks[methodid].ffrom()
            pipetypes = self.tasks[methodid].pipetype()
            for i in range(0,len(parents)):
                parent = parents[i]
                pipetype = pipetypes[i]
                if self.status[parent] != "done":
                    self.status[methodid] = "waiting"
                    self._statusupdate(methodid)
                    if self.verbose:
                        print >>sys.stderr, "PiseWorkflow/_launch ",methodid,": will wait for ", parent,">>>>"
                    pstatus = self._wait(parent)
                    if self.verbose:
                        print >>sys.stderr, "PiseWorkflow/_launch",methodid,": completed wait for ", parent," got status",pstatus,"<<<<"
                    if pstatus != "ok":
                        self.status[methodid] = "error"
                        self.error[methodid] = "broken pipe"
                        self._statusupdate(methodid)
                        if self.verbose:
                            print >>sys.stderr, "PiseWorkflow/_launch: ERROR BROKEN PIPE"
                        self.level -= 1
                        return "waiterror"
                self._pipe(parent,methodid, pipetype)
                if self.verbose:
                    print >>sys.stderr, "PiseWorkflow/_launch",methodid,": pipe ",parent, "to", methodid,"type",pipetype

            # We run the process
            try:
                childpid = os.fork()
            except:
                # This includes a raise SystemExit
                if self.verbose:
                    sys.stderr.write("Could not fork. Workflow execution broken.")
                self.level -= 1
                return "forkerror"
        
            if childpid==0:
                # child
		self.parent = False
                os.getpid()
                if self.verbose:
                    print >>sys.stderr, "PiseWorkflow/_launch",methodid,": child=", children , childpids

                # we close the file descriptors
                try:
                    maxfd = os.sysconf("SC_OPEN_MAX")
                except (AttributeError, ValueError):
                    maxfd = 256       # default maximum
        
                for fd in range(4, maxfd):
                    try:
                        os.close(fd)
                    except OSError:   # ERROR (ignore)
                        pass

                if self.verbose:
                    print >>sys.stderr, "PiseWorkflow/_launch",methodid,": will submit"
                if self._submit(methodid) == "ok":
                    if self.verbose:
                        print >>sys.stderr, "PiseWorkflow/_launch",methodid,": returning from submitting the task, OK"
                    sys.exit(0)
                else:
                    if self.verbose:
                        print >>sys.stderr, "PiseWorkflow/_launch",methodid,": some error occurred when submitting the task"
                    sys.exit(1) # some error occurred
            else:
                # parent
                childpids.append([childpid, methodid])
                children += 1
                if self.verbose:
                    print >>sys.stderr, "PiseWorkflow/_launch",methodid,": parent=", children , childpids

        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_launch: status :"
            print >>sys.stderr, self
            print >>sys.stderr, "PiseWorkflow/_launch",methodids,": will consider children :",childpids
            print >>sys.stderr, "PiseWorkflow/_launch",methodids,": children , childpids: ", children , childpids
        # Here, we recursively process a list of method children

        for achild in childpids:
            os.wait() # wait until the child is terminated

            if self.verbose:
                print >>sys.stderr, "PiseWorkflow/_launch: child.tomethodids is : ",self.tasks[achild[1]].tomethodids()
                
            if self.status[achild[1]] == "error":
                if self.tasks[achild[1]].tomethodids()  != []:
                    for id in self.tasks[achild[1]]["tomethodids"]:
                        self.status[id] = "error"
                        self.status[id] = "broken pipe!"
            elif self.tasks[achild[1]].tomethodids()  != []:
                # we care for childs waiting: do not lauch !
                childlist = []
                for rank in self.tasks[achild[1]].tomethodids():
                    if self.verbose:
                        print >>sys.stderr, "PiseWorkflow/_launch",methodid,": child is ",rank,"status:",self.status[rank]
                    if self.status[rank] == "waiting":
                        pass
                    else:
                        childlist.append(rank)
                if self.verbose:
                    print >>sys.stderr, "PiseWorkflow/_launch",methodids,": will launch childlist:",childlist
                self._launch(childlist)
            else:
                self.level -= 1
                print >>sys.stderr, "PiseWorkflow/_launch",methodids,": completed!"
                return "ok"
        self.level -= 1
        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_launch",methodids,": completed!"
        return "ok"

    def _wait(self, rank):
        """
        possible status values are:
        declared, lauchned, waiting, running, done, error
        """
        self._statusread()

        if self.verbose:
            print >>sys.stderr, ">>>>>>>>>> PiseWorkflow/entering _wait for ",rank, "status:",self.status[rank]

        # the task is not even launched: we trigger its run
        # (made through recursive call backwards)
        ostatus = "ok"
        if self.status[rank] == "declared":
            if self.verbose:
                print >>sys.stderr, ">>>>>>>>>> PiseWorkflow/_wait for ",rank, "will wait for parents"
            if self.tasks[rank].ffrom() != []:
                # run the parents
                for parent in self.tasks[rank].ffrom():
                    if self.status[parent] == "error":
                        self.status[rank] = "error"
                        ostatus = "error"
                        break
                    elif self.status[parent] != "done":
                        if self.verbose:
                            print >>sys.stderr, "PiseWorkflow/_wait for ",rank, ": will wait_wait for",parent,"from ", rank
                        self.status[rank] = "waiting"
                        self._statusupdate(rank)
                        self._wait(parent)
                self.status[rank] = "declared"
                self._statusupdate(rank)
##                 self._statusread()
##                 if self.status[rank] == "declared":
##                     ostatus = self._launch([rank])
##             else:
##                 # run the task directly: todo
##                 ostatus =  self._launch([rank])
            if self.verbose:
                print >>sys.stderr, ">>>>>>>>>PiseWorkflow/_wait for ",rank, ": finished wait_wait for parents"
            ostatus =  self._launch([rank])
            
        # There was a problem
        elif self.status[rank] == "error":
            if self.verbose:
                print >>sys.stderr, ">>>>>> PiseWorkflow/_wait for ",rank, ": stopping wait with status:",self.status[rank]
            ostatus = "error"

        # It is running: we wait
	if ostatus == "error":
		pass
        else:
            while(self.status[rank] not in  ["done", "error"]):
                time.sleep(1)
                self._statusread()
            if self.verbose:
                print >>sys.stderr, ">>>>>> PiseWorkflow/_wait for ",rank, ": awaiking wait with status:",self.status[rank]
            if self.status[rank] == "error":
                ostatus = "error"
        if self.verbose:
            print >>sys.stderr, ">>>>>> PiseWorkflow/_wait for ",rank, ": exiting wait with task status:",self.status[rank], "wait exit status",ostatus
        return ostatus
            
    
    def _submit(self, rank, **args):
        """
        submit one job
        wait until it is finished
        """
        import time

        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_submit: ************** _submit: running task",rank
        
        appli = self.tasks[rank].method()
        self.status[rank] = "launched"
        self._statusupdate(rank)
        if self.verbose:
            print >>sys.stderr, self

        # return 1

        try:
            theJob = appli.submit()
            if self.verbose:
                print >>sys.stderr, "PiseWorkflow/_submit: ************** _submit: task ",rank,"jobid=", theJob.jobid()
	    self.tasks[rank].job(theJob.jobid())
            self._statusupdate(rank)
            if self.verbose:
                print >>sys.stderr, "PiseWorkflow/_submit: updated, will print"
                print >>sys.stderr, self
        except:
            if self.verbose:
                print >>sys.stderr, "PiseWorkflow/_submit: task ",rank,"========> Could not sumbit job!"
            self.status[rank] = "error"
            self.error[rank]  = "Could not sumbit job!"
            self._statusupdate(rank)
            return "error"

        theJobId = theJob.jobid()
        self.status[rank] = "running"
        self._statusupdate(rank)
        if self.verbose:
            print >>sys.stderr, self

        if theJob.error(): # some problem occurred starting the application
            if self.verbose:
                print >>sys.stderr, "PiseWorkflow/_submit: task ",rank,"========> some problem occurred starting the application task "
            self.status[rank] = "error"
            self.error[rank]  = theJob.error_message()
            if self.verbose:
                print >>sys.stderr, "PiseWorkflow/_submit: error_message=", theJob.error_message()
            self._statusupdate(rank)
            return "error"

        # wait for the application to complete
        if not theJob.terminated():
            theJob.results_type("url")
            while not theJob.terminated():
                time.sleep(self.interval)

        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_submit: **************  task ",rank," ========> The jobs has completed !"
        self.status[rank] = "done"
        self._statusupdate(rank)
        if self.verbose:
            print >>sys.stderr, self
            print >>sys.stderr, "PiseWorkflow/_submit: **************  task ",rank," ============> exiting for task ",rank
        
        del time
        return "ok"

    def _pipe(self, ffrom, tto, pipetype):
        """
        We pipe methods ffrom and tto, on a parameter of type pipetype
        """
        # return
        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_pipe: xxxxxxxxxxxxxxx _pipe ",ffrom,"==>",tto,"type:",pipetype
	piped_appli = self.tasks[tto].method()
	#pipetype = self.tasks[tto].pipetype()
	#??job = piped_appli['job']
	jobid = self.tasks[ffrom].job()
        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_pipe: xxxxxxxxxxxxxxx : ffrom jobid:", jobid
        if jobid == None:
            if self.verbose:
                print >>sys.stderr, "COULD NOT FIND jobid for task ",ffrom,"<<<<<<<<<<<<<<<<<<<<<<<<<<<<XXXXXXXXXXXXXXXX"
            sys.exit(0)
        try:
            job = PiseJob(jobid=jobid, submit=0, verbose=False)
        except:
            if self.verbose:
                print >>sys.stderr,  "COULD NOT FIND job for task ",ffrom,"<<<<<<<<<<<<<<<<<<<<<<<<<<<<XXXXXXXXXXXXXXXX"
            sys.exit(0)
            
	params = piped_appli.pipein(pipetype)
        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_pipe: xxxxxxxxxxxxxxx : params=", params
	pipefile = job.lookup_piped_file(pipetype)
        if self.verbose:
            print >>sys.stderr, "PiseWorkflow/_pipe: xxxxxxxxxxxxxxx  pipefile:",pipefile
	if len(params) > 0:
	    piped_appli.param(name=params[0], value=job.fh(pipefile))


    def __str__(self):
        """
        Some visualisation of the tasks.
        """
        html = False
        # 1. We read the content
        self._statusread()
        
##         f = open(self.dump, "r")
##         fcntl.flock(f.fileno(), fcntl.LOCK_EX)
##         u = cPickle.Unpickler(f)
##         odefs = u.load()
        
##         fcntl.flock(f.fileno(), fcntl.LOCK_UN)
##         f.close()

	s = "======================\n"
        s += "Complete worklow tasks status:\n\n"
        # 2. We print the information
        for rank in range(0,len(self.tasks)):
            if not html:
                s += self.tasks[rank]._print(self.status[rank],self.error[rank]) + "\n"
	s += "======================\n"
	return s

	
