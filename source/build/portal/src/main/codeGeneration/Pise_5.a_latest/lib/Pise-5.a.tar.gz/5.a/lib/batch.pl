
## Get batch queue for job

# Local jobs are directed to local (webloc) queue.
# Small jobs are directed to special (small) queue.
# Big jobs are directed to special (long) queue.
# Parallel jobs are directed to special (noonan) queue.
# All others jobs are directed to default (webrem) queue.

my @small = qw ( genscan toppred efetch golden drawtree drawgram tacg
		 readseq melting psort2 tacg fastrna boxshade sigcleave 
		 sirna stretcher remap codonw html4blast eprimer3 cds pepwindow 
		 fuzznuc revseq pftools dotmatcher cpgplot seqsblast
		 predator plotorf unroot seqgen nnssp tfscan pepstats loadseq
		 protal2dna wordcount helixturnhelix tmap equicktandem
		 filtersites boxshade mreps restrict geecee antigenic iep
		 prose dan pepcoil dottup fmtseq getorf transeq cpgreport 
		 mview_alig gibbs lindna dssp sreformat cusp showseq showorf
		 pepinfo octanol pepwheel prettyplot saps scan_for_matches 
		 merger grailclnt cirdna fuzzpro fuzznuc trnascan chaos 
		 compseq bl2seq matcher silent wordmatch);
my @long = qw ( fastdnaml );
my @para = qw ( blastpar clustalwpar fastdnamlpar psiblastpar megablastpar
                hmmpar hmmsearchpar hmmpfampar );

sub batch_queue {
  my ($local, $command) = @_;
  
  ## Parallel jobs
  foreach (@para) {
    if ($command ne $_) { next; }
    return 'noonan'; }

  ## Local users
  if ($local eq 'local') {
    return 'webloc'; }

  ## Small/Rapid jobs
  foreach (@small) {
    if ($command ne $_) { next; }
    return 'small'; }
  
  ## Big/Long jobs
  foreach (@long) {
    if ($command ne $_) { next; }
    return 'long'; }

  return 'webrem'; }


sub check_queue_busy {
  my $queue = $_[0];

  if ($queue eq 'webloc') {
      return 0;
  }
  my $date = `date +"%d %b %Y %H:%M"` ;
  chop($date);
  my $me = basename $0;

  open(QSTAT, 'qstat -Q|') || die "pb opening qstat: $!" ; 
  while (<QSTAT>) {
      my ($q, $max, $jobs, @r) = split(/\s+/, $_);
      if ($q eq $queue) {
	  if ($jobs >= ($max + 5)) {
	      print STDERR "Pise (batch.pl) $me [$date]: queue: $queue q: $q max: $max jobs: $jobs\n";
	      return 1;
	  } else {
	      return 0;
	  }
      }
  }
  close(QSTAT);
  return 0;
}


1;

