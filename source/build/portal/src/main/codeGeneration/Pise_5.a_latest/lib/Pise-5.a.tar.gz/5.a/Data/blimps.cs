ER	2
SE	block
SQ	/local/private/sis/letondal/Work/Intf/Pise/2.b/Data/blastp.data
DB	/local/gensoft/lib/blimps/db/blocks.dat
CO	2
GE	3
NU	0
OU	blimps.results
