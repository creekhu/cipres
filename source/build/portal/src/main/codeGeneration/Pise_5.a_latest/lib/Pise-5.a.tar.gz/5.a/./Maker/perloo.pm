# accessors / modifiers

sub command {
    my $self = shift;
    return $self->{COMMAND} ;
}

sub version {
    my $self = shift;
    return $self->{VERSION} ;
}

sub title {
    my $self = shift;
    if (@_) { 	$self->{TITLE} = shift ;    }
    return $self->{TITLE} ;
}

sub description {
    my $self = shift;
    if (@_) { 	$self->{DESCRIPTION} = shift ;    }
    return $self->{DESCRIPTION} ;
}

sub opt_email {
    my $self = shift;
    return $self->{OPT_EMAIL} ;
}

sub categories {
    my $self = shift;
    if (@_) { 	$self->{CATEGORIES} = shift ;    }
    return $self->{CATEGORIES} ;
}

sub authors {
    my $self = shift;
    if (@_) { 	$self->{AUTHORS} = shift ;    }
    return $self->{AUTHORS} ;
}

sub doclink {
    my $self = shift;
    if (@_) { 	$self->{DOCLINK} = shift ;    }
    return $self->{DOCLINK} ;
}

sub reference {
    my $self = shift;
    return @{ $self->{REFERENCE} };
}

sub seqinput {
    my $self = shift;
    if (@_) { 	$self->{SEQINPUT} = shift ;    }
    return $self->{SEQINPUT} ;
}

sub seqtype {
    my $self = shift;
    if (@_) { 	$self->{SEQTYPE} = shift ;    }
    return $self->{SEQTYPE} ;
}

sub top_parameters {
    my $self = shift;
    return @{ $self->{TOP_PARAMETERS} };
}

sub parameters_order {
    my $self = shift;
    return @{ $self->{PARAMETERS_ORDER} };
}

sub by_group_parameters {
    my $self = shift;
    return @{ $self->{BY_GROUP_PARAMETERS} };
}

sub type {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{TYPE}{$param} = shift ;    }
        return  $self->{TYPE}{$param};
    } else {
        return  %{ $self->{TYPE} };
    }
}

sub format {
    my $self = shift;
    if (@_) { 
        my $param = shift;
        if (@_) {
            my $language = shift;
	    if (@_) { 	$self->{FORMAT}{$param}{$language} = shift ;    }
            return  $self->{FORMAT}{$param}{$language};
        } else {
	    if (defined $self->{FORMAT}{$param}) {
		return  %{ $self->{FORMAT}{$param} };
	    } else {
		return $self->{FORMAT}{$param};
	    }
        }
    } else {
        return  %{ $self->{FORMAT} };
    }
}

sub filenames {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{FILENAMES}{$param} = shift ;    }
        return  $self->{FILENAMES}{$param};
    } else {
        return  %{ $self->{FILENAMES} };
    }
}

sub seqfmt {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{SEQFMT}{$param} = shift ;    }
        return  @{ $self->{SEQFMT}{$param} };
    } else {
        return  %{ $self->{SEQFMT} };
    }
}

sub size {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{SIZE}{$param} = shift ;    }
        return  $self->{SIZE}{$param};
    } else {
        return  %{ $self->{SIZE} };
    }
}

sub group {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{GROUP}{$param} = shift ;    }
        return  $self->{GROUP}{$param};
    } else {
        return  %{ $self->{GROUP} };
    }
}

sub ishidden {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{ISHIDDEN}{$param} = shift ;    }
        return  $self->{ISHIDDEN}{$param};
    } else {
        return  %{ $self->{ISHIDDEN} };
    }
}

sub iscommand {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{ISCOMMAND}{$param} = shift ;    }
        return  $self->{ISCOMMAND}{$param};
    } else {
        return  %{ $self->{ISCOMMAND} };
    }
}

sub ismandatory {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{ISMANDATORY}{$param} = shift ;    }
        return  $self->{ISMANDATORY}{$param};
    } else {
        return  %{ $self->{ISMANDATORY} };
    }
}

sub isstandout {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{ISSTANDOUT}{$param} = shift ;    }
        return  $self->{ISSTANDOUT}{$param};
    } else {
        return  %{ $self->{ISSTANDOUT} };
    }
}

sub _interface_standout {
    my $self = shift;
    if (@_) { 	$self->{_INTERFACE_STANDOUT} = shift ;    }
    return  $self->{_INTERFACE_STANDOUT};
}

sub _standout_file {
    my $self = shift;
    if (@_) { 	$self->{_STANDOUT_FILE} = shift ;    }
    return  $self->{_STANDOUT_FILE};
}

sub prompt {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{PROMPT}{$param} = shift ;    }
        return  $self->{PROMPT}{$param};
    } else {
        return  %{ $self->{PROMPT} };
    }
}

sub vlist {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{VLIST}{$param} = shift ;    }
        return  @{ $self->{VLIST}{$param} };
    } else {
        return  %{ $self->{VLIST} };
    }
}

sub flist {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 
	    my $value = shift;
	    if (@_) { 	$self->{FLIST}{$param}{$value} = shift ;    }
	    return $self->{FLIST}{$param}{$value};
	} else {
	    if (defined $self->{FLIST}{$param}) {
		return  %{ $self->{FLIST}{$param} };
	    } else {
		return  $self->{FLIST}{$param} ;
	    }
	}
    } else {
        return  %{ $self->{FLIST} };
    }
}

sub separator {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{SEPARATOR}{$param} = shift ;    }
        return  $self->{SEPARATOR}{$param};
    } else {
        return  %{ $self->{SEPARATOR} };
    }
}

sub vdef {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{VDEF}{$param} = shift ;    }
	# may be a list (List type parameters)
	# must be casted by user
	return $self->{VDEF}{$param};
    } else {
        return  %{ $self->{VDEF} };
    }
}

sub precond {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 
            my $language = shift;
	    if (@_) { 	$self->{PRECOND}{$param}{$language} = shift ;    }
            return  $self->{PRECOND}{$param}{$language};
	} else {
	    if (defined $self->{PRECOND}{$param}) {
		return  %{ $self->{PRECOND}{$param} };
	    } else {
		return  $self->{PRECOND}{$param} ;
	    }
	}
    } else {
        return  %{ $self->{PRECOND} };
    }
}

sub ctrl {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 
	    my $language = shift;
	    if (@_) { 
		my $test = shift;
		if (@_) { 	
		    $self->{CTRL}{$param}{$language}{$test} = shift ; 
		}
		return $self->{CTRL}{$param}{$language}{$test};
	    } else {
		if (defined $self->{CTRL}{$param}{$language}) {
		    return %{ $self->{CTRL}{$param}{$language} };
		} else {
		    return $self->{CTRL}{$param}{$language};
		}
	    }
	} else {
	    if (defined $self->{CTRL}{$param}) {
		return %{ $self->{CTRL}{$param} };
	    } else {
		return $self->{CTRL}{$param};
	    }
	}
    } else {
        return  %{ $self->{CTRL} };
    }
}

sub pipeout {
    my $self = shift;
    if (@_) { 
        my $param = shift;
        if (@_) {
            my $test = shift;
	    if (@_) { 	$self->{PIPEOUT}{$param}{$test} = shift ;    }
            return  $self->{PIPEOUT}{$param}{$test} ;
	} else {
	    if (defined $self->{PIPEOUT}{$param}) {
		return  %{ $self->{PIPEOUT}{$param} };
	    } else {
		return  $self->{PIPEOUT}{$param};
	    }
	}
    } else {
        return  %{ $self->{PIPEOUT} };
    }
}

sub withpipeout {
    my $self = shift;
    if (@_) { 
        my $param = shift;
        if (@_) {
            my $test = shift;
	    if (@_) { 	$self->{WITHPIPEOUT}{$param}{$test} = shift ;    }
            return  @{ $self->{WITHPIPEOUT}{$param}{$test} };
	} else {
	    if (defined $self->{WITHPIPEOUT}{$param}) {
		return  %{ $self->{WITHPIPEOUT}{$param} };
	    } else {
		return  $self->{WITHPIPEOUT}{$param} ;
	    }
	}
    } else {
        return  %{ $self->{WITHPIPEOUT} };
    }
}

sub pipein {
    my $self = shift;
    if (@_) { 
        my $param = shift;
        if (@_) {
            my $type = shift;
	    if (@_) { 	$self->{PIPEIN}{$param}{$type} = shift ;    }
            return   $self->{PIPEIN}{$param}{$type} ;
	} else {
	    if (defined $self->{PIPEIN}{$param}) {
		return  %{ $self->{PIPEIN}{$param} };
	    } else {
		return  $self->{PIPEIN}{$param};
	    }
	}
    } else {
        return  %{ $self->{PIPEIN} };
    }
}

sub withpipein {
    my $self = shift;
    if (@_) { 
        my $param = shift;
        if (@_) {
            my $type = shift;
	    if (@_) { 	$self->{WITHPIPEIN}{$param}{$type} = shift ;    }
            return  @{ $self->{WITHPIPEIN}{$param}{$type} };
	} else {
	    if (defined $self->{WITHPIPEIN}{$param}) {
		return  %{ $self->{WITHPIPEIN}{$param} };
	    } else {
		return  $self->{WITHPIPEIN}{$param} ;
	    }
	}
    } else {
        return  %{ $self->{WITHPIPEIN} };
    }
}

sub isclean {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{ISCLEAN}{$param} = shift ;    }
        return  $self->{ISCLEAN}{$param};
    } else {
        return  %{ $self->{ISCLEAN} };
    }
}

sub issimple {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{ISSIMPLE}{$param} = shift ;    }
        return  $self->{ISSIMPLE}{$param};
    } else {
        return  %{ $self->{ISSIMPLE} };
    }
}

sub paramfile {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{PARAMFILE}{$param} = shift ;    }
        return  $self->{PARAMFILE}{$param};
    } else {
        return  %{ $self->{PARAMFILE} };
    }
}

sub comment {
    my $self = shift;
    if (@_) { 
        my $param = shift;
        if (@_) {       
	    $self->{COMMENT}{$param} = [ @{$_[0]} ] ;    
	}
	if (defined $self->{COMMENT}{$param} ) {
            return  @{ $self->{COMMENT}{$param} };
	} else {
	    return $self->{COMMENT}{$param}
	}
    } else {
        return  %{ $self->{COMMENT} };
    }
}


sub scalemin {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{SCALEMIN}{$param} = shift ;    }
        return  $self->{SCALEMIN}{$param};
    } else {
        return  %{ $self->{SCALEMIN} };
    }
}

sub scalemax {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{SCALEMAX}{$param} = shift ;    }
        return  $self->{SCALEMAX}{$param};
    } else {
        return  %{ $self->{SCALEMAX} };
    }
}

sub scaleinc {
    my $self = shift;
    if (@_) { 
        my $param = shift;
	if (@_) { 	$self->{SCALEINC}{$param} = shift ;    }
        return  $self->{SCALEINC}{$param};
    } else {
        return  %{ $self->{SCALEINC} };
    }
}


1;

