
from Bio.Seq import Seq
from Pise import PiseFactory
from Bio.Blast import NCBIStandalone
from Bio import Alphabet

seq = Seq('MASVQLQNVTKAWGEVVVSKDINLDIHEGEFVVFVGPSGCGKSTLLRMIAGLETITSGDLFIGEKRMNDTPPAERGVGMVFQSYALYPHLSVAENMSFGLKPAGAKKEVINQRVNQVAEVLQLAHLLDRKPKALSGGQRQRVAIGRTLVAEPSVFLLDEPLSNLDAALRVQMRIEISRLHKRLGRTMIYVTHDQVEAMTLADKIVVLDAGRVAQVGKPLELYHYPADRFVAGFIGSPKMNFLPVKVTATAIDQVQVELPMPNRQQVWLPVESRDVQVGANMSLGIRPEHLLPSDIADVILEGEVQVVEQLGNETQIHIQIPSIRQNLVYRQNDVVLVEEGATFAIGLPPERCHLFREDGTACRRLHKEPGV',
          alphabet=Alphabet.ProteinAlphabet())

factory = PiseFactory(email='letondal@pasteur.fr')
blast2 = factory.program("blast2",protein_db="swissprot",blast2='blastp')
blast2.verbose(1)
j=blast2.run(query=seq)
if j.error():
    print "Error: " + j.error_message()
else:
    print j.jobid()

    b_parser = NCBIStandalone.BlastParser()
    blast_out = j.fh('blast2.txt')
    b_record = b_parser.parse(blast_out)
    E_VALUE_THRESH = 0.04
    for alignment in b_record.alignments:
        for hsp in alignment.hsps:
            if hsp.expect < E_VALUE_THRESH:
                print '****Alignment****'
                print 'sequence:', alignment.title
                print 'length:', alignment.length
                print 'e value:', hsp.expect
                print hsp.query[0:75] + '...'
                print hsp.match[0:75] + '...'
                print hsp.sbjct[0:75] + '...'

