#
# Generate the code for a bioperl module
#

package Maker;

my $command=$ARGV[0];

my $perldef = "/local/gensoft/lib/Pise/5.a/PerlDef/$command.pm";
require $perldef;

my $defs = $command->new;
my $title = "Bioperl class for:\n\n\t";
$title .= $defs->title . "\t" . $defs->description;
if ($defs->authors) {
    $title .= " (" . $defs->authors . ")";
}
if (defined $defs->reference) {
    $title .= "\n\n\tReferences:\n";
    foreach my $ref ($defs->reference) {
	$title .= "\n\t\t" . $ref . "\n"; 
    }
}

print "
=head1 NAME

Pise::$command - ";
print $defs->title, " ", $defs->description;
print " 

=head1 SYNOPSIS

=head1 DESCRIPTION

Pise::$command

      $title

      Parameters:

";

foreach my $param ($defs->parameters_order) {
    my $type = $defs->type($param);
    my $prompt = $defs->prompt($param);
    my %pipein = $defs->pipein($param);
    my %pipeout = $defs->pipeout($param);

    print "\n\t\t$param ($type)\n";
    if (defined $prompt && $prompt ne "") {
	print "\t\t\t$prompt\n";
    }
    
    foreach my $in (keys %pipein) {
	if ($in) {
	    print "\t\t\tpipe: $in\n";
	}
    }
    foreach my $out (keys %pipeout) {
	if ($out) {
	    print "\t\t\tpipe: ",$pipeout{$out},"\n";
	}
    }
}


print "
=cut

#'
package Pise::$command;

use vars qw(\@ISA);
use strict;
use Pise;

\@ISA = qw(Pise);

=head2 new

 Title   : new()
 Usage   : my \$$command = Pise::$command->new(\$cgi, \$email, \@params);
 Function: Creates a Pise::$command object.
 Example :
 Returns : An instance of Pise::$command.

=cut

sub new {
    my (\$class, \$cgi, \$email, \@params) = \@_;
    my \$self = \$class->SUPER::new(\$cgi, \$email);

";

print "# -- begin of definitions extracted from $perldef\n\n";
open(DEF,$perldef) || die "cannot open $perldef: $!";
my $print = -1;
my $param_list = 0;
my $param;
my $line;
my $prompt;
while (<DEF>) {
    $print = 1 if (/\{COMMAND\}/ && $print == -1);
    $print = 0 if (/bless/);
    $param_list++ if ($param_list == 1);
    $param_list = 1 if (/PARAMETERS_ORDER/);
    $param_list = 3 if ($param_list == 2 && /;/);
    
    if ($param_list == 2) {
	$line = $_;
	$param = $line;
	chomp($param);
	$param =~ s/\"(.+)\",/$1/;
	$param =~ s/\s+//g;
	$prompt = $defs->prompt($param);
	#print STDERR "$param_list param: $param ($prompt)\n";
	if ($prompt) {
	    $line =~ s/\",/\", \t\# $prompt/;
	}
	print $line if $print == 1;
    } else {
	print if $print == 1;
    }
    #print STDERR "$print $_";
}
close DEF;
print "# -- end of definitions extracted from $perldef\n\n";

print "

    \$self->_init_params(\@params);

    return \$self;
}



1; # Needed to keep compiler happy

";

