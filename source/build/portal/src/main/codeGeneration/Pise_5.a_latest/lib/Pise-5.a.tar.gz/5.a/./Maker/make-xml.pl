use lib "/local/gensoft/inst/Pise/4.b/PerlDef";

package Maker;

$command=$ARGV[0];
$VERSION=$ENV{'VERSION'};
$PISEDIR=($ENV{'PISEDIR'})? $ENV{'PISEDIR'} : "/local/gensoft/inst/Pise/$VERSION";
$PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : $PISEDIR . '/PerlDef';
eval ("use $command;");
$defs = $command->new;
print_headers();
do_parameters ('top',-1,$defs->top_parameters);
print_footers();

sub print_headers {
    my $title = $defs->title;
    print "<?xml version=\"1.0\" encoding=\"ISO-8859-1\" ?>\n";
#bogue psgml    print "<!DOCTYPE pise SYSTEM \"http://www.pasteur.fr/~letondal/XML/pise.dtd\">\n";
    print "<!DOCTYPE pise SYSTEM \"$PISEDIR/Parser/pise.dtd\">\n";
    print "\n<pise>\n";
    print "\n<head>$title</head>\n\n";
    print "\n<command>$command</command>\n\n";
    print "<parameters>\n\n";
}
sub print_footers {
    print "\n</parameters>\n";
    print "</pise>\n";
}

sub do_parameters {
    my ($paragraph, $indent,@parameters_list) = @_ ;
    my $param;
    my $group;
    my $type;
    my $tab;
    for my $i (0..$indent) {
	$tab .= "\t";
    }
    foreach $param (@parameters_list) {
	$type=$defs->type($param);
	print "$tab<parameter type=\"$type\">\n";
	if ($type eq "Paragraph") {
	    print "$tab<paragraph>\n";
	    print "$tab<name>$param</name>\n";
	    do_precond($param,$indent);
	    if (defined $defs->group($param)) {
		$group = $defs->group($param);
		print "$tab<group>$group</group>\n";
	    }
	    if (defined $defs->format($param)) {
		print "$tab<format>\n";
		my %languages = $defs->format($param);
		foreach my $language (keys %languages) {
		    print "$tab\t<language>$language</language>\n";
		    $code = $defs->format($param,$language);
		    $code =~ s/\&/\&amp;/g;
		    $code =~ s/</&lt;/g;
		    $code =~ s/>/&gt;/g;
		    print "$tab\t<code>$code</code>\n";
		}
		print "$tab\t</format>\n";
	    }
	    print "$tab<parameters>\n\n";
	    do_parameters($param,$indent+1,$defs->vlist($param));
	    print "$tab</parameters>\n";
	    print "$tab</paragraph>\n\n";
	} else {
	    print "$tab<name>$param</name>\n";
	    print "$tab<attributes>\n\n";
	    do_attributes($param,$indent);
	    print "\n$tab</attributes>\n";
	}
	print "$tab</parameter>\n\n";
    }
}

sub do_precond {
    my $param = $_[0];
    my $indent = $_[1];
    my $code;
    my $tab;
    for my $i (0..$indent) {
	$tab .= "\t";
    }
    return if (! defined $defs->precond($param));
    return if ($defs->precond($param,'perl') eq '1');
    print "$tab<precond>\n";
    my %languages = $defs->precond($param);
    foreach my $language (keys %languages) {
	print "$tab\t<language>$language</language>\n";
	$code = $defs->precond($param,$language);
	$code =~ s/\&/\&amp;/g;
	$code =~ s/</&lt;/g;
	$code =~ s/>/&gt;/g;
	print "$tab\t<code>$code</code>\n";
    }
    print "$tab</precond>\n";

}

sub do_attributes {
    my $param = $_[0];
    my $indent = $_[1];
    my %languages;
    my $language;
    my $type;
    my %ctrls;
    my $message;
    my %messages;
    my %test;
    my %pipeins;
    my %pipeouts;
    my $j;
    my @list;
    my $tab;
    for my $i (0..$indent+1) {
	$tab .= "\t";
    }
    $type=$defs->type($param);

    if (defined $defs->prompt($param)) {
	print "$tab<attribute>\n";
	my $prompt = $defs->prompt($param);
	$prompt =~ s/\&/\&amp;/g;
	$prompt =~ s/</&lt;/g;
	$prompt =~ s/>/&gt;/g;
	print "$tab<prompt>$prompt</prompt>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->ismandatory($param)) {
	print "$tab<attribute>\n";
	print "$tab<ismandatory>",$defs->ismandatory($param),"</ismandatory>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->format($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<format>\n";
	%languages = $defs->format($param);
	foreach $language (keys %languages) {
	    print "$tab\t\t<language>$language</language>\n";
	    $code = $defs->format($param,$language);
	    $code =~ s/\&/\&amp;/g;
	    $code =~ s/</&lt;/g;
	    $code =~ s/>/&gt;/g;
	    print "$tab\t\t<code>$code</code>\n";
	}
	print "$tab\t</format>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->vdef($param)) {
	print "$tab<attribute>\n";
	if ($type eq "List") {
	    print "$tab\t<vdef>\n";
	    foreach my $value (@{ $defs->vdef($param) }) {
		print "$tab\t\t<value>$value</value>\n";
	    }
	    print "\n$tab\t</vdef>\n";
	} else {
	    print "$tab\t<vdef>",,$defs->vdef($param),"</vdef>\n";
	}
	print "$tab</attribute>\n";
    }
    if (defined $defs->group($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<group>",$defs->group($param),"</group>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->vlist($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<vlist>\n";
	$j = 0;
	@list = $defs->vlist($param);
	while ($j <= $#list) {
	    if (!( $j % 2)) {
		print "$tab\t\t<value>$list[$j]</value>\n";
	    } else {
		print "$tab\t\t<label>$list[$j]</label>\n";
	    }
	    $j++;
	}
	print "$tab\t</vlist>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->flist($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<flist>\n";
	$j = 0;
	@list = $defs->flist($param);
	while ($j <= $#list) {
	    if (!( $j % 2)) {
		print "$tab\t\t<value>$list[$j]</value>\n";
	    } else {
		$code = $list[$j];
		$code =~ s/\&/\&amp;/g;
		$code =~ s/</&lt;/g;
		$code =~ s/>/&gt;/g;
		print "$tab\t\t<code>$code</code>\n";
	    }
	    $j++;
	}
	print "$tab\t</flist>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->ishidden($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<ishidden>",$defs->ishidden($param),"</ishidden>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->iscommand($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<iscommand>",$defs->iscommand($param),"</iscommand>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->comment($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<comment>\n";
	foreach my $value ($defs->comment($param)) {
	    $value =~ s/\&/\&amp;/g;
	    $value =~ s/</&lt;/g;
	    $value =~ s/>/&gt;/g;
	    print "$tab\t\t<value>$value</value>\n";
	}
	print "$tab\t</comment>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->seqfmt($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<seqfmt>\n";
	foreach my $value ($defs->seqfmt($param)) {
	    print "$tab\t\t<value>$value</value>\n";
	}
	print "$tab\t</seqfmt>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->ctrl($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<ctrls>\n";
	%ctrls = $defs->ctrl($param);
	foreach my $ctrl (keys %ctrls) {
	    %languages = $defs->ctrl($param);
	    foreach $language (keys %languages) {
		%tests = $defs->ctrl($param,$language);
		foreach my $test (keys %tests) {
		    $message = $defs->ctrl($param,$language,$test);
		    $tests_by_message{$message}{$language} = $test;
		}
	    }
	    print "$tab\t\t<ctrl>\n";
	    foreach $message (keys %tests_by_message) {
		print "$tab\t\t<message>$message</message>\n";
		foreach $language (keys %{ $tests_by_message{$message}} ) {
		    print "$tab\t\t\t<language>$language</language>\n";
		    $code = $tests_by_message{$message}{$language};
		    $code =~ s/\&/\&amp;/g;
		    $code =~ s/</&lt;/g;
		    $code =~ s/>/&gt;/g;
		    print "$tab\t\t\t<code>$code</code>\n";
		}
	    }
	    print "$tab\t\t</ctrl>\n";
	}
	print "$tab\t</ctrls>\n";
	print "$tab</attribute>\n";
    }
    do_precond($param,$indent);
    if (defined $defs->isstandout($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<isstandout>",$defs->isstandout($param),"</isstandout>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->issimple($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<issimple>",$defs->issimple($param),"</issimple>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->isclean($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<isclean>",$defs->isclean($param),"</isclean>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->paramfile($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<paramfile>",$defs->paramfile($param),"</paramfile>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->filenames($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<filenames>",$defs->filenames($param),"</filenames>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->scalemin($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<scalemin>",$defs->scalemin($param),"</scalemin>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->scalemax($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<scalemax>",$defs->scalemax($param),"</scalemax>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->scaleinc($param)) {
	print "$tab<attribute>\n";
	print "<scaleinc>",$defs->scaleinc($param),"</scaleinc>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->separator($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<separator>'",$defs->separator($param),"'</separator>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->size($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<size>",$defs->size($param),"</size>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->pipein($param) || defined $defs->pipeout($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<pipe>\n";
	%pipeins = $defs->pipein($param);
	foreach $pipetype (keys %pipeins) {
	    print "$tab\t\t<pipetype>$pipetype</pipetype>\n";
	    $test = $defs->pipein($param,$pipetype);
	    print "$tab\t\t\t<language>perl</language>\n";
	    $code = $test;
	    $code =~ s/\&/\&amp;/g;
	    $code =~ s/</&lt;/g;
	    $code =~ s/>/&gt;/g;
	    print "$tab\t\t\t<code>$code</code>\n";
	}
	%pipeouts = $defs->pipeout($param);
	foreach $test (keys %pipeouts) {
	    $pipetype=$pipeouts{$test};
	    print "$tab\t\t<pipetype>$pipetype</pipetype>\n";
	    print "$tab\t\t\t<language>perl</language>\n";
	    $code = $test;
	    $code =~ s/\&/\&amp;/g;
	    $code =~ s/</&lt;/g;
	    $code =~ s/>/&gt;/g;
	    print "$tab\t\t\t<code>$code</code>\n";
	}
	print "$tab\t</pipe>\n";
	print "$tab</attribute>\n";
    }
    if (defined $defs->withpipein($param) || defined $defs->withpipeout($param)) {
	print "$tab<attribute>\n";
	print "$tab\t<withpipe>\n";
	%withpipeins = $defs->withpipein($param);
	foreach $pipetype (keys %withpipeins) {
	    print "$tab\t\t<pipetype>$pipetype</pipetype>\n";
	    foreach my $parametername ($defs->withpipein($param,$pipetype)) {
		print "$tab\t\t\t<parametername>$parametername</parametername>\n";
	    }
	}
	%withpipeouts = $defs->withpipeout($param);
	foreach $pipetype (keys %withpipeouts) {
	    print "$tab\t\t<pipetype>$pipetype</pipetype>\n";
	    foreach my $parametername ($defs->withpipeout($param,$pipetype)) {
		print "$tab\t\t\t<parametername>$parametername</parametername>\n";
	    }
	}
	print "$tab\t</withpipe>\n";
	print "$tab</attribute>\n";
    }
}

1;
