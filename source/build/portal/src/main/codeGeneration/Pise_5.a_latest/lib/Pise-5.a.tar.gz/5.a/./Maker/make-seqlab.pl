#
# seqlab extension menu item generator
#
# differences:
# - no paramfiles
# - "abstract" command line (generated without entered values)
#  pb : with blanks separating each qualifier -> pb for grouping 
#      several parameters in one string
#  other pb : size limitation :-( 
# - outfiles are mono-typed in Pise :-(
#   - Results filenames must be more precise
# - integer+float = range with min, max and inc
# - no pull-down menus in seqlab ?
# - no standard output (OutFile) parameters (this is already managed)
# - precond -> rules (postcond) + sqinfile

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";
 

package Maker;

$VERSION = $ENV{'VERSION'} ;
$command=$ARGV[0];
$date = `date +"%d %b %Y %H:%M"` ;
chop($date);
$PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : "/local/gensoft/lib/Pise/5.a/PerlDef";
$PISEDIR=($ENV{'PISEDIR'})? $ENV{'PISEDIR'} : "/local/gensoft/lib/Pise";
require "$PISEDIR/lib/convseq.pl";

eval ("use $command;");

$defs = $command->new;

my $title = $defs->title;


#==========================================================
# definitions
#==========================================================

%seqlab_name = (
		"Integer" => "Range",
		"Float" => "Range",
		"Switch" => "Bool",
		"String" => "Text",
		"Sequence" => "",
		"Excl" => "Radio",
		"List" => "Menu",
		"InFile" => "File",
		"OutFile" => "TextFile",
		"Paragraph" => "Label",
		"False" => "-",
		"True" => "+",
		);

#==========================================================
# SeqLab global section
#==========================================================

print "
EXTERNAL
";

my $seqtype=$defs->seqtype;
my $seqinput=$defs->seqinput;
if ($seqtype ne "0") {
    print "
TYPE $seqtype
INPUT $seqinput
";
}


&do_param_id;
&do_postcond;

my $convseq = &build_convseq;
my $exe = &build_command;

print "EXE $convseq $exe\n";

if (defined %sqinfile) {
    print "\nSqInfile *\n";
    foreach $key (keys %sqinfile) {
	print "\t$key = $sqinfile{$key}\n";
    }
    print "End\n\n";
}

@main_parameters = &simple_parameters($command);
foreach $p ( @{ &mandatory_parameters($command) } ) {
    unless (grep ( { $_ eq $p } @main_parameters )) {
	push (@main_parameters, $p);
    }
}

&do_parameters ('main',@main_parameters );
&do_parameters ('optional',  $defs->top_parameters );


#==========================================================
# utilities
#==========================================================


# return the list of parameters with attribute simple = True
sub simple_parameters {
    my $command = $_[0] ;
    my @plist;

    for $p ($defs->parameters_order) {
       if ($defs->issimple($p)) {
	   push (@plist, $p);
       } 
    }
    print STDERR "simple: ", "@plist", "\n";
    return @plist;
}

# return the list of parameters with attribute mandatory = True
sub mandatory_parameters {
    my $command = $_[0] ;
    my @plist;

    for $p ($defs->parameters_order) {
       if ($defs->ismandatory($p)) {
	   push (@plist, $p);
       } 
    }
    print STDERR "mandatory: ", "@plist", "\n";
    return @plist;
}

sub do_param_id {
    my $param;
    my $id = 0;

    foreach $param ( $defs->parameters_order ) {
	$id++;
	$id{$param} = $id;
    }
}

sub build_command {
    my $param;
    my $n;
    my $actual_arg;
    my $format;
    my $convseqname;

    my @parameters_list = 
	map {$defs->type($_) ne 'Paragraph' ? $_:()} $defs->by_group_parameters ;

    @parameters_list =
	map {$defs->type($_) ne 'Results' ? $_:()}
             @parameters_list;

    @parameters_list =
	map {$defs->precond($_, 'seqlab') eq '! seqlab' ? () : $_ }
             @parameters_list;

    @parameters_list =
	map {$defs->type($_) eq "OutFile" && $defs->isstandout($_) ? () : $_ }
             @parameters_list;

    $n = 1;
    for $i (0 .. $#parameters_list) {

	$param = $parameters_list[$i];
	$format = $defs->format($param,'seqlab');
        if ( $defs->type($param) eq "Sequence" ) {
	    if (defined $convseqname{$param}) {
		$convseqname = $convseqname{$param};
		$actual_arg = $format;
		if ($format =~ /value/) {
		    $actual_arg =~ s/value/$convseqname/g;
		}
		if ($format =~ /name/) {
		    $actual_arg =~ s/name/$param/g;
		}
		$actual_arg =~ s/\$param/$convseqname/g;
	    } else {
		if ($format =~ /value/) {
		    ($actual_arg = $format) =~ s/value/SQ$n/g ;
		} else {
		    ($actual_arg = $format) =~ s/\$param/SQ$n/g ;
		}
	    }
# print STDERR "param=$param, format=$format, convseqname=$convseqname, actual_arg=$actual_arg\n";
	    $parameters_list[$i] = $actual_arg;
            $n++;
        } elsif ($defs->iscommand($param) && ! $format) {
	    $parameters_list[$i] = $command;
        } elsif ($defs->ishidden($param) &&
            ! (defined $defs->precond($param,'seqlab'))) {
            $parameters_list[$i] = $format;
        } else { 
#	    print STDERR "id ", $param, " : ", $id{$param}, "\n";
	    $parameters_list[$i] = '$' . $id{$param};   
        } 
    } 

    return join(" ",@parameters_list);
}

sub do_parameters {
    my ($paragraph, @list) = @_ ;
    print STDERR "doing ", "@list", "\n";
    
    if ($paragraph eq 'main') {
print "
Main {
   Label 
       prompt = TEST VERSION -- $title
   End
   Blank

";
    }

    if ($paragraph eq 'optional') {
print "
Optional {

";
    }

    foreach $p ( @list ) {


       if (  $defs->type($p) eq "Paragraph" ) {
	  $prompt=$defs->prompt($p);

          print "
   Line
   Label 
       prompt = $prompt
   End
   Blank
";
	  &do_parameters($p, $defs->vlist($p) );

       } else {
          if  ( $paragraph eq 'main' ) {
             &print_one_param($paragraph,$p);
	  } elsif (! $defs->issimple($p) ) {
             &print_one_param($paragraph,$p);
          }
       }
    }

    if ($paragraph eq 'main' || $paragraph eq 'optional') {
	print "
}
";
    }

}


sub print_one_param {
    my $paragraph = $_[0];
    my $param = $_[1];
    my $precond;
    my $zeros;
    my $l;
    my $n;

    my $type=$defs->type($param);
    return if ($type eq "Results" || $type eq "Sequence");
    if (defined $defs->precond($param,'seqlab')) {
         $precond = $defs->precond($param,'seqlab');
         return if ($precond eq '! seqlab');
    }

    return if ($type eq "OutFile" && $defs->isstandout($param));
    return if ($defs->ishidden($param) &&
            ! (defined $defs->precond($param,'seqlab')));

    my $prompt=$defs->prompt($param);
    my $vdef=$defs->vdef($param);
    my $format=$defs->format($param, 'seqlab');
    if (! $format) {
	my $perl_format = $defs->format($param, 'perl');
	$perl_format =~ s/\$value/value/g;
	$perl_format = '$value=1; ' . $perl_format;
	$format = eval($perl_format);
	print STDERR "perl format: $perl_format\nformat: $format\n";
    }
    my $scalemin=$defs->scalemin($param);
    my $scalemax=$defs->scalemax($param);
    my $scaleinc=$defs->scaleinc($param);

    print "
   $seqlab_name{$type}
     id = $id{$param}
     qualifier = $param
     method = $format";

    if ($defs->ishidden($param)) {
        print "
     display = False
     default = $format";  
    } else {
        print "
     prompt = $prompt";
    }

    unless ($type eq "Switch" || $type eq "List" 
	    || $type eq "Excl" || $defs->ishidden($param) ) {
	print "
     default = $vdef";
    }

    unless ($defs->ismandatory($param)) {
        if ($type ne "Switch" && defined $vdef && $vdef) {
            print "
     toggle = True
     toggledefault = -";
        }
    }

    if ($type eq "List") {
	if ( $defs->ismandatory($param) ) {
	    print "
     menutype = 1";
	}
        my $separator= $defs->separator($param);
        print "
     separator = $separator";

    } elsif ($type eq "Excl") {
	if ( $defs->ismandatory($param) ) {
	    print "
     radiotype = 1";
	}
    } elsif ($type eq "Integer" || $type eq "Float") {
	print "
     scalemin = $scalemin
     scalemax = $scalemax
     scaleinc = $scaleinc";
	if ($type eq "Integer") {
	    print "
     format = \%d";
	} else {
            if ($scaleinc =~ /0\.(0+)/) {
                 $zeros = $1;
                 $l = length($zeros) + 1;
                 $actual_format = '%.' . $l . "f";
            	    print "
     format = $actual_format";
            } else {
            	    print "
     format = \%.1f";
            }
        }
    } elsif ($type eq "Switch") {
         if ($vdef) {
              print "
     default = +";
	  } else {
              print "
     default = -";
         }
    } elsif ($type eq "String") {
    } elsif ($type eq "InFile") {
    } elsif ($type eq "OutFile") {
    }

    if ($type eq "List" || $type eq "Excl") {
        $i=0;
	@vdef = @{ $defs->vdef($param) } if ($type eq "List");
	@values = ( @{ $defs->vlist($param) } );
        if ($type eq "List" && $#values > 10) {
              print "
     columns = 2";
        }
        $n = 0;
	while ($i <= $#values) {
	      $value = $values[$i];
              $n++;
	      $prompt_list=$values[$i+1];
	      if ($type eq "List" ) {
                 if (grep {$_ eq $value} @vdef ) {
                    $default = "+";
                 }
              } elsif ($type eq "Excl" && $value eq $vdef ) {
                 $default = "+";
              } else {
                 $default = "-";
              }

              if ($value) {
                  print "
     Bool
         id = $id{$param}_$n
         qualifier = $value
         prompt = $prompt_list";
                  if ($type eq "Excl") {
                       $actual_format = $format;
                       if ($format =~ /name/) {
                           $actual_format =~ s/name/$param/g ;
                       }
                       if ($format =~ /value/) {
                           $actual_format =~ s/value/name/g ;
                       }
                       print "
         method = $actual_format";
                  } else {
                       print "
         method = name";
                  }
                  print "
         default = $default";
                  if (defined $postcond{$param}{$value}) {
                       $postcond = $postcond{$param}{$value};
                       print "
         rules = $postcond";
                  }
                  print "
     End";
              }
	      $i+=2;
        }
    } elsif (defined $postcond{$param}{True}) {
        $postcond = $postcond{$param}{True};
        print "
     rules = $postcond";
    }


    if ($paragraph eq 'main' && ( ! $defs->ismandatory($param)) ) {
        print "
     answer = False";
    }

    print "
   End
";

}

sub do_postcond {
    my $param;
    foreach $param (@{ $defs->parameters_order}) {
	if (defined $defs->precond($param, 'seqlab')) {
	      if ($defs->type($param) eq "Paragraph") {
	          foreach $p (@{ $defs->vlist($param) }) {
		      &do_one_postcond($p,
				       $defs->precond($param, 'seqlab'));
		  }
              } else {
		  &do_one_postcond($param,
				   $defs->precond($param, 'seqlab'));
	      }
        }
    }

}

sub do_one_postcond {
    my $param = $_[0];
    my $precond = $_[1];
    my $cond;
    my @listv;
    my $var;
    my $val;
    my $sign;
    my $key;
    my $p;
    if ($precond =~ /\|/) {
	@listv = split (/\|/,$precond);
	$var = shift @listv;
	foreach $val (@listv) {
	    if ($val =~ /^\!/) {
		$cond = '!' . $id{$param};
		$val =~ s/^\!// ;
	    } else {
		$cond = $id{$param};
	    }
	    if (defined $postcond{$var}{$val}) {
		$postcond{$var}{$val} .= ",$cond";
	    } else {
		$postcond{$var}{$val} = "$cond";
	    }
	}
    } elsif ($precond =~ /Nuc|Prot/i) {
	if ($precond =~ /^\!/) {
	    $sign = "-";
	} else {
	    $sign = "+";
	}
	if ($precond =~ /Nuc/i) {
	    $key = 'nucrules';
	} else {
	    $key = 'protrules';
	}
	if (defined $seqinfile{$key}) {
	    $sqinfile{$key} .= ",$sign". $id{$param};
	} else {
	    $sqinfile{$key} = $sign . $id{$param};
	}
    } elsif ($precond =~ /,/) {
	@listv = split (/,/,$precond);
	foreach $var (@listv) {
	    if (${"${command}::type"}{$var} eq "Switch" ) {
	        if ($var =~ /^\!/) {
		    $var =~ s/\!// ;
		    $cond='!' . $id{$param};
		} else {
		    $cond = $id{$param};
		}
		if (defined $postcond{$var}{True}) {
		    $postcond{$var}{True} .= ",$cond";
		} else {
		    $postcond{$var}{True} = $cond;
		}
	    }
        }
    } else {
	$var = $precond;
	$var =~ s/\!// ;
	if ($precond =~ /^\!/) {
	    $cond = '!' . $id{$param};
	} else {
	    $cond = $id{$param};
	}
	if (defined $postcond{$var}{True}) {
	    $postcond{$var}{True} .= ",$cond";
	} else {
	    $postcond{$var}{True} = $cond;
	}
    }

}

sub build_convseq {
    my $param;
    my $convseq;
    my $seqname;
    my $fastaseqname;
    my $seqnb=0;

    foreach $param ( $defs->parameters_order ) {
	if ($defs->type($param) eq "Sequence" ) {
	    print STDERR "build_convseq: $param\n";
            $seqnb++;
	    if ( defined $defs->seqfmt($param)  ) {
		my @l = $defs->seqfmt($param);
		$tofmt= $l[0];
	    } else {
		$tofmt = 8 ; # fasta
	    }
            if ($seqinput == 1) {
		$seqname = 'SQ1';
	    } elsif ($seqinput == 2) {
		$seqname = "SQ" . $seqnb;
	    } else {
		$seqname = 'SQ*';
	    }
            $convseqname{$param} = $param . "." . $main::seqfmtssuff{$tofmt};

            if (defined $main::gcgcmd{$tofmt}) {
		$gcgcmd = "\$GCGUTILDIR/" . $main::gcgcmd{$tofmt} . " '$seqname' -outfile=$convseqname{$param} -d ;" ;
	    } else {
		$fastaseqname = "$param." . $main::seqfmtssuff{8};
		$gcgcmd= "\$GCGUTILDIR/" . $main::gcgcmd{8} . " '$seqname' -outfile=$fastaseqname -d";
		$gcgcmd .= "; readseq -p -a -f$tofmt < $fastaseqname > $convseqname{$param};";
	    }

            if ($convseq) {
                $convseq .= $gcgcmd;
            } else {
                $convseq = $gcgcmd;
            }
        }
    }

    return $convseq;

}
