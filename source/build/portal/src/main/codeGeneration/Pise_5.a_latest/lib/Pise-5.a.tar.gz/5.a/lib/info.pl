
sub information_message {

	my $type = $_[0]; # information for short_job or long_job ?

	# un/comment to change the information message to be displayed
	# to all bioweb users
	my $msg = "";
	#my $msg = "The server will be halted on Thursday October, 27th 2005, for 3 hours (8pm to 11pm). All the running jobs will be cancelled. Sorry for inconvenience. ";

	if ($type eq 'long_job') {
		# put here the message you wish for long jobs
#	    $msg = "Warning: Service shutdown scheduled from 20pm to 1am french time (11/20/2002).";
	}
	if ($type eq 'short_job') {
		# put here the message you wish for long jobs
	}
	if ($type eq 'down') {
	    #$msg = "The server is about to be halted. The service should restart in the night. Sorry for the inconvenience.";
	}
	if ($type eq 'db') {
	    $msg = "This program uses databanks which are not available for now. Sorry for the inconvenience.";
	}

	return $msg;

}

1;

