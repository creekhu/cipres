from Pise import PiseFactory
import sys

factory = PiseFactory(email='letondal@pasteur.fr')
program = factory.program("dssp", classic=1)

for i in range(1, len(sys.argv)):
    pdbid = sys.argv[i]
    print "Running DSSP on: ", pdbid
    job = program.run(pdbid=pdbid)
    #job = program.run(pdbfile=sys.argv[i])
    if job.error():
        print job.error_message()
    else:
        #print "url of the job: " + job.jobid()
        #print job.stdout()
        print job.get_results()
        outfile = job.save('dssp.out', "dssp-" + pdbid + ".out")
        print "Result for ", pdbid, " saved in: ", outfile, " (", job.jobid(), ")"


        

