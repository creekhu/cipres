
package Maker;

# Settings

sub do_something {
    local ($title, 
	   $command, 
	   $seqinput,
	   $seqtype,
	   *parameter_type, 
	   *parameters_attributes, 
	   *parameters_order,
	   *top_parameters) = @_;
    
    $VERSION = $ENV{'VERSION'} ;
    
    print "

# perl description of \"$command\" parameters (Version $VERSION)

package $command;

\$${command}::command=\"$command\";
\$${command}::title=\"$title\";

unless (defined \&TRUE) {
     sub TRUE { 1; }
}
unless (defined \&FALSE) {
     sub FALSE { 0; }
}

";


    foreach $param (keys (%parameter_type)) {
	if ($parameter_type{$param} eq "Paragraph") {
	    %attributes = %{$parameters_attributes{$param}};
	    if ( defined $attributes{'group'}) {
		foreach $p ( @{$attributes{'vlist'}} ) {
		    unless ( defined $parameters_attributes{$p}{'group'} ) {
			$parameters_attributes{$p}{'group'} =  $attributes{'group'};
		    }
		}
	    }
	    if ( defined $attributes{'precond'}{'perl'}) {
		foreach $p ( @{$attributes{'vlist'}} ) {
		    unless (defined $parameters_attributes{$p}{'precond'} ) {
			$parameters_attributes{$p}{'precond'}{'perl'} =  $attributes{'precond'}{'perl'};
		    } else {
			$parameters_attributes{$p}{'precond'}{'perl'} =  $attributes{'precond'}{'perl'} 
			. " && " . $parameters_attributes{$p}{'precond'}{'perl'};
		    }
		}
	    }
	}
    }
    
    print "
\@${command}::top_parameters = (\n";
    foreach $param (@top_parameters) {
	print "       \"$param\",\n";
    }

    print "    );\n";
    print "
\@${command}::parameters_order  = (\n";
    foreach $param (@parameters_order) {
	print "       \"$param\",\n";
    }
    print "    );\n";
    
    $seqinput = 0 unless ($seqinput); # no sequences input (seqlab)
    $seqtype = "0" unless ($seqtype); #
    $seqnb = 0;

    print "    
\%${command}::type = (\n";
    foreach $param (keys (%parameter_type)) {
	print "       \"$param\" => \'", $parameter_type{$param}, "\',\n";
        $seqnb++ if ($parameter_type{$param} eq "Sequence");
    }
    print "    );\n";

    if (! $seqinput) {
        if ($seqnb > 0) {
	    $seqinput = ($seqnb <= 3) ? $seqnb : 3;
	}
    }
    if ($seqtype eq "0") {
        if ($seqnb > 0) {
	    $seqtype = "B";
	}
    }

    print "
\$${command}::seqinput=$seqinput; #1=only 1 seq,2=2 seqs,3=any nb (SeqLab)
\$${command}::seqtype=\"$seqtype\"; # P(rot)/N(uc)/B(oth) (SeqLab)
";

    print "    
\%${command}::format = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'format'} ) {
            print "   \"$param\" => {\n";             
            foreach $format ( keys %{ $attributes{'format'} } ) {
	         print "       \"$format\" => \'", $attributes{'format'}{$format}, "\',\n";

            }
            print "    },\n";
        }
    }
    print "    
);\n";
 
   
    print "    
\%${command}::filenames = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'filenames'} ) {
	     print "       \"$param\" => \'", $attributes{'filenames'}, "\',\n";
        }
    }
    print "    
);\n";
    
    print "    
\%${command}::seqfmt = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'seqfmt'} ) {
	     print "       \"$param\" => [", 
	     join ("," , 
	          map {"$_"}
	          @{ $attributes{'seqfmt'}} 
	          ), 
	      "],\n";
        }
    }
    print "    
);\n";
    
    
    print "    
\%${command}::group = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'group'} ) {
	     $group{$param} = $attributes{'group'};
	     print "       \"$param\" => ", $attributes{'group'}, ",\n";
        } else {
             $group{$param} = &max_group_nr + 1;
        }
    }
    print "    );\n";
    
    print "    
\@${command}::by_group_parameters = (\n";
    foreach $param (sort by_group keys (%parameter_type)) {
	print "       \"$param\",\n";
    }
    print "    );\n";

    print "    
\%${command}::size = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'size'}) {
	    print "       \"$param\" => ", $attributes{'size'}, ",\n";
	}
    }
    print "    
);\n";


    print "    
\%${command}::hidden = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'hidden'}) {
	    print "       \"$param\" => TRUE,\n";
	} else {
	    print "       \"$param\" => FALSE,\n";
	}
    }
    print "    
);\n";

    print "    
\%${command}::command = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'command'}) {
	    print "       \"$param\" => TRUE,\n";
	} else {
	    print "       \"$param\" => FALSE,\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::mandatory = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'mandatory'}) {
	    print "       \"$param\" => TRUE,\n";
	} else {
	    print "       \"$param\" => FALSE,\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::prompt = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'prompt'} ) {
	    print "       \"$param\" => ", " \"$attributes{'prompt'}\" ", ",\n";
        }
    }
    print "    
);\n";
    
    print "    
\%${command}::standout = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'standout'}) {
	    print "       \"$param\" => TRUE,\n";
	} else {
	    print "       \"$param\" => FALSE,\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::vlist = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined @{ $attributes{'vlist'}} ) {
	    map {s/\'/\\\'/g} @{ $attributes{'vlist'}};
	    map {s/ +/ /g} @{ $attributes{'vlist'}};
	    print "       \"$param\" => [", 
	    join ("," , 
		  map {"\'$_\'"}
		  @{ $attributes{'vlist'}} 
		  ), 
	    "],\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::flist = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'flist'} }) {
	    print "           \"$param\" => {\n";
	    foreach $k (keys %{ $attributes{'flist'} }) {
		$v = $attributes{'flist'}{$k};
		print "                            \'$k\' => \'$v\',\n";
	    }
	    print "                       },\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::separator = (\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "List") {
	%attributes = %{$parameters_attributes{$param}};
	print "       \"$param\" => \'", $attributes{'separator'}, "\',\n";
      }
    }
    print "    
);\n";
    
    print "    
\%${command}::vdef = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'vdef'}) {
	    if ($parameter_type{$param} eq "List") {
	        print "       \"$param\"	=> [";
	        foreach $v ( @{ $attributes{'vdef'}} ) {
		    print "\'$v\',";
	        }
	        print " ],\n";
	    } else {
	        print "       \"$param\" => \'", $attributes{'vdef'}, "\',\n";
	    }
        }
    }
    print "    
);\n";


    print "    
\%${command}::precond = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'precond'} ) {
            print "   \"$param\" => {\n";             
            foreach $format ( keys %{ $attributes{'precond'} } ) {
	         print "       \"$format\" => \'", $attributes{'precond'}{$format}, "\',\n";

            }
            print "    },\n";
        } else {
	    print "       \"$param\" => {
		\"perl\"  => \'1\',
	    },\n";
	}
    }
    print "    
);\n";
 
    
    print "    
\%${command}::ctrl = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'ctrl'} }) {
	    print "           \"$param\" => {\n";
	    foreach $msg (keys %{ $attributes{'ctrl'} }) {
                foreach $lg (keys %{ $attributes{'ctrl'}{$msg} } ) {
                    if ( $lg = 'perl') {
                        $test = $attributes{'ctrl'}{$msg}{$lg};
		        print "             \'$test\' => \"$msg\",\n";
                    }
                }
	    }
	    print "                       },\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::pipeout = (\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "OutFile" ||
          $parameter_type{$param} eq "Results"  ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'pipe'} }) {
	    print "           \"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'pipe'} }) {
                foreach $lg (keys %{ $attributes{'pipe'}{$type} } ) {
                    if ( $lg = 'perl') {
                        $test = $attributes{'pipe'}{$type}{$lg};
		        print "              \'$test\' => \"$type\",\n";
                    }
                }
	    }
	    print "                       },\n";
	}
      }
    }
    print "    
);\n";
    
     print "    
\%${command}::withpipeout = (\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "OutFile" ||
          $parameter_type{$param} eq "Results" ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'withpipe'} }) {
	    print "           \"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'withpipe'} }) {
		print "             \"$type\" => [\n";
                foreach $paramname (@{ $attributes{'withpipe'}{$type} } ) {
		    print "                   \'$paramname\',\n";
                }
		print "             ]\n";
	    }
	    print "                       },\n";
	}
      }
    }
    print "    
);\n";
   
    print "    
\%${command}::pipein = (\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "InFile" ||
          $parameter_type{$param} eq "Sequence" ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'pipe'} }) {
	    print "           \"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'pipe'} }) {
                foreach $lg (keys %{ $attributes{'pipe'}{$type} } ) {
                    if ( $lg = 'perl') {
                        $test = $attributes{'pipe'}{$type}{$lg};
		        print "             \"$type\" => \'$test\',\n";
                    }
                }
	    }
	    print "                       },\n";
	}
      }
    }
    print "    
);\n";

     print "    
\%${command}::withpipein = (\n";
    foreach $param (keys (%parameter_type)) {
      if ($parameter_type{$param} eq "InFile" ||
          $parameter_type{$param} eq "Sequence" ) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined %{ $attributes{'withpipe'} }) {
	    print "           \"$param\" => {\n";
	    foreach $type (keys %{ $attributes{'withpipe'} }) {
		print "             \"$type\" => [\n";
                foreach $paramname (@{ $attributes{'withpipe'}{$type} } ) {
		    print "                   \'$paramname\',\n";
                }
		print "             ]\n";
	    }
	    print "                       },\n";
	}
      }
    }
    print "    
);\n";
   
    print "    
\%${command}::clean = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'clean'}) {
	    print "       \"$param\" => TRUE,\n";
	} else {
	    print "       \"$param\" => FALSE,\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::simple = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if ($attributes{'simple'}) {
	    print "       \"$param\" => TRUE,\n";
	} else {
	    print "       \"$param\" => FALSE,\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::paramfile = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'paramfile'}){
	    print "       \"$param\" => \'", $attributes{'paramfile'}, "\',\n";
        }
    }
    print "    
);\n";
    
    
    print "    
\%${command}::comment = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
	if (defined @{ $attributes{'comment'}} ) {
	    map {s/\'/\\\'/g} @{ $attributes{'comment'}};
	    map {s/ +/ /g} @{ $attributes{'comment'}};
	    print "       \"$param\" => [", 
	    join ("," , 
		  map {"\'$_\'"}
		  @{ $attributes{'comment'}} 
		  ), 
	    "],\n";
	}
    }
    print "    
);\n";
    
    print "    
\%${command}::scalemin = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'scalemin'}){
	    print "       \"$param\" => \'", $attributes{'scalemin'}, "\',\n";
        }
    }
    print "    
);\n";

    print "    
\%${command}::scalemax = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'scalemax'}){
	    print "       \"$param\" => \'", $attributes{'scalemax'}, "\',\n";
        }
    }
    print "    
);\n";
    
    print "    
\%${command}::scaleinc = (\n";
    foreach $param (keys (%parameter_type)) {
	%attributes = %{$parameters_attributes{$param}};
        if (defined $attributes{'scaleinc'}){
	    print "       \"$param\" => \'", $attributes{'scaleinc'}, "\',\n";
        }
    }
    print "    
);\n";
    

    print "1;\n";

}

sub by_group {
    my %attributes_a = %{$parameters_attributes{$a}};
    my %attributes_b = %{$parameters_attributes{$b}};
    $attributes_a{'group'} <=> $attributes_b{'group'};
}
sub max_group_nr {
    return $group{$by_group_parameters[$#by_group_parameters]};
}

1;


