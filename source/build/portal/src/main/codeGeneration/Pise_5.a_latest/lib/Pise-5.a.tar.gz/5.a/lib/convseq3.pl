
## Sequence format checker

use strict;

use File::Basename;

## Sequence format
my %compat = ( 1 => 'IG', 2 => 'GENBANK', 3 => 'NBRF', 4 => 'EMBL',
	       5 => 'GCG', 8 => 'FASTA', 9 => 'ZUKER', 11 => 'PHYLIPS',
	       12 => 'PHYLIP', 13 => 'RAW', 14 => 'PIR', 15 => 'MSF',
	       17 => 'NEXUS', 100 => 'CLUSTAL' );

my %fmtseq = ( 1 => 'RAW', 
	       2 => 'RAW', # PLAIN ?
	       3 => 'EMBL', 
	       4 => 'EMBL',  # Swissprot?
	       5 => 'GCG', 
	       6 => 'PIR',
	       8 => 'FASTA', 
	       9 => 'FASTA', 
	       12 => 'NBRF', 
	       13 => 'NBRF-old',
	       14 => 'IG',
	       15 => 'IG-old',
	       16 => 'GCG',
	       17 => 'MSF', 
	       18 => 'PHYLIP',
	       19 => 'PHYLIP',
	       20 => 'PHYLIP',
	       21 => 'CLUSTAL' );

sub readseq_code {
    my $name = $_[0];
    foreach my $nb (keys(%compat)) {
	if ($compat{$nb} eq $name) {
	    return $nb;
	}
    }
    return -1;
}

sub fmtseq_code {
    my $name = $_[0];
    foreach my $nb (keys(%fmtseq)) {
	if ($fmtseq{$nb} eq $name) {
	    return $nb;
	}
    }
    return -1;
}

## Get sequence format
sub convseq_format {
  my ($seqfile) = @_;

  my $infmt;

  ## Check with squizz
  $infmt = undef;
  open (FMT, "squizz $seqfile 2>&1 |");
  while (<FMT>) {
    next if (! /: (.+) format\.$/);
    $infmt = $1; last; }
  close (FMT);
  if ($? == 0 and defined $infmt and $infmt ne 'UNKNOWN') {
    return ('squizz', $infmt); }

  ## Check with readseq
  $infmt = undef;
  open (FMT, "readseq -v -p < $seqfile 2>&1 |");
  while (<FMT>) {
    next if (! /^Sequence.*format=\s+(\d+)\.\s+(\S+),/);
    $infmt = $2; last; }
  close (FMT);
  if ($? == 0 and defined $infmt) {
    return ('readseq', $infmt); }

  ## Check with fmtseq
  $infmt = undef;
  open (FMT, "fmtseq -li $seqfile 2>&1 |");
  while (<FMT>) {
    next if (! /^The Sequences of .+ \((\S+)\)/);
    $infmt = $1; last; }
  close (FMT);
  ## Warning: unknown formats are identified as `Plain'
  if ($? == 0 and defined $infmt and $infmt !~ /Plain/) {
    return ('fmtseq', $infmt); }

  return ('none', 'unknown'); 
}


## Convert sequence file
sub convseq_convert {
  my ($seqfile, @seqfmt) = @_;

  ## Check for valid file name
  if ($seqfile =~ m,/$,) { return; }

  ## Get input format and program
  my ($prg, $infmt) = convseq_format($seqfile);

  ## Set output formats
  foreach (@seqfmt) {
    next if (! /^\d+$/ or ! exists $compat{$_});
    $_ = $compat{$_}; }

  ## Log format detection
  open (LOG, '>> /bioweb/logs/seqfmt.log');
  print LOG "** $seqfile **\nIN: $prg ... $infmt\nOUT: @seqfmt\n";
  close (LOG);

  ## Log format in work directory
  my ($seq,$log,undef) = File::Basename::fileparse($seqfile, '');
  open (LOG, ">> $log/.seqfmt");
  print LOG "$seq: $infmt ($prg)\n";
  close (LOG);

  my $outfmt = $infmt;

  ## Do not convert unknown format
  if ($infmt eq "unknown") { return ($prg, $infmt, $outfmt); }

  ## Check if already in expected format
  my $ok = grep(/^$infmt$/, @seqfmt);
  if ($ok != 0) { return ($prg, $infmt, $outfmt); }

  my $date=localtime;
  $outfmt = $seqfmt[0];

  ## Convert sequence/alignment
  my $outfile = "$seqfile.$prg"; my $orifile = "$seqfile.orig";
  if ($prg eq "squizz") {
      print STDERR "[$date] converting $orifile ($infmt) to $outfile ($outfmt) by $prg\n";
      open (FMT, "squizz -c $outfmt $seqfile > $outfile 2>/dev/null |");
      close (FMT);
      if ($? or -z $outfile) { 
	  print STDERR "[$date] SQUIZZ: $seqfile formatting failed.\n"; 
	  unlink ($outfile);
	  $outfmt = "unknown";
      }
  } elsif ($prg eq "readseq") {
      my $code = readseq_code($outfmt);
      print STDERR "[$date] converting $orifile ($infmt) to $outfile ($outfmt) by $prg\n";
      open (FMT, "readseq -p -a -f$code  < $seqfile > $outfile 2>/dev/null |");
      close (FMT);
      if ($? or -z $outfile) { 
	  print STDERR "[$date] READSEQ: $seqfile formatting failed.\n"; 
	  unlink ($outfile);
	  $outfmt = "unknown";
      }
  } elsif ($prg eq "fmtseq") {
      my $code = fmtseq_code($outfmt);
      print STDERR "[$date] converting $orifile ($infmt) to $outfile ($code:$outfmt) by $prg\n";
      open (FMT, "fmtseq -p -all -f$code < $seqfile > $outfile 2>/dev/null |");
      close (FMT);
      if ($? or -z $outfile) { 
	  print STDERR "[$date] FMTSEQ: $seqfile formatting failed.\n"; 
	  unlink ($outfile);
	  $outfmt = "unknown";
      }
   
  }
 
  ## Rename old and new files
  if ($outfmt eq "unknown") {
      rename ($seqfile, $outfile); } 
  rename ($seqfile, $orifile);
  rename ($outfile, $seqfile);

  ## return results
  return ($prg, $infmt, $outfmt); }

1;
