# 
# make-index.pl: by Mark Warmoes 
#  generates an HTML frameset with programs grouped by categories
#   (slightly adapted to Pise recent changes)
#

use Data::Dumper;
use lib "/usr/local/gensoft/lib/Pise/current/PerlDef";
use Getopt::Long;


# Settings
$PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : "/usr/local/gensoft/lib/Pise/current/PerlDef";
$PISEDIR=($ENV{'PISEDIR'})? $ENV{'PISEDIR'} : "/usr/local/gensoft/lib/Pise";
$VERSION = ($ENV{'VERSION'})? $ENV{'VERSION'} : "5.a" ;
require "$PISEDIR/lib/web.pl";
# get all modules in PerlDef directory
#my @modules = glob("$PERLDEFDIR/*.pm");
my $data = {};
my ($cgi, $index, $modules);

GetOptions ( "index:s" => \$index,
             "navframe:s" => \$navframe,
             "alpha:s" => \$alpha,
             "category:s" => \$category,
	     "modules:s" => \$modules);

#print STDERR "modules(1): $modules\n";
chomp($modules);
my @modules = split(/\s/, $modules);
@modules = map($_ . ".pm" , @modules);
#print STDERR "modules(2): @modules\n";

#exit;

&print_index if ($index);
&print_NavFrame if ($navframe);
&print_alpha if ($alpha);
&print_category if ($category);

sub print_alpha  {
    foreach my $perldef (@modules)
    {
	next if ($perldef =~ /^\.pm$/);
	print STDERR "Doing $perldef (alpha) ...\n";
	require "$perldef";
	my ($package) = $perldef =~ m|([^/]+)\.pm$|;
	my $defs = new $package;
	$data->{$package}->{description} = $defs->description;
	$data->{$package}->{categories}    = $defs->categories;
    }
    my $pise_data = Data::Dumper->Dump([$data],[qw(data)]);
    my $arrow = "\<img src=\"$IMAGES_DIR/arrow.gif\">";
    print "<html>\n",
    "<head>\n",
      "<title>Pise Applications</title>\n",
      "<link rel=\"stylesheet\" type=\"text/css\" href=\"pise.css\">\n",
      "</head>\n",
      "<body>\n",
      "<H1><img align=top src=\"$IMAGES_DIR/torre1x.gif\">PISE - Pasteur Institute Software Environment</h1>",
      "<DL>\n";
    foreach my $program (sort keys %$data) 
    {
       print "<DT>\n",
             "<h3>$program\n</h3>",
             "<DD>\n",
             "<a href=\"$program.html\">Advanced</a>\n",
             "<a href=\"$program-simple.html\">/simple</a>\n",
             " version<br>\n";
       print "<H4>$data->{$program}->{description}</h4>\n";

       my @cats= @{ $data->{$program}->{categories} };
       if ( @cats >= 1)
       {
	   print "<br>\n";
	   foreach my $cat (@cats) {
	       my @l = split(/:/, $cat);
	       my $maincat = $l[0];
	       if ($maincat) {
		   print "<b><A HREF=\"category.html#$maincat\">$arrow</A> $cat</b>\n";
	       } else {
		   print "<b><A HREF=\"category.html#$cat\">$arrow</A> $cat</b>\n";
	       }
	       #print "<BR>\n";
	   }

       }
       print "<HR>\n";
   }
    print "</DL>\n";
    print "<BR>\n" x 50;
    print "</body>\n";
}


sub print_index   {
    print "<html>\n",
      "<head>\n",
      "<title>Pise Applications</title>\n",
      "<link rel=\"stylesheet\" type=\"text/css\" href=\"pise.css\">\n",
      "</head>\n",
      "<FRAMESET COLS=\"20%,80%\">\n",
      "<FRAME NAME=\"navframe\" SRC=\"navframe.html\">\n",
      "<FRAME NAME=\"mainframe\" SRC=\"alpha.html\">\n",
      "</frameset>\n",
};



sub print_category  {
    foreach my $perldef (@modules)
    {
	next if ($perldef =~ /^\.pm$/);
	print STDERR "Doing $perldef (category) ...\n";
	require "$perldef";
	my ($package) = $perldef =~ m|([^/]+)\.pm$|;
	my $defs = new $package;
	$data->{$package}->{description} = $defs->description;
	$data->{$package}->{categories}    = $defs->categories;
	
	
    }
    my $pise_data = Data::Dumper->Dump([$data],[qw(data)]);
    my $arrow = "\<img src=\"$IMAGES_DIR/arrow.gif\">";
    my @subcat;
    my $app;
    my $category;
    my $cat;
    my %categories;
    my $pise_data;
    
    print "<html>\n",
      "<head>\n",
      "<title>Pise - overview</title>\n",
      "<link rel=\"stylesheet\" type=\"text/css\" href=\"pise.css\">\n",
      "</head>\n",
      "<body>\n",
      "<H1><img align=top src=\"$IMAGES_DIR/torre1x.gif\">PISE - Pasteur Institute Software Environment</h1>";
    foreach my $program (keys %$data)
    {
	my $categories = $data->{$program}->{categories};
	foreach my $subcats (@{ $categories }) {
	    my @subcats = split(/:/, $subcats);
	    my $cat = $subcats[0];
	    my $subcat = $subcats[1];
	    if (exists $categories{$cat})
	    {
		push (@{$categories{$cat}},$program);
	    }
	    else
	    {
		$categories{$cat} = [$program];
	    }
	}
    }
    print "<DL>\n";
    foreach my $category (sort keys %categories)
    {
	print "<DT>\n";
	print "<a name=\"$category\"></a>";
	print "<h2>$category</h2>\n";
	foreach my $app ( sort (@{$categories{$category} } ))
	{
	    print "<h3>$app</h3>\n";
	    print "<a href=\"$app.html\">Advanced</a>\n",
	    "<a href=\"$app-simple.html\">/simple</a>\n",
	    " version<br>\n";
	    print "$data->{$app}->{description}";
	    my @cats= @{ $data->{$app}->{categories} };
	    if ( @cats >= 1)
	    {
		print "<br>\n";
		foreach my $cat (@cats) {
		    my @l = split(/:/, $cat);
		    my $maincat = $l[0];
		    #print STDERR "$app category: $category maincat: $maincat\n";
		    if ($maincat eq $category) {
			if ($cat ne $category) {
			    print "<b>$cat</b>\n";
			}
		    } else {
			print "<b><A HREF=\"#$maincat\">$arrow</A> $cat</b>\n";
		    }
		    print "<BR>\n";
		}
	    }
	    print "<hr>\n";
	}
	print "<DD>\n";
    }
    print "</DL>\n";
    print "<BR>\n" x 50;
    print "</body>\n";
}

sub print_NavFrame   {

    foreach my $perldef (@modules)
    {
	next if ($perldef =~ /^\.pm$/);
	print STDERR "Doing $perldef (navframe) ...\n";
	require "$perldef";
	my ($package) = $perldef =~ m|([^/]+)\.pm$|;
	my $defs = new $package;
	$data->{$package}->{description} = $defs->description;
	$data->{$package}->{categories}    = $defs->categories;
    }
    my $pise_data = Data::Dumper->Dump([$data],[qw(data)]);
    
    print "<html>\n",
      "<head>\n",
      "<title>NavFrame</title>\n",
      "<link rel=\"stylesheet\" type=\"text/css\" href=\"pise.css\">\n",
      "</head>\n",
      "<body>\n",
      "<base target=\"mainframe\">\n",
      "<h3><a href=\"alpha.html\">Alphanumeric</a><br></h3>\n",
      "<h3><a href=\"category.html\">By Category</a><br></h3>\n";
    print "<hr>\n";
    foreach my $program (keys %$data)
    {
	print STDERR "program: $program\n";
	my $categories = $data->{$program}->{categories};

	foreach my $subcats (@{ $categories }) {
	    my @subcats = split(/:/, $subcats);
	    my $cat = $subcats[0];
	    my $subcat = $subcats[1];
	    print STDERR "\tcat: ", $cat, "\n";
	    if (exists $category{$cat})
	    {
		push (@{$category{$cat}},$program);
	    }	    else
	    {
		$category{$cat} = [$program];
	    }
	    if ($subcat) {
		print STDERR "\t\tsubcat: ", $subcat, "\n";
	    }
	}
    }
    foreach my $category (sort keys %category)
    {
	print "<h3>\n";
	print  "<a href=\"category.html#$category\">$category</a>\n</h3>\n";
    }
    print "</body>\n";
};
                         
