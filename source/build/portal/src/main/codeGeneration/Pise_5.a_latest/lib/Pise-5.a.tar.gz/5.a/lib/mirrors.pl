
%MIRRORS = ();

%NOT_ANYMORE_MIRRORS = (
    'fastdnaml' => ['http://kun.homelinux.com/Pise/5.a/fastdnaml.html'],
    'Puzzle' => ['http://kun.homelinux.com/Pise/5.a/Puzzle.html'],
    'prot_nucml' => ['http://kun.homelinux.com/Pise/5.a/prot_nucml.html'],
    'dialign2' => ['http://kun.homelinux.com/Pise/5.a/dialign2.html'],
    'dnapars' => ['http://kun.homelinux.com/Pise/5.a/dnapars.html'],
    'dnadist' => ['http://kun.homelinux.com/Pise/5.a/dnadist.html'],
    'protpars' => ['http://kun.homelinux.com/Pise/5.a/protpars.html'],
    'protdist' => ['http://kun.homelinux.com/Pise/5.a/protdist.html'],
    'neighbor' => ['http://kun.homelinux.com/Pise/5.a/neighbor.html'],
);

sub get_mirrors {
    my $command = $_[0];
    if (defined $MIRRORS{$command}) {
	return @{ $MIRRORS{$command} } ;
    }
    my @empty = ();
    return @empty;
}

1;
