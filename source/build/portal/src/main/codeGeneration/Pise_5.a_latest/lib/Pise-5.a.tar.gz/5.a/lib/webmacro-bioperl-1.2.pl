#! /local/bin/perl

# to be used with Pise/bioperl module
# See http://www-alt.pasteur.fr/~letondal/Pise/#pisebioperl
# (requires bioperl 1.2 with bioperl-run, or else a Pise distribution 
# and setting: use lib /local/gensoft/lib/Pise/5.a -- see BEGIN clause)
#

# TODO
# summary with evaluating preconds
# withpipe

# required if you don't have bioperl 1.2 installed with bioperl-run
BEGIN {
    use lib "/local/gensoft/lib/Pise/5.a";
}

require "/local/gensoft/lib/Pise/5.a/lib/web.pl";
use lib "/local/gensoft/lib/Pise/5.a/PerlDef";

use Bio::Tools::Run::AnalysisFactory::Pise;
use CGI;
use File::Basename;

sub script_ok {
    return 1;
}

# problem: CGI_DIR may not be under ROOT_WEB
my $MACROS_DIR = (-d "$ROOT_WEB/$CGI_DIR/macros")? "$ROOT_WEB/$CGI_DIR/macros" : "$CGI_DIR/macros";
my $MACROS_URL = "$CGI_URL/macros";
my $MACROS_EXEC = "$tmp_dir/macros";
my $MACROS_EXEC_URL = "$tmp_url/macros";

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";
my @commands;

my $input = new CGI;
my $command=$input->param('command');
eval ("use Pise::$command;");
my $scratch_dir=$input->param('scratch_dir');
my $email=$input->param('email');
$email =~ s/\\//;

print $input->header;
print $input->start_html("Saving a procedure.");
print $input->h1("Saving  a procedure.");
my $date=localtime;
$me = basename $0;
chomp($me);
print STDERR "[$date] $me $command $scratch_dir ($email)\n";

my @first_params;
my @first_prompts;
my @first_values;
my @first_params_types;
my @first_params_cmds;
my %in_piped_file_type;

my $factory = new Bio::Tools::Run::AnalysisFactory::Pise();

chdir("/$tmp_dir/$scratch_dir") || die "can't cd to $scratch_dir: $!";
open (MACRO,"> macro.pl") || die "cannot open macro.pl: $!";
lookup_dir("$tmp_dir/$scratch_dir");


&print_headers;
&print_macro;
close MACRO;
print "<I>This is</I> <A HREF=\"$tmp_url/$scratch_dir/macro.html\">a form</A><I> to reuse the whole procedure later, and to save in your bookmarks.</I>\n";
;

if (script_ok($email)) {
    print "<BR></BR><I>This is </I> <A HREF=\"$tmp_url/$scratch_dir/macro.pl\">a perl script</A>\n";
    print "<I>to be edited and executed (for programmers).</I>\n";
}

&print_summary;

print $input->end_html;
save_form($command);

sub print_macro {
    my $first=1;
    my $first_input;
    my $piped_file;
    my $paramdata;
    my $prompt;
    my $type;

    foreach my $cmd (@commands) {
	print_init($cmd);
	print_args($dir{$cmd},$cmd,$first, MACRO);
	if ($first) {
	    $first = 0;
	}
	foreach my $in ( @{ $in_param{$cmd} } ) {
	    ($prev_cmd,$piped_file) = split(",",$pipe{$cmd,$in});
	    $prev_command{$cmd} = $prev_cmd;
	    $prompt = $prompt{$cmd,$in};
	    $type = $in_piped_file_type{$cmd,$in};
#	    print STDERR "DEBUG> print_macro: $cmd in=$in type=$type\n";
	    print MACRO "\n#---------------------------------------------------------\n";
	    print MACRO "# $prompt\n";
            if ($data{$cmd,$in}) {
		print MACRO "my \$saved_file = \$$prev_cmd","_job->save(\$$prev_cmd","_job->lookup_piped_file('$type'));\n";
		print MACRO "\$$cmd","->$in(\$saved_file);\n";
	    } else {
		print MACRO "\$$cmd","->$in(\$$prev_cmd","_job->fh(\$$prev_cmd","_job->lookup_piped_file('$type')));\n";
	    }

	}
	print_run($cmd);
	propose_results($dir{$cmd},$cmd);
    }
}


sub lookup_dir {
    my $dirname = $_[0];
    my $file = $_[1];
    my $cmd = what_command($dirname);
    return if (defined $dir{$cmd});
    unshift (@commands,$cmd);
    $dir{$cmd} = $dirname;
    opendir(DIR, $dirname) || die "cannot open dir $dirname: $!";
    my @files = readdir DIR;
    close DIR;
    my $name;
    my $base;
    my $prev_dir;
    my $last=1;
    my $arg;
    my $in;
    my @arg;
    foreach my $f (@files) {
	next if ("$dirname/$f" eq ".");
	next if ("$dirname/$f" eq "..");
	if (-l "$dirname/$f") {
	    $name = readlink "$dirname/$f";
	    $base = basename $name;
	    chomp($base);
	    ($prev_dir = $name) =~ s/$base//;
	    chop($prev_dir);
	    while (-l "$prev_dir/$base") {
		$name = readlink "$prev_dir/$base";
		$base = basename $name;
		chomp($base);
		($prev_dir = $name) =~ s/$base//;
		chop($prev_dir);
	    }
#	    $name = "$prev_dir/$base";
#	    print STDERR "($dirname) link: $f = $name (prev_dir=$prev_dir)\n";
	    if ($name =~ /$tmp_dir/) {
		$base = basename $name;
		chomp($base);
		($prev_dir = $name) =~ s/$base//;
		chop($prev_dir);
#		print STDERR "DEBUG> lookup_dir: base=$base prev_dir=$prev_dir\n";
		if (-e $prev_dir) {
		    # ok there is a link to a previous job which
		    # directory still exists
		    ($prev_cmd,@arg) = split ('\.',$f);
		    $arg = join (".",@arg);
		    $arg =~ s/\.orig$//;
		    # determine the name of the param for cmd that will
		    # get the input from the pipe
		    $in = arg2param($prev_dir,$prev_cmd,$cmd,$arg);
#		    print STDERR "DEBUG> lookup_dir: $arg ($f), in = $in\n";
		    push @{ $in_param{$cmd} }, $in;
		    # record for this param the name of the file and the 
		    # previous command
		    $pipe{$cmd,$in} = "$prev_cmd,$base";
		    stat("$dirname/$f");
		    if (! (-T _)) {
			print STDERR "Not a text file $dirname/$f\n";
			$data{$cmd,$in} = 1;
		    }
		    # go one step further
		    lookup_dir ($prev_dir, "$dirname/$f");
		    $last = 0;
		} else {
		    print STDERR "$prev_dir does not exist anymore\n";
		}
	    }
	}
    }
}

sub what_command {
    my $dirname = $_[0];
    my $cmd = $dirname;
    $cmd =~ s/$tmp_dir//;
    $cmd =~ s/(.+)\/\w?\d+/$1/;
    $cmd =~ s/\///g;
#    print STDERR "DEBUG> $date $me: current command ($dirname): $cmd\n";
    return $cmd;
}

sub propose_results {
    my $dir = $_[0];
    my $cmd = $_[1];
    my $tmp;
    ($tmp = $dir) =~ s/$tmp_dir//;
    my $jobid = $tmp_url . $tmp . "/index.html";
#    print STDERR "propose_results: $jobid cmd=$cmd prev_cmd=$prev_cmd\n";
    my $job = $factory->job($jobid);
    my @results = $job->get_results($jobid);
    my $filename;
    foreach my $result (@results) {
	($filename = $result) =~ s/$tmp_url//;
	$filename =~ s/$cmd//;
	$filename =~ s/\w?\d+\///;
	$filename =~ s/\///g;
	if ($filename) {
	    next if ($filename =~ /$cmd\.err/);
#	    print STDERR "propose_results: cmd=$cmd $filename\n";
	    print MACRO "\n#------ uncomment either of this lines to get this output file ------\n";
	    print MACRO "#print \$$cmd","_job->content(\"$filename\");\n"; 
	    print MACRO "#\$$cmd","_job->save(\"$filename\");\n"; 
	}
    }
    return;
}

sub arg2param {
    my $dir = $_[0];
    my $prev_cmd = $_[1];
    my $cmd = $_[2];
    my $arg = $_[3];
    my $content;
    my $tmp;
    ($tmp = $dir) =~ s/$tmp_dir//;
    my $jobid = $tmp_url . $tmp . "/index.html";
    my $job = $factory->job($jobid);
    my @results = $job->get_results($jobid);
    return undef if ($#results < 0);
    my @pipes;
    my $paramaram;
    my $piped_file_type;
    eval ("use $cmd;");
    my $defs = $cmd->new;
    my %pipeins;
    my $file;
    foreach my $result (@results) {
	($file = $result) =~ s/$tmp_url//;
	$file =~ s/$tmp//;
	$file =~ s/\///g;
	if ($file eq $arg) {
#	    print STDERR "DEBUG> arg2param: looking for $file ($cmd) (result=$result)\n";
	    @pipes = $job->get_pipes($result);
#	    print STDERR "DEBUG> arg2param: pipes = ",join(",",@pipes),"\n";
	    if (grep {$_ eq $cmd} @pipes) {
		$piped_file_type = $job->piped_file_type($result);
#		print STDERR "DEBUG> arg2param: piped by $cmd (type=$piped_file_type)\n";
		%pipeins = $defs->pipein;
		foreach $param (keys %pipeins) {
		    if (defined $defs->pipein($param,$piped_file_type)) {
#			print STDERR "DEBUG> arg2param: $param ",$pipein{$param}," type = $piped_file_type\n";
			$in_piped_file_type{$cmd,$param} = $piped_file_type;
			return $param;
		    }
		}
		%withpipeins = $defs->withpipein;
		my %types;
		my $type;
		foreach $param (keys %withpipeins) {
#		    print STDERR "DEBUG> arg2param: $param ?\n";
		    %types = $defs->withpipein($param);
		    foreach $type (keys %types) {
#			print STDERR "DEBUG> arg2param: $type ?\n";
			foreach $p ($defs->withpipein($param,$type)) {
#			    print STDERR "DEBUG> arg2param: $p ?\n";
			    if (defined $defs->pipein($param,$type,$p)) {
				$in_piped_file_type{$cmd,$p} = $p;
				return $p;
			    }
			}
		    }
		}
	    }
	}
    }
    return undef;
}

sub print_args {
    my $dir = $_[0];
    my $cmd = $_[1];
    my $first = $_[2];
    my $fh = $_[3];

    my $jobid = $tmp_url;
    my $jobdir = $dir;
    $jobdir =~ s/$tmp_dir//;
    $jobid .= "$jobdir/index.html";

    #print STDERR "DEBUG> print_args dir: $dir jobid: $jobid\n";
    my $job = $factory->job($jobid);

    eval ("use $cmd;");
    my $defs = $cmd->new;
    my $type;
    my $vdef;
    my $value;
    my $content;
    my $varname;
    my $paramdata;
    my $separator;
    my $i;
    my $form_input;
    foreach my $param ($defs->parameters_order) {
	for ($i=0; $i < scalar(@first_params); $i++) {
	    if ($param eq $first_params[$i] && $cmd eq $first_params_cmds[$i]) {
#		print STDERR "DEBUG> print_args: $param in first_params\n";
		$form_input = 1;
	    }
	}
#	    print STDERR "DEBUG> print_args: $param in = $in_param{$cmd}\n";
	$type = $defs->type($param);
	$vdef = $defs->vdef($param);
	$prompt = $defs->prompt($param);
	$value = $job->value($param);
	$ismandatory = $defs->ismandatory($param);
	$hasprecond = (defined $defs->precond($param) && ($defs->precond($param,'perl') != 1)) ? 1 : 0;
	
	if ($type eq "Switch") {
	    if ($value eq "True") {
		$value=1;
	    } elsif ($value eq "on") {
		$value=1;
	    } elsif ($value eq "False") {
		$value=0;
	    } elsif ($value eq "") {
		$value=0;
	    }
	    if ($vdef eq "True") {
		$vdef=1;
	    } elsif ($vdef eq "on") {
		$vdef=0;
	    } elsif ($vdef eq "False") {
		$vdef=0;
	    } elsif ($vdef eq "") {
		$vdef=0;
	    }
	}
	#print STDERR "DEBUG> print_args: $param type=$type value=$value vdef=$vdef\n";
	if ($form_input) {
	    print $fh "\n#---------------------------------------------------------\n";
	    print $fh "# $prompt\n";
	    print $fh "# input from FORM\n";
            if ($type eq "String") {
		print $fh "\$$cmd","->$param(\"\$$param\");\n"; 
	    } else {
		print $fh "\$$cmd","->$param(\$$param);\n"; 
	    }
	    $form_input = 0;
	} elsif ($first && ($type eq "Sequence" || $type eq "InFile")) {
	    if ($value ne "") {
		$varname = $cmd . "_" . $param;
		print $fh "\n#---------------------------------------------------------\n";
		print $fh "# $prompt\n";
		print $fh "# \$$varname can be associated to a file ";
		if ($type eq "Sequence") {
			print $fh ", a bioperl Bio::Seq object or a string\n";
		} else {
			print $fh " or a string\n";
		}
		print $fh "\n# 1) filename:\n";
		print $fh "my \$$varname = \$ARGV[",scalar(@first_params),"];\n";
		if ($type eq "Sequence") {
		    print $fh "\n# 2) bioperl Bio::Seq object (http://bio.perl.org):\n";
		    print $fh "#use Bio::SeqIO;\n";
		    print $fh "#my \$$varname = Bio::SeqIO->new (-file => \$ARGV[",scalar(@first_params),"], -format => 'fasta');\n";

		    print $fh "\n# 3) string\n";
		} else {
		    print $fh "\n# 2) string\n";
		}
		print $fh "#my \$$varname = \"";
		open (INPUT,"$dir/$value") || die "cannot open $dir/$value:$!";
		$content = join ("#", <INPUT>);
		close INPUT;
		$content =~ s/\"/\\\"/g;
		$content =~ s/\@/\\@/g; 
		print $fh $content; 
		print $fh "#" . "\";\n\n"; 

		print $fh "\$$cmd","->$param(\$$varname);\n"; 
		print STDERR "DEBUG> $param ($cmd) ($type) is first input ($value)\n"; 
		push (@first_params, $param );
		push (@first_params_cmds, $cmd);
		push (@first_params_types,$type);
		push (@first_prompts,$prompt);
		push (@first_values,"$dir/$value");
	    }
	} elsif ($first && $ismandatory && (! $hasprecond)  && $vdef eq "") {
	    print STDERR "DEBUG> $param ($cmd) ($type) is first input. Value: $value\n";
	    print $fh "\n#---------------------------------------------------------\n";
	    print $fh "# $prompt\n";
	    print $fh "# (mandatory parameter)\n";
	    print $fh "# 1) either your actual input:\n"; 
            if ($type eq "String") {
                print $fh "#\$$cmd","->$param(\"$value\");\n"; 
            } elsif ($type eq "Excl") {
                print $fh "#\$$cmd","->$param('",$value,"');\n"; 
            } else {
                print $fh "#\$$cmd","->$param($value);\n"; 
            }
	    print $fh "# 2) or a parameter:\n"; 
	    print $fh "#\$$cmd","->$param(\$ARGV[",scalar(@first_params),"]);\n"; 
	    push (@first_params,$param);
	    push (@first_params_cmds, $cmd);
	    push (@first_params_types,$type);
	    push (@first_prompts,$prompt);
	    if ($type eq "Excl") {
		my @vlist = $defs->vlist($param);
		#print STDERR "DEBUG> $param ($type) :",join(",",@vlist),"\n";
		push (@first_values,[@vlist]);
	    } else {
#			push (@first_values,'');
		push (@first_values,$value);
	    }
	} else { 
	    if ($type eq "List" && defined $defs->vdef($param)) {
		$separator = $defs->separator($param);
		$vdef = join ($separator, @{ $defs->vdef($param) });
		if ($value ne "" && $value != $vdef) { 
		    print $fh "\n#---------------------------------------------------------\n";
		    print $fh "# $prompt\n";
		    print $fh "\$$cmd","->$param($value);\n"; 
		    $summary{$cmd}{$param} = $value;
		}
	    } elsif (grep {$_ eq $param} @{ $in_param{$cmd} } ) {
		$prompt{$cmd,$param} = $prompt;
	    } elsif ($type eq "Sequence" || $type eq "Infile") {
		if ($value ne "") {
		    $varname = $cmd . "_" . $param;
		    print $fh "\n#---------------------------------------------------------\n";
		    print $fh "# $prompt\n";
		    print $fh "my \$$varname = \"";
		    open (INPUT,"$dir/$value") || die "cannot open $dir/$value:$!";
		    $content = join ("", <INPUT>);
		    close INPUT;
		    $content =~ s/\"/\\\"/g;
		    $content =~ s/\@/\\@/g; 
		    print $fh $content; 
		    print $fh "\";\n"; 
		    print $fh "\$$cmd","->$param(\$$varname);\n"; 
		    $summary{$cmd}{$param} = $value;
		}
		if ($ismandatory && (! $hasprecond) && $vdef eq "") {
		    push (@first_params,$param);
		    push (@first_params_cmds, $cmd);
		    push (@first_params_types,$type);
		    push (@first_prompts,$prompt);
		    push (@first_values,"$dir/$value");
		}
	    } elsif ($type eq "Excl" && $value ne "" ) {
		print $fh "\n#---------------------------------------------------------\n";
		print $fh "# $prompt\n";
		print $fh "\$$cmd","->$param(\"$value\");\n"; 
		$summary{$cmd}{$param} = $value;
	    } else {
		if ($value ne "" && $value ne $vdef) { 
		    #print STDERR "DEBUG> print_args $cmd args: $param = $value vdef=$vdef\n";
		    print $fh "\n#---------------------------------------------------------\n";
		    print $fh "# $prompt\n";
		    if ($type eq "String") {
			print $fh "\$$cmd","->$param(\"$value\");\n"; 
		    } else {
			print $fh "\$$cmd","->$param($value);\n"; 
		    }
		    if ($type ne "Paragraph") {
			$summary{$cmd}{$param} = $value;
		    }
		}
	    }
        }
    } 
}


sub print_headers { 
    print MACRO "#! /local/bin/perl

#-------------------------------------------------------------
# macro to be used with Pise/bioperl module
# See http://www-alt.pasteur.fr/~letondal/Pise/#pisebioperl
# (requires bioperl 1.2 with bioperl-run, or else a Pise distribution 
# and setting: use lib /local/gensoft/lib/Pise/5.a)
#-------------------------------------------------------------

use lib \"/local/gensoft/lib/Pise/5.a\";
use Bio::Tools::Run::AnalysisFactory::Pise;

my \$PISE_SERVER = \"$CGI_URL\" . \"/\"; 
my \$email = (! defined \$email)? \$ENV{'USER'} : \$email;   #  your email # 
my \$factory = new Bio::Tools::Run::AnalysisFactory::Pise(-remote => \$PISE_SERVER,
                                                          -email => \$email);
";

};

sub print_init { 
    my $cmd = $_[0];
    print MACRO "
#============================== $cmd ==============================


\$$cmd = \$factory->program('$cmd');

";
}

sub print_run { 
    my $cmd = $_[0];
    my $cmdjob = $cmd . "_job";
    print MACRO "\n\$$cmdjob = \$$cmd->run;\n";
    print MACRO "\$jobid{$cmd} = \$$cmdjob->jobid;\n";
    print MACRO "if (\$$cmdjob->error) {\n";
    print MACRO "    print STDERR \$$cmdjob->error_message,\"\\n\";\n";
    print MACRO "    exit -1;\n";
    print MACRO "}\n";
    print MACRO "if (! \$$cmdjob->terminated(\$jobid)) {\n";
    print MACRO "\t\$$cmdjob->results_type(\"attachment\");\n";
    print MACRO "\twhile (! \$$cmdjob->terminated(\$jobid)) {\n";
    print MACRO "\t\tsleep 100;\n";
    print MACRO "\t}\n";
    print MACRO "}\n";
    print MACRO "# END OF $cmd\n";
}

sub print_output {
    my $cmd = $_[0];
    my $cmdjob = $cmd . "_job";
#    print MACRO "print STDERR \$$cmdjob->stdout;\n";
}

sub save_form {
    my $command = $_[0];
    my $param;
    my $paramdata;
    my $type;

    stat( "$MACROS_DIR/$command" );
    if ( ! -e _ ) {
	mkdir ("$MACROS_DIR/$command", 0770 )
	    || die ("Cannot create directory $MACROS_DIR/$command : $!") ;
	chmod 0770, "$MACROS_DIR/$command" ;
    }
    stat( "$MACROS_DIR/$scratch_dir" );
    if ( ! -e _ ) {
	mkdir ("$MACROS_DIR/$scratch_dir", 0770 )
	    || die ("Cannot create directory $MACROS_DIR/$scratch_dir: $!") ;
	chmod 0770, "$MACROS_DIR/$scratch_dir" ;
    }

    print_form_macro($command);

    open(FORM,"> $tmp_dir/$scratch_dir/macro.html") || die "cannot open $dir/macro.html: $!";

    my $form = new CGI;
    print FORM $form->start_html("Form to reuse your procedure later.");
    print FORM $form->h1("Form to reuse your procedure later.");
    print FORM "<I>Save this in your bookmarks!!</I>\n";
    print FORM "<BR></BR><I>Commands that will be executed on these data:</I> ", join(", ",@commands),".\n";
    my $action = "$MACROS_URL/$scratch_dir/macro.pl";
    print FORM $form->start_multipart_form(-method => "POST",
					   -action=> $action,
					   -encoding=> &CGI::MULTIPART);
    my $tmp_email = $email;
    $tmp_email =~ s/\\//;
#    print STDERR "tmp_email: $tmp_email\n";
#    print FORM $form->textfield(-name=>'email',
#                             -default=> $tmp_email,
#                             -size=>50);
    print FORM "<INPUT TYPE=\"text\" NAME=\"email\" VALUE=\"$tmp_email\" SIZE=50>\n";
    my $cmd = $commands[0];
    $i = 0;
    my %done;
    foreach $param (@first_params) {
	my $prompt = $first_prompts[$i];
	my $value = $first_values[$i];
	my $cmd = $first_params_cmds[$i];
	$type = $first_params_types[$i];
	if ($done{$param,$cmd}) {
	    next;
	}
	$done{$param,$cmd} = 1;
	#print STDERR "DEBUG> save_form $param ($cmd)\n";
	if ($type eq "InFile" || $type eq "Sequence") { 
#	    $file = $value;
#	    open (INPUT,"$file") || die "cannot open $file:$!";
#	    $content = join ("", <INPUT>);
#	    close INPUT;
#	    $content =~ s/\"/\\\"/g;
#	    $content =~ s/\@/\\@/g; 
#	    $paramdata = $param . "_data";
#	    print FORM "<BR></BR><I>$cmd</I> $prompt:<BR></BR>",
#	    $form->textarea( -name=> $paramdata,
#			    -default=>$content,
#			    -rows=> 20,
#			    -columns=> 50,
#			    -linebreak=>'true');
	    print FORM "<BR></BR><I>$cmd</I> $prompt:<BR></BR>\n";
	    print FORM $form->filefield(-name=>$param,
					-size=>50), "\n";

	} elsif ($type eq "Excl") {
	    print FORM "<BR></BR>\n";
	    my @list = @{ $first_values[$i] };
	    my @values;
	    my %labels;
	    my $j = 0;
            my $prompt_size = 0;
	    while ($j < $#list) {
		if (!( $j % 2)) {
		    push (@values,$list[$j]);
		} else {
		    $labels{$list[$j-1]} = $list[$j];
		    $prompt_size += length($list[$j]);
		}
		$j++;
	    }
	    $labels{$list[$j-1]} = $list[$j];
	    print FORM "<BR></BR><I>$cmd</I> $prompt<BR></BR>";
	    if ( $#values > 6 || $prompt_size > 70) {
		print FORM $form->popup_menu(-name => $param,
                                             -values => [@values],
                                             -labels => \%labels);
	    } else {
		print FORM $form->radio_group(-name => $param,
					      -values => [@values],
					      -labels => \%labels);
	    }
	} else {
	    print FORM "<BR></BR>\n";
	    print FORM $form->textfield(-name=> $param,
					-default=> $value,
					-size=>50);
	    print FORM "<I>$cmd</I> $prompt:<BR></BR>";
	}
	$i++;
    }
    print FORM "<BR></BR>\n";
    print FORM $form->reset;
    print FORM $form->submit(-value=> "Submit the whole procedure.");
    print FORM $form->end_form;

    print FORM $form->hr;

    foreach my $cmd (@commands) {
	eval ("use $cmd;");
	my $defs = $cmd->new;
	my @params = keys %{ $summary{$cmd}};
	next if ($#params < 0);

	print FORM $form->h3("Parameters for $cmd");
	print FORM "<TABLE border=1>\n";
	

	foreach $param (keys %{ $summary{$cmd} } ) {
	    $prompt = $defs->prompt($param) ;
	    $value = $summary{$cmd}{$param};
	    if ($defs->type($param) eq "Switch") {
		if ($value == 1) {
		    $value="True";
		} elsif ($value == 0) {
		    $value="False";
		}
	    }
	    if ($prompt) {
		print FORM "<TR><TD>$prompt</TD><TD>$value</TD></TR>\n";
	    }
	}

	print FORM "\n</TABLE>\n";
    }
    print FORM $form->end_html, "\n";

    close FORM;
}

sub print_form_macro {
    my ($command) = @_ ;

    open(FORMMACRO, "> $MACROS_DIR/$scratch_dir/macro.pl") || die "cannot open $MACROS_DIR/$scratch_dir/macro.pl: $!";

    print FORMMACRO "\#\! /local/bin/perl
\$ENV{'PATH'}=\"/usr/bin:/bin:/usr/local/bin:/usr/sbin\";
require \"/local/gensoft/lib/Pise/5.a/lib/web.pl\";
use lib \"/local/gensoft/lib/Pise/5.a\";
use CGI;
use Bio::Tools::Run::AnalysisFactory::Pise;

my \$input = new CGI;
my \$email=\$input->param('email');
\$email =~ s/\\\\//;
my \$PISE_SERVER = \"$CGI_URL\" . \"/\"; 
my \$factory = new Bio::Tools::Run::AnalysisFactory::Pise(-remote => \$PISE_SERVER,
                                                          -email => \$email);

";
    my $i = 0;
    foreach $param (@first_params) {
	$type = $first_params_types[$i];
	if ($type eq "InFile" || $type eq "Sequence") {
	    #$paramdata=$param . "_data";
	    #print FORMMACRO "my \$$param=\$input->param('$paramdata');\n";
            print FORMMACRO "my \$$param=upload_file($param,\$input->param('$param'));\n";
	} else {
	    print FORMMACRO "my \$$param=\$input->param('$param');\n";
	}
	$i++;
    }
    print FORMMACRO "
sleep 1;
my \$t = time ;
my \$scratch_nb = \"\$\$\" . \"\$t\";
my \$scratch_dir = \"$MACROS_EXEC/\$scratch_nb\" ;
my \$scratch_url = \"$MACROS_EXEC_URL/\$scratch_nb\" ;
stat( \"$MACROS_EXEC\" );
if ( \! -e _ ) {
     mkdir (\"$MACROS_EXEC\", 0770 )
        || &panic(\"Cannot create directory $MACROS_EXEC: \$\!\") ;
     chmod 0770, \"$MACROS_EXEC\" ;
     system(\"touch $MACROS_EXEC/index.html\");
}
mkdir \"\$scratch_dir\", 0770
     || &panic(\"Cannot create directory  \$scratch_dir: \$\!\") ;
chmod 0770, \"\$scratch_dir\" ;
chdir \"\$scratch_dir\" || die \"can\'t cd to \$scratch_dir: \$!\" ;

print \$input->header(-type=>'text/html',-expires=>'+0');
print \$input->start_html(\"Procedure Results\");
print \$input->h1(\"Procedure Results.\");
";
    my $line;


    my $first=1;
    my $first_input;
    my $piped_file;
    my $paramdata;
    my $prompt;
    my $type;
    foreach my $cmd (@commands) {
	#print STDERR "DEBUG  print_form_macro cmd: $cmd\n";
	my $cmdjob = $cmd . "_job";
	print FORMMACRO "
#============================== $cmd ==============================

\$$cmd = \$factory->program('$cmd');

";

	print_args($dir{$cmd},$cmd, 0 , FORMMACRO);
	foreach my $in ( @{ $in_param{$cmd} } ) {
	    ($prev_cmd,$piped_file) = split(",",$pipe{$cmd,$in});
	    $prev_command{$cmd} = $prev_cmd;
	    $prompt = $prompt{$cmd,$in};
	    $type = $in_piped_file_type{$cmd,$in};
#	    print STDERR "DEBUG> print_macro: $cmd in=$in type=$type\n";
	    print FORMMACRO "\n#---------------------------------------------------------\n";
	    print FORMMACRO "# $prompt\n";
            if ($data{$cmd,$in}) {
		print FORMMACRO "my \$saved_file = \$$prev_cmd","_job->save(\$$prev_cmd","_job->lookup_piped_file('$type'));\n";
		print FORMMACRO "\$$cmd","->$in(\$saved_file);\n";
	    } else {
		print FORMMACRO "\$$cmd","->$in(\$$prev_cmd","_job->fh(\$$prev_cmd","_job->lookup_piped_file('$type')));\n";
	    }

	}
	print FORMMACRO "\n\$$cmdjob = \$$cmd->run;\n";
	print FORMMACRO "\$jobid{$cmd} = \$$cmdjob->jobid;\n";
	print FORMMACRO "if (\$$cmdjob->error) {\n";
	print FORMMACRO "   print \$input->h3(\"($cmd) \" . \$$cmd","_job->error_message);\n";
	print FORMMACRO "   print \$input->end_html;\n";
	print FORMMACRO "   exit;\n";
	print FORMMACRO "}\n";
	print FORMMACRO "if (! \$$cmdjob->terminated(\$jobid)) {\n";
	print FORMMACRO "\t\$$cmdjob->results_type(\"attachment\");\n";
	print FORMMACRO "\twhile (! \$$cmdjob->terminated(\$jobid)) {\n";
	print FORMMACRO "\t\tsleep 100;\n";
	print FORMMACRO "\t}\n";
	print FORMMACRO "}\n";
	print FORMMACRO "\@{ \$results_files{$cmd} } = \$$cmdjob->get_results;\n";
	print FORMMACRO "# END OF $cmd\n";
    }

    print FORMMACRO "my \$filename;\n";
    print FORMMACRO "foreach my \$cmd (",join(",",@commands),") {\n";
    print FORMMACRO "   if (defined \$results_files{\$cmd}) {\n";
    print FORMMACRO "     my \@cmd_results = \@{ \$results_files{\$cmd} };\n";
    print FORMMACRO "     print \$input->hr;\n";
    print FORMMACRO "     print \"\\n\";\n";
    print FORMMACRO "     print \$input->h4(\"\$cmd results\");\n";
    print FORMMACRO "     print \"\\n\";\n";
    print FORMMACRO "     \$jobid = \$jobid{\$cmd};\n";
    print FORMMACRO "     print \$input->a({href=>\"\$jobid\"},\"Results page\");\n";
    print FORMMACRO "     foreach my \$result_file (\@cmd_results) {\n";
    print FORMMACRO "       print \"\\n\";\n";
    print FORMMACRO "       print \"<BR></BR>\";\n";
    print FORMMACRO "       (\$filename = \$result_file) =~ s/.+\\/(.+)/\$1/;\n";
    print FORMMACRO "       print \$input->a({href=>\"\$result_file\"},\"\$filename\");\n";
    print FORMMACRO "     }\n";
    print FORMMACRO "   }\n";
    print FORMMACRO "}\n";
    print FORMMACRO "\n\nprint \$input->end_html;\n";

    print_upload_file_sub();

    close FORMMACRO;

    system ("chmod 770 $MACROS_DIR/$scratch_dir/macro.pl");

}


sub print_summary {
    my $prompt;
    my $value;
    my @params;

    foreach my $cmd (@commands) {
	eval ("use $cmd;");
	my $defs = $cmd->new;

	@params = keys %{ $summary{$cmd}};
	next if ($#params < 0);

	print $input->h3("Parameters for $cmd");
	print "<TABLE border=1>\n";
	

	foreach $param (keys %{ $summary{$cmd} } ) {
	    $prompt = $defs->prompt($param) ;
	    $value = $summary{$cmd}{$param};
	    if ($defs->type($param) eq "Switch") {
		if ($value == 1) {
		    $value="True";
		} elsif ($value == 0) {
		    $value="False";
		}
	    }
	    if ($prompt) {
		print "<TR><TD>$prompt</TD><TD>$value</TD></TR>\n";
	    }
	}

	print "\n</TABLE>\n";
    }
}

sub print_upload_file_sub {

    print FORMMACRO "

sub upload_file { 
    my (\$param, \$filename) = \@_ ;

    my \$fh = \$filename;


    #print STDERR \"DEBUG> webmacro.pl upload_file: \$param filename=\$filename\\n\";

    if (\$filename =~ /\\\\/ ) {
	\$filename =~ s|.*[:/\\\\](.*)|\$1| ;
	print STDERR \"DEBUG> webmacro.pl upload_file \$param PC Windows filename (2) = \$filename\\n\";
    } 

    if (\$filename =~ /^\\S*.*\\s+.*\\S*\$/ ) {
	print STDERR \"DEBUG> webmacro.pl upload_file \$param filename containing space(s): \$filename\\n\";
	\$filename =~ s/\\s+//g ;
    } 

    my \$tmpdir = \"/tmp\";
    my \$tmpfile = `basename \$filename`;
    chomp(\$tmpfile);
    \$tmpfile = \"\$tmpdir/\$tmpfile\";

    #print STDERR \"DEBUG> webmacro.pl upload_file \$param tmpfile: \$tmpfile\\n\";

    open (TMPFILE,\"> \$tmpfile\") || die \"cannot open \$tmpfile: \$!\";
    my \$content;
    my \$data;
    # book on CGI.pm, Lincoln Stein, p154
    while (read(\$fh,\$data,1024)) {
	\$content .= \$data;
    } 
    my \$eol = \"\\n\";
    \$content =~ s/\\015\\012/\$eol/og;
    \$content =~ s/\\015/\$eol/og;
    print TMPFILE \$content;
    close TMPFILE; 

    return \$tmpfile;
}

";

}
