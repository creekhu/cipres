#
# TODO : 
#

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";

package Maker;

$command=$ARGV[0];
$VERSION=$ENV{'VERSION'};
$PISEDIR=($ENV{'PISEDIR'})? $ENV{'PISEDIR'} : "/local/gensoft/lib/Pise";
$PERLDEFDIR=($ENV{'PERLDEFDIR'})? $ENV{'PERLDEFDIR'} : "/local/gensoft/lib/Pise/5.a/PerlDef";
require "$PISEDIR/Maker/make-tcl-utils.pl";
if (defined $ARGV[1]) {
    $required=$ARGV[1];
    require "$required";
}
eval ("use $command;");
$defs = $command->new;

&print_headers;

&print_procedures($defs,$command);
$top_frame=&print_top_frame($command,"advanced");
&print_quit_submit($command);
&do_parameters ($defs,$top_frame, 'top', $defs->top_parameters);
&print_jobs_frame($command);

&print_footers($top_frame);

sub do_parameters {
    my ($defs, $frame, $paragraph, @parameters_list) = @_ ;
    my $param;
    foreach $param (@parameters_list) {
	next if ($defs->ishidden($param));
	if ($defs->type($param) eq "Paragraph") {

	    print_one_param($defs,
			    $command,
			    "advanced", 
			    $param,
			    $defs->type($param),
	                    $paragraph,
			    $frame);
	    $string = $defs->prompt($param);

#	    foreach $p ( @{ $defs->vlist($param) } ) {
	    foreach $p ( $defs->vlist($param) ) {
		push @{ $parameters_todo{$param} }, $p;
	    }
            $paragraph_frame = "$param_frame" . "_frame";
	    &do_parameters($defs,
			   $paragraph_frame, 
			   $param, 
			   @{$parameters_todo{$param}} 
			   );

            print "\n}\n# end proc for paragraph $paragraph\n\n";
       } else {
	    print_one_param($defs,
			    $command,
			    "advanced", 
			    $param,
			    $defs->type($param),
	                    $paragraph,
			    $frame);
       }

    }

}


1;


