#
# close service
# 

# put here the names of the program you want to stop
# (e.g: clustalw, blast2, ...)
#@programs = ( 'qr2', 'flinqs', 'satellites' );
@programs = ( 'alistat', 'seqstat', 'grailclnt', 'gibbs', 'gibbs_scan', 'seqboot', 'complex', 'hmmt', 'prodom', 'hmmb', 'mse', 'hmm_convert', 'qr2', 'flinqs', 'satellites' ,  'seqinfo', 'pestfind', 'readnexus' );

# list of programs using databanks (might be out-of-date)
@programs_with_databanks = ('golden', 'blast2', 'blimps', 'blimps_matrix', 'fasta', 'hmmsearch', 'gibbs_scan', 'pftools', 'phiblast', 'psiblast', 'wublast2');
# set to 1 if you want to close all services using databanks
$all_programs_with_databanks = 0;

# set to 1 if you want to close all services
$all = 0;

sub service_down {
  my $program = $_[0];

  my $date = localtime;
  my $msg;

  my $remote = $ENV{'REMOTE_HOST'};
  if (! $remote) {
      $remote = $ENV{'REMOTE_ADDR'};
  }
  if ($remote =~ /.sis.pasteur.fr/) {
      return 0;
  }

  if ( $all ) {
    print STDERR "[$date] server not available for now ($program). \n";
    $msg = information_message('down');
    if ($msg) {
	print $msg, "\n";
    }
    return 1;
  }
  
  if ( $all_programs_with_databanks ) {
     if ( grep (/^$program$/i, @programs_with_databanks)) { 
	 print STDERR "[$date] program $program not available for now (db).\n";
	 $msg = information_message('db');
	 if ($msg) {
	     print $msg, "\n";
	 }
	 return 1;
     }
  }
  
  if ($program) {
    if ( grep (/^$program$/, @programs)) {
      print STDERR "[$date] $program not available for now.\n";
      return 1;
    }
  } 

  return 0;
}

1;
