#! /local/bin/perl

# essais de CGI.pm

# upload 
# r�pertoires temporaires
# textarea
# List

use CGI;
use POSIX;
my $query = new CGI;
print $query->header;
print $query->start_html('CGI.pm Tests');
print $query->h1('CGI.pm Tests');
text_area();

sub files {
    $filename = $query->param('uploaded_file');
    open (TMPFILE,"> /bioweb/htdocs/seqanal/tmp/test/$filename") || die "cannot open $filename: $!";
    my @content = <$filename>;
    print TMPFILE @content;
    close TMPFILE;
}

sub text_area {
#    $text = $query->param('text_area');
    my $text = join ("", split ("\r", $query->param('text_area')));
    my $tmpfile = POSIX::tmpnam;
    print "<BR>Tmpfile: $tmpfile";
    open (TMP, "> $tmpfile");
    print TMP $text;
    close TMP;
    print "<BR>Texte:<BR>$text";
}

sub choices {
    @choices = $query->param('multiple_choice');
    print "Liste:<BR>",join("\n",@choices);
}

print $query->end_html;
