#
# TODO: comment line/separator in Excl menus
#
package PiseParser;

$verbose  = 0;
$debug = 0;
$paragraph_level=-1;

sub new {
    
    $PISEDIR = $_[1];
    $VERSION = $_[2];
    if ($_[3]) {
	$verbose = $_[3];
    }
    return bless {};
}

sub characters {
    my ($self, $element) = @_; 

    chomp ($element->{Data});
    if ($_in_title) {
	$title .= $element->{Data};
    } elsif ($_in_command) {
	$command = $element->{Data};
	$iscommand{$command} = 1;
    } elsif ($_in_description) {
	$description .= $element->{Data};
    } elsif ($_in_doclink) {
	$doclink .= $element->{Data};
    } elsif ($_in_authors) {
	$authors .= $element->{Data};
    } elsif ($_in_pipetype) {
	$pipetype = $element->{Data};
    } elsif ($_in_name) {
	$name = $element->{Data};
	$type{$name} = $type;
	$ismandatory{$name} = $ismandatory;
	$iscommand{$name} = $iscommand;
	$ishidden{$name} = $ishidden;
	$isstandout{$name} = $isstandout;
	$issimple{$name} = $issimple;
	$isclean{$name} = $isclean;
    } elsif ($_in_value) {
	$value .= $element->{Data};
	if ($_in_vdef) {
	    $vdef .= $element->{Data};
#	    print STDERR "DEBUG> (1) vdef ($name) = $vdef\n";
	}
    } elsif ($_in_parametername) {
	push ( @{ $withpipe{$name}{$pipetype}}, $element->{Data} );
    } elsif ($_in_label) {
	$label .= $element->{Data};
#	push (@{ $vlist{$name} }, $element->{Data});
#	print STDERR "DEBUG> ($name) label = ",$element->{Data},"\n";
    } elsif ($_in_message) {
	$message .= $element->{Data};
    } elsif ($_in_language) {
	$language = $element->{Data};
    } elsif ($_in_code) {
	$code .= $element->{Data};
    } elsif ($_in_filenames) {
	$filenames .= $element->{Data};
    } elsif ($_in_group) {
	if ($type{$name} eq "Paragraph") {
	    my $paragraph_name = $paragraph_name[$paragraph_level];
	    $group{$paragraph_name} = $element->{Data};
	} else {
	    $group{$name} = $element->{Data};
	}
    } elsif ($_in_size) {
	$size{$name} = $element->{Data};
    } elsif ($_in_prompt) {
	$prompt{$name} .= $element->{Data};
    } elsif ($_in_separator) {
	$separator{$name} = $element->{Data};
    } elsif ($_in_paramfile) {
	$paramfile{$name} = $element->{Data};
    } elsif ($_in_scalemin && ! ($_in_code || $_in_language)) {
	$scalemin{$name} = $element->{Data};
    } elsif ($_in_scalemax && ! ($_in_code || $_in_language)) {
	$scalemax{$name} = $element->{Data};
#	print STDERR "DEBUG> PiseParser scalemax{$name} = $scalemax{$name} ($_in_code $_in_language)\n";
    } elsif ($_in_scaleinc) {
	$scaleinc{$name} = $element->{Data};
    } elsif ($_in_info) {
	$info{$name} = $element->{Data};
    } elsif ($_in_category) {
	push (@categories , $element->{Data});
    } elsif ($_in_reference) {
	push(@references, $element->{Data});
    } 
}

sub comment {
    my ($self, $element) = @_; 
}

sub start_element {
    my ($self, $element) = @_;
#    print STDERR "\nstart element: ",$element->{Name},"\n" if ($debug);

    my %xml_attributes = %{ $element->{Attributes} };

#    print STDERR "start: ismandatory: $ismandatory issimple:$issimple ishidden:$ishidden\n";
    if ($element->{Name} eq "pise") {
	$_in_pise=1;
	$error = 0;
	$error_message = "";
    } elsif ($element->{Name} eq "head") {
	$_in_head = 1;
    } elsif ($element->{Name} eq "command") {
	$_in_command = 1;
    } elsif ($element->{Name} eq "parameters") {
	$_in_parameters = 1;
    } elsif ($element->{Name} eq "title") {
	$_in_title = 1;
    } elsif ($element->{Name} eq "description") {
	$_in_description = 1;
    } elsif ($element->{Name} eq "category") {
	$_in_category = 1;
    } elsif ($element->{Name} eq "doclink") {
	$_in_doclink = 1;
    } elsif ($element->{Name} eq "authors") {
	$_in_authors = 1;
    } elsif ($element->{Name} eq "parameter") {
	$type = $xml_attributes{type};
	$ismandatory = $xml_attributes{ismandatory};
	$iscommand = $xml_attributes{iscommand};
	$ishidden = $xml_attributes{ishidden};
	$isstandout = $xml_attributes{isstandout};
	$issimple = $xml_attributes{issimple};
	$isclean = $xml_attributes{isclean};
	$_in_parameter = 1;
    } elsif ($element->{Name} eq "paragraph") {
	$_in_paragraph = 1;
	$paragraph_level++;
    } elsif ($element->{Name} eq "name") {
	$_in_name = 1;
    } elsif ($element->{Name} eq "attributes") {
	$_in_attributes = 1;
#    } elsif ($element->{Name} eq "attribute") {
#	$_in_attribute = 1;
    } elsif ($element->{Name} eq "precond") {
	$_in_precond = 1;
    } elsif ($element->{Name} eq "group") {
	$_in_group = 1;
    } elsif ($element->{Name} eq "prompt") {
	$_in_prompt = 1;
    } elsif ($element->{Name} eq "format") {
	$_in_format = 1;
    } elsif ($element->{Name} eq "vdef") {
	$_in_vdef = 1;
    } elsif ($element->{Name} eq "vlist") {
	$_in_vlist = 1;
    } elsif ($element->{Name} eq "flist") {
	$_in_flist = 1;
    } elsif ($element->{Name} eq "comment") {
	$_in_comment = 1;
    } elsif ($element->{Name} eq "seqfmt") {
	$_in_seqfmt = 1;
    } elsif ($element->{Name} eq "ctrls") {
	$_in_ctrls = 1;
    } elsif ($element->{Name} eq "ctrl") {
	$_in_ctrl = 1;
    } elsif ($element->{Name} eq "paramfile") {
	$_in_paramfile = 1;
    } elsif ($element->{Name} eq "filenames") {
	$_in_filenames = 1;
    } elsif ($element->{Name} eq "scalemin") {
	$_in_scalemin = 1;
    } elsif ($element->{Name} eq "scalemax") {
	$_in_scalemax = 1;
    } elsif ($element->{Name} eq "scaleinc") {
	$_in_scaleinc = 1;
    } elsif ($element->{Name} eq "separator") {
	$_in_separator = 1;
    } elsif ($element->{Name} eq "size") {
	$_in_size = 1;
    } elsif ($element->{Name} eq "pipe") {
	$_in_pipe = 1;
    } elsif ($element->{Name} eq "withpipe") {
	$_in_withpipe = 1;
    } elsif ($element->{Name} eq "value") {
	$_in_value = 1;
    } elsif ($element->{Name} eq "boolean") {
	$_in_boolean = 1;
    } elsif ($element->{Name} eq "parametername") {
	$_in_parametername = 1;
    } elsif ($element->{Name} eq "message") {
	$_in_message = 1;
    } elsif ($element->{Name} eq "language") {
	$_in_language = 1;
    } elsif ($element->{Name} eq "code") {
	$_in_code = 1;
    } elsif ($element->{Name} eq "label") {
	$_in_label = 1;
    } elsif ($element->{Name} eq "pipetype") {
	$_in_pipetype = 1;
    } elsif ($element->{Name} eq "info") {
	$_in_info = 1;
    } elsif ($element->{Name} eq "reference") {
	$_in_reference = 1;
    }
}

sub end_element {
    my ($self, $element) = @_;
    print STDERR "\nend element: ",$element->{Name},"\n" if ($debug);
    if ($element->{Name} eq "pise") {
	print_perl();
	$_in_pise = 0;
    } elsif ($element->{Name} eq "head") {
	$_in_head = 0;
    } elsif ($element->{Name} eq "command") {
	$_in_command = 0;
    } elsif ($element->{Name} eq "parameters") {
	$_in_parameters = 0;
    } elsif ($element->{Name} eq "title") {
	$_in_title = 0;
    } elsif ($element->{Name} eq "description") {
	$_in_description = 0;
    } elsif ($element->{Name} eq "category") {
	$_in_category = 0;
    } elsif ($element->{Name} eq "doclink") {
	$_in_doclink = 0;
    } elsif ($element->{Name} eq "authors") {
	$_in_authors = 0;
    } elsif ($element->{Name} eq "parameter") {
	if ($_in_paragraph) {
#	    push (@parameters,$name);
	    my $paragraph_name = $paragraph_name[$paragraph_level];
	    push (@{ $vlist{$paragraph_name} }, $name);
	}
	if (! (defined $group{$name})) {
	    if ($_in_paragraph) {
		my $paragraph_name = $paragraph_name[$paragraph_level];
		$group{$name} = $group{$paragraph_name};
	    }
#	    print STDERR "DEBUG> group  name $name:",$group{$name}, " paragraph $paragraph_name: ", $group{$paragraph_name},"\n";
	}
	if (! (defined $precond{$name})) {
	    if ($_in_paragraph) {
		my $paragraph_name = $paragraph_name[$paragraph_level];
		$precond{$name} = $precond{$paragraph_name};
	    }
#	    print STDERR "DEBUG> group  name $name:",$group{$name}, " paragraph $paragraph_name: ", $group{$paragraph_name},"\n";
	}
	$type = "";
	$_in_parameter = 0;
    } elsif ($element->{Name} eq "paragraph") {
#	@{ $vlist{$paragraph_name} } = @parameters;
	my $paragraph_name = $paragraph_name[$paragraph_level];
#	print STDERR "DEBUG> PiseParser: $paragraph_name: ",join(",",@{ $vlist{$paragraph_name} }),"\n";
#	undef @parameters;
	undef $paragraph_name[$paragraph_level];
	$_in_paragraph = 0;
	$paragraph_level--;
    } elsif ($element->{Name} eq "name") {
	if ($type{$name} eq "Paragraph") {
	    $paragraph_name[$paragraph_level] = $name;
	    if ($paragraph_level <= 0) {
		push (@top_parameters,$name);
	    } else {
		my $paragraph_name = $paragraph_name[$paragraph_level - 1];
		push (@{ $vlist{$paragraph_name} }, $name);
	    }
	} elsif (! $_in_paragraph) {
	    push (@top_parameters,$name);
	}
	push (@parameters_order,$name);
	$_in_name = 0;
    } elsif ($element->{Name} eq "attributes") {
	$_in_attributes = 0;
#    } elsif ($element->{Name} eq "attribute") {
#	undef @list;
#	undef %list;
    } elsif ($element->{Name} eq "precond") {
	$_in_precond = 0;
    } elsif ($element->{Name} eq "group") {
	$_in_group = 0;
    } elsif ($element->{Name} eq "prompt") {
	$_in_prompt = 0;
    } elsif ($element->{Name} eq "format") {
	$_in_format = 0;
    } elsif ($element->{Name} eq "vdef") {
	if ($type{$name} ne "List") {
	    $vdef{$name} = $vdef;
#	    print STDERR "DEBUG> (2) vdef  ($name) = $vdef\n";
	}
	$vdef = "";
	$_in_vdef = 0;
    } elsif ($element->{Name} eq "vlist") {
	$_in_vlist = 0;
    } elsif ($element->{Name} eq "flist") {
	$_in_flist = 0;
    } elsif ($element->{Name} eq "comment") {
	$_in_comment = 0;
    } elsif ($element->{Name} eq "seqfmt") {
	$_in_seqfmt = 0;
    } elsif ($element->{Name} eq "ctrls") {
	$_in_ctrls = 0;
    } elsif ($element->{Name} eq "ctrl") {
	$_in_ctrl = 0;
    } elsif ($element->{Name} eq "paramfile") {
	$_in_paramfile = 0;
    } elsif ($element->{Name} eq "filenames") {
	$filenames{$name} = $filenames;
	$filenames = "";
	$_in_filenames = 0;
    } elsif ($element->{Name} eq "scalemin") {
	$_in_scalemin = 0;
    } elsif ($element->{Name} eq "scalemax") {
	$_in_scalemax = 0;
    } elsif ($element->{Name} eq "scaleinc") {
	$_in_scaleinc = 0;
    } elsif ($element->{Name} eq "separator") {
	$_in_separator = 0;
    } elsif ($element->{Name} eq "size") {
	$_in_size = 0;
    } elsif ($element->{Name} eq "pipe") {
	$_in_pipe = 0;
    } elsif ($element->{Name} eq "withpipe") {
	$_in_withpipe = 0;
    } elsif ($element->{Name} eq "value") {
	if ($_in_seqfmt) {
	    push (@{$seqfmt{$name}}, $value);
	} elsif ($_in_vlist) {
	    push (@{ $vlist{$name} }, $value);
#	    print STDERR "DEBUG> (3) value ($name) = $value\n";
	} elsif ($_in_flist) {
	    $flist_value = $value;
	} elsif ($_in_vdef && $type{$name} eq "List") {
	    push (@{ $vdef{$name} }, $value);
#	    print STDERR "DEBUG> (3) vdef  ($name) = $value\n";
	} elsif ($_in_comment) {
	    push (@{ $comment{$name} }, $value);
	}
	$value = "";
	$_in_value = 0;
    } elsif ($element->{Name} eq "boolean") {
	$_in_boolean = 0;
    } elsif ($element->{Name} eq "parametername") {
	$_in_parametername = 0;
    } elsif ($element->{Name} eq "message") {
	$last_message = $message;
	$message = "";
	$_in_message = 0;
    } elsif ($element->{Name} eq "language") {
	$_in_language = 0;
    } elsif ($element->{Name} eq "code") {
	if ($_in_format) {
	    $format{$name}{$language} = $code;
	}
	if ($_in_precond) {
	    $precond{$name}{$language} = $code;
	}
	if ($_in_flist) {
	    $flist{$name}{$flist_value} = $code;
	} 
	if ($_in_ctrl) {
	    $ctrl{$name}{$language}{$code} = $last_message;
	}
	if ($_in_scalemin) {
	    $scalemin{$name}{$language}{$code} = $code;
	}
	if ($_in_scalemax) {
	    $scalemax{$name}{$language}{$code} = $code;
	}
	if ($_in_pipe) {
	    $pipe{$name}{$pipetype}{$language} = $code;
	    $pipetype = "";
	}
	$code = "";
	$_in_code = 0;
    } elsif ($element->{Name} eq "label") {
	if ($_in_vlist) {
	    push (@{ $vlist{$name} }, $label);
#	    print STDERR "DEBUG> ($name) label = $label\n";
	}
	undef $label;
	$_in_label = 0;
    } elsif ($element->{Name} eq "pipetype") {
	$_in_pipetype = 0;
    } elsif ($element->{Name} eq "info") {
	$_in_info = 0;
    } elsif ($element->{Name} eq "reference") {
	$_in_reference = 0;
    }
}

sub print_perl {
    my $param;
    my $language;
    my $code;
    my $val;
    my $message;

    print "
# perl description of \"$command\" parameters (Version $VERSION)

package $command;
    
sub new {
    my \$proto = shift;
    my \$class = ref(\$proto) || \$proto;
    my \$self  = {};
    \$self->{COMMAND}   = \"$command\";
    \$self->{VERSION}   = \"$VERSION\";
    \$self->{TITLE}   = \"$title\";
";
    if ($description) {
        print "
    \$self->{DESCRIPTION}   = \"$description\";
";
    }

    if (defined $ENV{'OPT_EMAIL'}) {
        print "
    \$self->{OPT_EMAIL}   = ";
        print $ENV{'OPT_EMAIL'};
        print ";
";
    } else {
        print "
    \$self->{OPT_EMAIL}   = 0;
";
    }

    if (@categories) {
        print "
    \$self->{CATEGORIES}   =  [  
";
        foreach my $category (@categories) {
          print "
         \"$category\",
";
        }
        print "  ];
";
    }

    if ($authors) {
        print "
    \$self->{AUTHORS}   = \"$authors\";
";
    }

    if ($doclink) {
        print "
    \$self->{DOCLINK}   = \"$doclink\";
";
    }

    if (@references) {
        print "
    \$self->{REFERENCE}   = [
";
       foreach my $reference (@references) {
       
          $reference =~ s/\"/\\\"/g;
          $reference =~ s/\@/\\\@/g;
          print "
         \"$reference\",
";
       }
       print " ];
";
    }

    print "
    \$self->{_INTERFACE_STANDOUT} = undef;
    \$self->{_STANDOUT_FILE} = undef;
";

    $perloopise = "$PISEDIR/Maker/perloo.pm";

    print "
    \$self->{TOP_PARAMETERS}  = [ \n";
    if ( ! (grep {$_ eq $command} @top_parameters)) {
      print "\t\"$command\",\n";
    }
    foreach $param (@top_parameters) { 
      print "\t\"$param\",\n";
    }
    print "
    ];\n";

    print "
    \$self->{PARAMETERS_ORDER}  = [\n";

    if ( ! (grep {$_ eq $command} @top_parameters)) {
      print "\t\"$command\",\n";
    }
    foreach $param (@parameters_order) { 
      print "\t\"$param\",\n";
    }
    print "
    ];\n";

    print "
    \$self->{TYPE}  = {\n";
    if ( ! (grep {$_ eq $command} @top_parameters)) {
      print "\t\"$command\" => 'String',\n";
    }
    foreach $param (@parameters_order) { 
      print "\t\"$param\" => '", $type{$param},"',\n";
    }
    print "
    };\n";

    print "
    \$self->{FORMAT}  = {\n";
    foreach $param (@parameters_order) { 
      print "\t\"$param\" => {\n";
      foreach $language (keys %{ $format{$param}} ) {
          $code = $format{$param}{$language};
          print "\t\t\"$language\" => '$code',\n";
      }
      print "\t},\n";
    }

    if ( ! (grep {$_ eq $command} @parameters_order)) {
      print "\t\"$command\" => {\n";
      print "\t\t\"perl\" => '\"$command\"',\n";
      print "\t}\n";
    }

    print "
    };\n";

    print "
    \$self->{FILENAMES}  = {\n";
    foreach $param (@parameters_order) { 
      if (defined $filenames{$param}) {
          print "\t\"$param\" => '",$filenames{$param},"',\n";
      }
    }
    print "
    };\n";

    print "
    \$self->{SEQFMT}  = {\n";
    foreach $param (@parameters_order) { 
      if (defined $seqfmt{$param}) {
         print "\t\"$param\" => [",join(",", @{ $seqfmt{$param} }), "],\n";
      }
    }
    print "
    };\n";

    print "
    \$self->{GROUP}  = {\n";
    foreach $param (@parameters_order) { 
      if (defined $group{$param}) {
         print "\t\"$param\" => ", $group{$param},",\n";
      }
    }
    if ( ! (grep {$_ eq $command} @parameters_order)) {
      print "\t\"$command\" => 0\n"
    }
    print "
    };\n";

    my @sorted_by_group;
    print "
    \$self->{BY_GROUP_PARAMETERS}  = [\n";
    if ( ! (grep {$_ eq $command} @parameters_order)) {
        my @all_parameters;
        push(@all_parameters,@parameters_order);
        push(@all_parameters,$command);
        @sorted_by_group = sort by_group @all_parameters;
    } else {
        @sorted_by_group = sort by_group @parameters_order;
    }
    foreach $param (@sorted_by_group) {
	print "\t\"$param\",\n";
    }
    print "
    ];\n";

    print "
    \$self->{SIZE}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $size{$param}) {
           print "\t\"$param\" => ", $size{$param},",\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{ISHIDDEN}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $ishidden{$param}) {
        	print "\t\"$param\" => ", $ishidden{$param},",\n";
        } else {
        	print "\t\"$param\" => 0,\n";
        }
    }
    if ( ! (grep {$_ eq $command} @parameters_order)) {
      print "\t\"$command\" => 1\n"
    }
    print "
    };\n";

    print "
    \$self->{ISCOMMAND}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $iscommand{$param}) {
        	print "\t\"$param\" => ", $iscommand{$param},",\n";
        } else {
        	print "\t\"$param\" => 0,\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{ISMANDATORY}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $ismandatory{$param}) {
	     print "\t\"$param\" => ", $ismandatory{$param},",\n";
        } else {
        	print "\t\"$param\" => 0,\n";
        }

    }
    print "
    };\n";

    print "
    \$self->{PROMPT}  = {\n";
    foreach $param (@parameters_order) {
	print "\t\"$param\" => \"", $prompt{$param},"\",\n";
    }
    print "
    };\n";

    print "
    \$self->{ISSTANDOUT}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $isstandout{$param}) {
	      print "\t\"$param\" => ", $isstandout{$param},",\n";
        } else {
        	print "\t\"$param\" => 0,\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{VLIST}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $vlist{$param}) {
# print STDERR "DEBUG> (2) $param, vlist= ", join(",",@{ $vlist{$param} }),"\n";
           print "\n\t\"$param\" => [";
           foreach $val (@{ $vlist{$param} } ) {
               $val =~ s/\'/\\\'/g;
               print "'$val',";
           }
           print "],";
        }
    }
    print "
    };\n";

    print "
    \$self->{FLIST}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $flist{$param}) {
           print "\n\t\"$param\" => {\n";
           foreach $val (keys %{ $flist{$param} } ) {
               print "\t\t'$val' => '",$flist{$param}{$val},"',\n";
           }
           print "\n\t},";
        }
    }
    print "
    };\n";

    print "
    \$self->{SEPARATOR}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $separator{$param}) {
	    print "\t\"$param\" => \"", $separator{$param},"\",\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{VDEF}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $vdef{$param}) {
            if ($type{$param} eq "List") {
	       print "\t\"$param\" => [";
               foreach $val (@{ $vdef{$param} }) {
                   print "'$val',"
               }
	       print "],\n";
            } else {
               my $vdef = $vdef{$param};
#               $vdef =~ s/\"/\\\"/g;
	       print "\t\"$param\" => '$vdef',\n";
            }
        }
    }
    print "
    };\n";

    print "
    \$self->{PRECOND}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $precond{$param}) {
           print "\t\"$param\" => {\n";
           foreach $language (keys %{ $precond{$param}} ) {
              $code = $precond{$param}{$language};
               print "\t\t\"$language\" => '$code',\n";
           }
           print "\t},\n";
        } else {
               print "\t\"$param\" => { \"perl\" => '1' },\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{CTRL}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $ctrl{$param}) {
           print "\t\"$param\" => {\n";
           foreach $language (keys %{ $ctrl{$param}} ) {
              print "\t\t\"$language\" => {\n";
              foreach my $test (keys %{ $ctrl{$param}{$language} }) {
                 $message = $ctrl{$param}{$language}{$test};
                 print "\t\t\t\'$test\' => \"$message\",\n";
              }
              print "\t\t},\n";
           }
           print "\t},\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{PIPEOUT}  = {\n";
    foreach $param (@parameters_order) {
       if ($type{$param} eq "OutFile" || $type{$param} eq "Results") {
          if (defined $pipe{$param}) {
             print "\t\"$param\" => {\n";
             foreach $pipetype (keys %{ $pipe{$param}} ) {
                foreach $language (keys %{ $pipe{$param}{$pipetype}  } ) {
                    my $test = $pipe{$param}{$pipetype}{$language};
                    print "\t\t \'$test\' => \"$pipetype\",\n";
                 }
             }
             print "\t},\n";
          }
       }
    }
    print "
    };\n";

    print "
    \$self->{WITHPIPEOUT}  = {\n";
    foreach $param (@parameters_order) {
       if ($type{$param} eq "OutFile" || $type{$param} eq "Results") {
          if (defined $withpipe{$param}) {
             print "\t\"$param\" => {\n";
             foreach $pipetype (keys %{ $withpipe{$param}} ) {
                 print "\t\t \"$pipetype\" => [";
                 foreach my $parametername ( @{ $withpipe{$param}{$pipetype} }) {
                    print "\"$parametername\",";
                 }
                 print "]\n";
             }
             print "\t},\n";
          }
       }
    }
    print "
    };\n";

    print "
    \$self->{PIPEIN}  = {\n";
    foreach $param (@parameters_order) {
       if ($type{$param} eq "InFile" || $type{$param} eq "Sequence") {
          if (defined $pipe{$param}) {
             print "\t\"$param\" => {\n";
             foreach $pipetype (keys %{ $pipe{$param}} ) {
                foreach $language (keys %{ $pipe{$param}{$pipetype}  } ) {
                    my $test = $pipe{$param}{$pipetype}{$language};
                    print "\t\t \"$pipetype\" => \'$test\',\n";
                 }
             }
             print "\t},\n";
          }
       }
    }
    print "
    };\n";

    print "
    \$self->{WITHPIPEIN}  = {\n";
    foreach $param (@parameters_order) {
       if ($type{$param} eq "InFile" || $type{$param} eq "Sequence") {
          if (defined $withpipe{$param}) {
             print "\t\"$param\" => {\n";
             foreach $pipetype (keys %{ $withpipe{$param}} ) {
                 print "\t\t \"$pipetype\" => [";
                 foreach my $parametername ( @{ $withpipe{$param}{$pipetype} }) {
                    print "\"$parametername\",";
                 }
                 print "]\n";
             }
             print "\t},\n";
          }
       }
    }
    print "
    };\n";

    print "
    \$self->{ISCLEAN}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $isclean{$param}) {
         	print "\t\"$param\" => ", $isclean{$param},",\n";
        } else {
         	print "\t\"$param\" => 0,\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{ISSIMPLE}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $issimple{$param}) {
	     print "\t\"$param\" => ", $issimple{$param},",\n";
        } else {
         	print "\t\"$param\" => 0,\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{PARAMFILE}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $paramfile{$param}) {
        	print "\t\"$param\" => \"", $paramfile{$param},"\",\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{COMMENT}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $comment{$param}) {
           print "\t\"$param\" => [\n";
           foreach my $comment (@{ $comment{$param} }) {
               $comment =~ s/\'/\\\'/g;
               print "\t\t\"$comment\",\n";
           }
           print "\t],\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{SCALEMIN}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $scalemin{$param}) {
           if (keys %{ $scalemin{$param}}) {
           } elsif ($scalemin{$param} !~ /^\s*$/) {
              print "\t\"$param\" => ", $scalemin{$param},",\n";
           }
        }
    }
    print "
    };\n";

    print "
    \$self->{SCALEMAX}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $scalemax{$param}) {
           if (keys %{ $scalemax{$param}}) {
           } elsif ($scalemax{$param} !~ /^\s*$/ ) {
              print "\t\"$param\" => ", $scalemax{$param},",\n";
           }
        }
    }
    print "
    };\n";

    print "
    \$self->{SCALEINC}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $scaleinc{$param}) {
           print "\t\"$param\" => ", $scaleinc{$param},",\n";
        }
    }
    print "
    };\n";

    print "
    \$self->{INFO}  = {\n";
    foreach $param (@parameters_order) {
        if (defined $info{$param}) {
           if (keys %{ $info{$param}}) {
           } elsif ($info{$param} !~ /^\s*$/ ) {
              print "\t\"$param\" => ", $info{$param},",\n";
           }
        }
    }
    print "
    };\n";

    print "
    bless (\$self, \$class);
    return \$self;
}
";

    print "# -- begin inclusion of $perloopise\n";
    open(LIB,$perloopise) || die "cannot open $perloopise: $!";
    while (<LIB>) {
        print;
    }
    close LIB;
    print "# -- end inclusion of $perloopise\n";

    print "
1;
";

}
sub by_group {
    $group{$a} <=> $group{$b};
}


1;
