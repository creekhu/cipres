#
# HTML : non expert version of the form (attribute : simple)
#
#TODO:

use lib "/local/gensoft/lib/Pise/5.a/PerlDef";

package Maker;

$command=$ARGV[0];

# Settings

require "/local/gensoft/lib/Pise/5.a/lib/web.pl";
require "/local/gensoft/lib/Pise/5.a/Maker/make-html-utils.pl";

eval ("use $command;");

$defs = $command->new;
if (defined $ARGV[1]) {
    $required=$ARGV[1];
    require "$required";
}
&print_headers($defs,"simple");
&print_one_param($defs,"simple", "email","Mail");

&do_parameters ($defs, 1, $defs->top_parameters);

print "</FORM>\n";

print "<br></br>\n";

if (defined $required) {

   if (defined $INITFORM && $INITFORM==1) {
        if (! defined $scratch_dir) {
          print "<hr></hr>\n";
	  print STDERR "$command: from initform...\n";
	  print "<FORM method=POST action=\"$CGI_URL/lib/initform.pl\">\n" ;

	  foreach $param (keys %hidden) {
	      if ($defs->type($param) eq "List") {
		  @param_value = @{ $hidden{$param} };
		  foreach $val ( @param_value ) {
		      #print STDERR "$0: (List) $val\n";
		      print "<INPUT NAME=\"$param_name\" TYPE=\"HIDDEN\" VALUE=\"$val\"/>\n";
		  }
	      } else {
		  $param_value = $hidden{$param};
#       print STDERR "param_value = $param_value\nparam_name=$param_name\n";
		  print "<INPUT NAME=\"param\" TYPE=\"HIDDEN\" VALUE=\"$param\"/>\n";
		  print "<INPUT NAME=\"$param\" TYPE=\"HIDDEN\" VALUE=\"$param_value\"/>\n";
	      }
	  }

	  print "<Input TYPE=\"submit\" VALUE=\"Advanced form\">\n";
	  print "<INPUT NAME=\"command\" TYPE=\"HIDDEN\" VALUE=\"$command\"/>\n";
	  print "<INPUT NAME=\"user_level\" TYPE=\"HIDDEN\" VALUE=\"advanced\"/>\n";
	  print "<INPUT NAME=\"scratch_dir\" TYPE=\"HIDDEN\" VALUE=\"$scratch_dir\"/>\n";
	  print "</FORM>\n";
      }

    } else {

	print "<hr></hr>\n";
       print "\n<FORM method=POST action=\"$CGI_URL/lib/connect.pl\">\n" ;
#      print "\n<INPUT NAME=\"command\" TYPE=HIDDEN VALUE=\"$command\"/>\n" ;
       $type = ${"${command}::piped"}{"piped_file_type"};
       $virgule="";
       my $piped_file;
       my $piped_variable = lookup_piped_variable($defs,$type);
       my @param_names = ( @{ $defs->withpipein($piped_variable,$type) } );
#    print STDERR "param_names($piped_variable)[$type] : ",join(",",@param_names),"\n";
       foreach $param_name (@param_names) {
        if ($param_name =~ /=/) {
	   ($in_param,$out_param) = split ("=",$param_name);
           $param_value = ${"${command}::piped"}{$out_param};
           $param_value = `basename $param_value`;
           chop($param_value);
	   if ($param_value) {
	       $with_piped_files .= $virgule . "$in_param=" .$param_value ;
	   }
        } else {
           $param_value = ${"${command}::piped"}{$param_name};
           $param_value = `basename $param_value`;
           chop($param_value);
	   if ($param_value) {
	       $with_piped_files .= $virgule . "$param_name=" . $param_value;
	   }
        }
        $virgule=",";
      }
      print "\n<INPUT NAME=\"command\" TYPE=HIDDEN VALUE=\"$command,$with_piped_files\"/>\n" ;
      print "\n<INPUT TYPE=\"submit\" VALUE=\"Advanced $command form\"/>\n" ;
      print "\n<INPUT NAME=\"scratch_dir\" TYPE=\"HIDDEN\" VALUE=\"", ${"${command}::piped"}{"scratch_dir"},"\"/>\n" ;
      print "\n<INPUT NAME=\"piped_file\" TYPE=\"HIDDEN\" VALUE=\"",${"${command}::piped"}{"piped_file"},"\"/>\n";
      print "\n<INPUT NAME=\"piped_file_type\" TYPE=\"HIDDEN\" VALUE=\"",${"${command}::piped"}{"piped_file_type"},"\"/>\n" ;
      print "\n<INPUT NAME=\"email\" TYPE=\"HIDDEN\" VALUE=\"",${"${command}::piped"}{"email"},"\"/>\n";

      print "\n</FORM>\n" ;
    }
} else {
    print "<a href=\"$command.html\">Advanced $command form</a>\n\n";
}

if (defined %comments || $seqfmt) {
    print "<hr></hr>\n<H2>Some explanations about the options</H2>\n";
    print "\n<dl>\n";
}
if (defined %comments) {
    foreach $param ( keys %comments ) {
	$string = $defs->prompt($param);
	$aname=$param;
	print "<dt><a name=$aname><i>$string</i></a></dt>\n";
	foreach $comment ($defs->comment($param)) {
	    print "<dd>$comment</dd>\n";
	}
    }
}
if ($seqfmt) {
    print "<dt><a name=fmtseq><i>Sequence format</i></a></dt>\n";
    print "<dd>The sequence will be automatically converted in the format needed for the program\n";
    print "<dd>providing you enter a sequence either:</dd>\n";
    print "<dd> in plain (raw) sequence format or in one of the following known formats:</dd>\n";
    print "<dd>IG,GenBank,NBRF,EMBL,GCG,DNAStrider,Fitch,fasta,Phylip,PIR,MSF,ASN,PAUP</dd>\n";
    if ($DBSEARCH) {
	print "<dd>You may enter in the text area a database entry code, or an accession number, in this form:<BR></BR><CODE>database:entry_name</CODE><BR></BR>or:<BR></BR><CODE>database:accession</CODE>.</dd>\n";
    }
}
if (defined %comments || $seqfmt || $defs->reference) {
    print "</dl><hr></hr>\n";
}

&print_footer($defs, "simple");

sub do_parameters {
    my ($defs, $top, @parameters_list) = @_ ;
    my $param;

    foreach $param (@parameters_list) {
	next if ($defs->ishidden($param) 
          || $defs->type($param) eq "Results");
	&print_one_param($defs, 
			 "simple", 
			 $param,
			 $defs->type($param));
        if ($defs->issimple($param) && defined $defs->comment($param) ) {
	    print STDERR "comment ($param)\n";
            push( @{ $comments{$param}}, $param);
        }
    }

    foreach $param (@parameters_list) {
	next if ($defs->ishidden($param));
	if ($defs->type($param) eq "Paragraph") {
	    foreach $p ( $defs->vlist($param) ) {
		push @{ $parameters_todo{$param} }, $p;
	    }
	    &do_parameters($defs, 0, @{$parameters_todo{$param}} );

	}
    }

}

sub lookup_piped_variable {
    my $defs = $_[0];
    my $type=$_[1];
    my $k;
    foreach $k (keys ( %{ $defs->pipein } ) ) {
	if (defined $defs->pipein($k, $type)) {
	    return $k;
	}
    }
}

1;


