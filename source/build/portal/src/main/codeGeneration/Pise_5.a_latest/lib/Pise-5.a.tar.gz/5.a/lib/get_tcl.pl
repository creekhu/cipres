#! /local/bin/perl
#
# send tcl code
# 

use strict;
use CGI;

my %authorized;
$authorized{'pise'} = 1;
$authorized{'http'} = 1;

my $request=new CGI;
my $source=$request->param('source');

print $request->header(-type=>'text/plain');

if ($authorized{$source}) {

    my $VERSION="5.a";
    my $PISEDIR="/local/gensoft/lib/Pise/$VERSION";
    my $remote = $ENV{'REMOTE_HOST'};
    print STDERR "$0: sending code $PISEDIR/lib/$source.tcl to $remote\n";
    open (TCL,"$PISEDIR/lib/$source.tcl") || die "Cannot find $PISEDIR/lib/$source.tcl:$!";
    while (<TCL>) {
	print;
    }
    close(TCL);
} else {
    print STDERR "$0: illegal request for tcl source: $source\n";
}
