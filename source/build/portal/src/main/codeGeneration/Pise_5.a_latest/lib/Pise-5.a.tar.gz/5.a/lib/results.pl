#! /local/bin/perl

use File::Basename;
use CGI;

$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";
require "/local/gensoft/lib/Pise/5.a/lib/web.pl";

my $input = new CGI;
print $input->header;
print $input->start_html("Results reception.");

$command=$input->param('command');
$scratch_dir=$input->param('scratch_dir');
$results_type=$input->param('results_type');

$email=$input->param('email');
$email =~ s|\\||g if ($email =~ /\\\@/);
if ($PASTEUR) {
   $email .= '@pasteur.fr' unless ($email =~ /\@/);
}
if ( ! ($email  =~ /^(\w|-|\+|,|@|\.(?!\.))+$/ ) ) {
    print "<I>email</I> = $email: this value is not allowed";
    print $input->end_html;
    exit;
}
$email =~ s|\\||g unless ($email =~ /\@/);

my $date=localtime;
$me = basename $0;
print STDERR "[$date] $me: $command ($scratch_dir) results_type: $results_type ($email)\n";


chdir "$tmp_dir/$scratch_dir";
#print STDERR "DEBUG> results.pl dir: $tmp_dir/$scratch_dir (",`pwd`,")\n";
if ($results_type eq "url" || $results_type eq "attachment" || $results_type eq "files" ) {

    open (RESULTSTYPE, "> .results") || die "cannot open .results: $!";
    print RESULTSTYPE "\$results_type=\"$results_type\";\n";
    close RESULTSTYPE;
} else {
    print "<I>$results_type</I>: this value is not allowed";
    print $input->end_html;
    exit;
}

open (EMAIL, "> .email") || die "cannot open .email: $!";
print EMAIL "\$email='$email';\n";
close EMAIL;

if ($results_type eq "url") {
    print "You will receive the url of the job upon its completion (sent to: $email). All the results files will be available at this url.\n";
} elsif ($results_type eq "attachment") {
    print "You will receive all the results as attachments in one email (sent to: $email).\n";
} else {
    print "You will receive all the results by emails, as well as the url (sent to: $email).\n";
}

print $input->end_html;
