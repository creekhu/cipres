from Pise import PiseFactory
import Bio.Fasta
import sys

email = 'letondal@pasteur.fr'
factory = PiseFactory(email=email)
program = factory.program("toppred",graph_output=1,profile_format="ps")

handle = open(sys.argv[1])
it = Bio.Fasta.Iterator(handle, Bio.Fasta.SequenceParser())
seq = it.next()
job = program.run(query=seq)

if job.error():
    print job.error_message()
else:
    print "url of the job: " + job.jobid()
    print job.stdout()
    print job.get_results()
    job.save('.ps')

