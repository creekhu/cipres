use lib "/local/private/sis/letondal/packages/bioperl-run";
use lib "/local/private/sis/letondal/packages/bioperl-live";

use Bio::Tools::Run::AnalysisFactory::Pise;
use Bio::SeqIO;
use Bio::SearchIO;

$_in_seq = Bio::SeqIO->newFh (-file => $ARGV[0],
                              -format => "fasta");
my $seq = <$_in_seq>; 

#my $email = 'letondal@pasteur.fr'; # your email
my $factory = Bio::Tools::Run::AnalysisFactory::Pise->new(-email => $email);
my $blast2 = $factory->program('blast2');
my $mspcrunch = $factory->program('mspcrunch');

$blast2->blast2('blastp');
$blast2->protein_db('swissprot');

my $blast_job = $blast2->run( -query => $seq);
sleep 5;
my $blast_output = $blast_job->lookup_piped_file('blast_output');
print STDERR "blast jobid: ", $blast_job->jobid(), "\nBlast output: $blast_output\n";
$mspcrunch->blast_output($blast_job->fh($blast_output));
$mspcrunch->three_frame(1);
my $mspcrunch_job = $mspcrunch->run();

my $mspcrunch_output = $mspcrunch_job->save('mspcrunch.txt');
print STDERR "mspcrunch jobid: ", $mspcrunch_job->jobid(), "\nOutput saved in: $mspcrunch_output\n";
