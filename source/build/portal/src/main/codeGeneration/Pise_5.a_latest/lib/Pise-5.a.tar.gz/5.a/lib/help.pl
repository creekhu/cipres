#! /local/bin/perl

# send help message to help
use CGI;
use Mail::Internet ;


$ENV{'PATH'}="/usr/bin:/bin:/usr/local/bin:/usr/sbin";

my $input = new CGI;
$command=$input->param('command');
$email=$input->param('email');
$message=$input->param('message');
my $agent_line = "User agent: $ENV{'HTTP_USER_AGENT'}\n";
$message =  $agent_line . $message;
if (defined $input->param('PISEDIR')) {
    $PISEDIR=$input->param('PISEDIR');
} else {
    $PISEDIR="/local/gensoft/lib/Pise/5.a";
}
require "$PISEDIR/lib/web.pl";

if (defined $input->param('subject')) {
    $subject=$input->param('subject');
    if ($subject =~ /^\s*$/) {
	$subject="help about a $command job";
    }
} else {
    $subject="help about a $command job";
}

printf "Content-type: text/html\n\n";

if ($email) {
    $help =~ s/\\//g;
    $mail = new Mail::Internet ( [ "From: $email" ,
                               "To: $help" ,
                               "Cc: $email",
                               "Subject: $subject" ] ,
                             'Body' => [ $message ] ) ;

    $ENV{MAILADDRESS} =  $email;

# RFC2219
    $mail->smtpsend ( 'Host' => "$MAILHOST" ) ;

    print "Your message \"$subject\" has been sent to $help\n";
} else {
    print "<B>You must provide an email.</B>\n";
}




