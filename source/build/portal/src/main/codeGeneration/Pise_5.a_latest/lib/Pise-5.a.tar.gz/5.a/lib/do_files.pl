# local interfaces

# handle filenames

sub do_files {
  my $defs = $_[0] ;
  my $filename;
  my $tmp;

  if (! ( &def_var("html") )) {
    foreach $param ( $defs->parameters_order) {
	if ( &def_var($param) ) {
	    if ($defs->type($param) eq "InFile" ||
		$defs->type($param) eq "Sequence" ) {
#             print STDERR "filename = $$param\n";
        	($tmp = &get_var($param)) =~ s/\s//g ;
	        &set_var($param, $tmp);
	        $filename=`basename $tmp`;
	        chop($filename);
	        if ($filename ne $tmp) {
#                   print STDERR "Symbolic link : $$param <- $filename\n";
	            symlink &get_var($param), $filename;
	            &set_var($param, $filename);
	        }
            }
        }
    }
  }
}

1;
