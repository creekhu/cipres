#!/local/bin/perl

# gives a name space for program parameters' variables
# in order to avoid variable collisions with interface variables

sub my_eval {
    my $s = shift;
    my $e;
    $e = eval("package evaluation; $s ;");
#    print STDERR "my_eval: s=$s e=$e\n";
    return $e;
}

sub set_var {
    my $var = $_[0];
    my $val = $_[1];
    package evaluation;
#    print STDERR "set_var: val=$val var=$var\n";
    $$var = $val;
}

sub get_var {
    my $var = $_[0];
    package evaluation;
    return $$var;
}

sub def_var {
    my $var = $_[0];
    package evaluation;
    return (defined $$var)? 1 : 0;
}

sub get_var_ref {
    my $var = $_[0];
    package evaluation;
    return \$$var;
}

1;

