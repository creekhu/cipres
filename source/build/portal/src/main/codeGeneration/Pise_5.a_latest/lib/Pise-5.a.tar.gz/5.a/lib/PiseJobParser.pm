package PiseJobParser;

$verbose  = 0;
$debug = 0;

sub new {
    my $type;
    if (@_) {
	$type = shift;
    }
    if (@_) {
	$verbose = shift;
    }
    return bless {}, $type;
}

sub characters {
    my ($self, $element) = @_; 
    chomp ($element->{Data});
#    print STDERR $element->{Data}  if ($verbose);
    if ($element->{Data} =~ /Results not available yet/) {
	$PiseJobParser::terminated = 0;
    }
    if ($element->{Data} =~ /Results:/) {
	$PiseJobParser::output_files = 1;
    }
    if ($element->{Data} =~ /Your input data:/) {
	$PiseJobParser::output_files = 0;
    }
    if ($check_message) {
	$PiseJobParser::error_message .= $element->{Data};
    }
}

sub comment {
    my ($self, $element) = @_; 
    if ($element->{Data} =~ /USER ERROR/) {
	$PiseJobParser::error = 1;
    }
}

sub start_element {
    my ($self, $element) = @_;
    print STDERR "\nstart element: ",$element->{Name},"\n" if ($debug);

    %attributes = %{ $element->{Attributes} };
    foreach $attr (keys %attributes) {
	print STDERR "\t$attr $attributes{$attr}\n"  if ($debug);
    }
    if ($element->{Name} eq "HTML") {
	$PiseJobParser::terminated = 1;
	$PiseJobParser::error = 0;
	$PiseJobParser::error_message = "";
	@hrefs = ();
    } elsif ($element->{Name} eq "A") {
	$href = $attributes{HREF};

	# what about Pise servers with Pise in the url??
	#if ($href !~ /Pise/ && $href ne "" && $PiseJobParser::output_files) {

	if ($href ne "" && $PiseJobParser::output_files) {
	    push (@hrefs, $href);
	    print STDERR "PiseJObParser: href=$href\n" if ($debug);
	}
    } elsif ($element->{Name} eq "H3") {
	if ($PiseJobParser::error) {
	    $check_message=1;
	}
    } elsif ($element->{Name} eq "FORM") {
	$action = $attributes{action};
	if ($action =~ /connect.pl/) {
	    $connected{$href} = 1;
	    print STDERR "\t$href is connected to...\n" if ($debug);
	} elsif ($action =~ /results.pl/) {
	    $PiseJobParser::terminated = 0;
	}
	$form++;
    } elsif ($element->{Name} eq "INPUT") {
	$name=$attributes{NAME};
	$value=$attributes{VALUE};
	if ($name eq "scratch_dir") {
	    $PiseJobParser::scratch_dir = $value;
	} else {
	    $PiseJobParser::value{$name} = $value;
	}
	if ($connected{$href}) {
	    if ($name eq "piped_file_type") {
		print STDERR "DEBUG> $href = $value\n"  if ($debug);
		$piped_file_type{$href} = $value;
	    }
	}
    } elsif ($element->{Name} eq "OPTION") {
	$option=1;
	$value=$attributes{VALUE};
	my $command;
	my @with_piped_files;
	my $with_href;
	my $root_url;
	($command,@with_piped_files) = split(",",$value);
	if ($connected{$href}) {
	    push (@{ $pipes{$href}},$command);
	    ($root_url = $href) =~ s/(.+)\/.+/$1/;
	    foreach my $with_file (@with_piped_files) {
		($with_param,$with_value) = split("=",$with_file);	
		$with_href = "$root_url/$with_value" ;
		push @{ $with_href{$href} }, $with_href;
		if ( ! (grep {$command eq $_ } @{ $pipes{$with_href}}) ) {
		    push (@{ $pipes{$with_href}},$command);
		    $piped_file_type{$with_href} = $with_param;
		}
	    }
	    print STDERR "\t\t$href is connected to $value\n"  if ($debug);
	}
    } 

}

sub end_element {
    my ($self, $element) = @_;
    print STDERR "\nend element: ",$element->{Name},"\n" if ($debug);
    if ($element->{Name} eq "H3") {
	if ($PiseJobParser::error) {
	    $check_message=0;
	}
    }
}

sub pipes {
    return %PiseJobParser::pipes;
}

sub piped_file_type {
    my $self = shift;
    my $href = shift;
    return $piped_file_type{$href};
}

1;
