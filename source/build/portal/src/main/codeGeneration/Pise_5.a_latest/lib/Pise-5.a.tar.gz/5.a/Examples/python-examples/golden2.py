from Pise import PiseFactory

factory = PiseFactory(email='letondal@pasteur.fr')
golden = factory.program("golden",db="embl",query="MMVASP")
golden.verbose(1)
j=golden.run()
print j.stdout()


